"""
constraints.py — 约束检查引擎

刚性约束：不能违反什么。
软性约束：最好不违反，但可以权衡。
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable

from state import WorldState


@dataclass
class Constraint:
    """单个约束定义"""
    name: str
    check_fn: Callable[[WorldState], bool]  # True = 通过, False = 违反
    severity: str = "hard"  # hard | soft
    message: str = ""
    violation_count: int = 0


@dataclass
class ConstraintReport:
    """约束检查报告"""
    passed: list[str] = field(default_factory=list)
    soft_violations: list[dict[str, Any]] = field(default_factory=list)
    hard_violations: list[dict[str, Any]] = field(default_factory=list)
    
    @property
    def has_hard_violations(self) -> bool:
        return len(self.hard_violations) > 0
    
    @property
    def has_any_violations(self) -> bool:
        return len(self.soft_violations) > 0 or len(self.hard_violations) > 0
    
    @property
    def all_clear(self) -> bool:
        return not self.has_any_violations


class ConstraintChecker:
    """约束检查器"""

    def __init__(self):
        self.constraints: list[Constraint] = []

    def add_constraint(self, name: str, check_fn: Callable[[WorldState], bool],
                       severity: str = "hard", message: str = "") -> None:
        """添加约束"""
        self.constraints.append(Constraint(
            name=name, check_fn=check_fn, severity=severity, message=message
        ))

    def check(self, state: WorldState) -> ConstraintReport:
        """检查所有约束"""
        report = ConstraintReport()
        
        for c in self.constraints:
            try:
                passed = c.check_fn(state)
            except Exception as e:
                passed = False
                c.message = f"Check error: {e}"
            
            if passed:
                report.passed.append(c.name)
            else:
                violation = {
                    "constraint": c.name,
                    "severity": c.severity,
                    "message": c.message,
                }
                if c.severity == "hard":
                    report.hard_violations.append(violation)
                    c.violation_count += 1
                else:
                    report.soft_violations.append(violation)
                    c.violation_count += 1
        
        return report

    def summary(self) -> dict[str, Any]:
        return {
            "constraint_count": len(self.constraints),
            "hard_constraints": sum(1 for c in self.constraints if c.severity == "hard"),
            "soft_constraints": sum(1 for c in self.constraints if c.severity == "soft"),
            "total_violations": sum(c.violation_count for c in self.constraints),
        }


# ---- 预定义约束函数 ----

def cpu_not_overloaded(threshold: float = 90.0):
    """CPU 不能过载"""
    def _check(state: WorldState) -> bool:
        return state.get("cpu_percent", 0) < threshold
    return _check


def memory_not_exhausted(threshold: float = 95.0):
    """内存不能耗尽"""
    def _check(state: WorldState) -> bool:
        return state.get("memory_percent", 0) < threshold
    return _check


def disk_not_full(threshold: float = 95.0):
    """磁盘不能满"""
    def _check(state: WorldState) -> bool:
        return state.get("disk_percent", 0) < threshold
    return _check


def network_must_be_up():
    """网络必须连通"""
    def _check(state: WorldState) -> bool:
        return state.get("network_connected", 0) > 0.5
    return _check


def no_zombie_processes():
    """不能有僵尸进程"""
    def _check(state: WorldState) -> bool:
        return state.get("zombie_count", 0) == 0
    return _check


def containers_must_be_running(expected_count: int = 1):
    """容器必须运行"""
    def _check(state: WorldState) -> bool:
        return state.get("container_count", 0) >= expected_count
    return _check
