"""
core.py — 自适应Agent主循环引擎

架构:
  Observe → Analyze → Evaluate → Select → Execute → Feedback → (iterate)
  
输入 → 目标 → 约束 → 资源 → 动作 → 反馈 → 迭代

在约束内持续把世界状态推向目标状态的自适应系统。
"""

from __future__ import annotations
import asyncio
import json
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

from state import StateObserver, WorldState
from goals import GoalEvaluator, GoalVerdict
from constraints import ConstraintChecker
from actions import ActionSelector, ActionResult
from feedback import FeedbackCollector, LearningSignal

logger = logging.getLogger("adaptive-agent")


class AgentPhase(Enum):
    OBSERVE = "observe"
    ANALYZE = "analyze"
    EVALUATE = "evaluate"
    SELECT = "select"
    EXECUTE = "execute"
    FEEDBACK = "feedback"
    IDLE = "idle"
    PAUSED = "paused"


@dataclass
class CycleRecord:
    """单次循环的完整记录，用于回溯和学习"""
    cycle_id: int
    timestamp: datetime
    phase_transitions: list[tuple[AgentPhase, float]] = field(default_factory=list)
    state_before: Optional[WorldState] = None
    state_after: Optional[WorldState] = None
    goal_verdict: Optional[GoalVerdict] = None
    action_taken: Optional[str] = None
    action_result: Optional[ActionResult] = None
    learning_signal: Optional[LearningSignal] = None
    delta_to_target: float = 0.0
    improvement: float = 0.0  # positive = moved toward goal


@dataclass
class AgentConfig:
    """Agent运行配置"""
    max_cycles: int = 0  # 0 = 无限循环
    cycle_interval_seconds: float = 5.0  # 循环间隔
    max_consecutive_failures: int = 3  # 连续失败熔断
    cooldown_after_failure: float = 30.0  # 失败后冷却秒数
    history_size: int = 100  # 保留最近N条循环记录
    convergence_threshold: float = 0.01  # 收敛判定阈值
    convergence_cycles: int = 5  # 连续N次无改进则收敛
    auto_recover: bool = True  # 异常自动恢复
    log_level: str = "INFO"
    state_snapshot_dir: Optional[str] = None  # 可选的状态快照持久化目录
    execution_mode: str = "dry_run"  # dry_run | live; dry_run is safest by default
    permitted_actions: tuple[str, ...] = ()  # Required allowlist for live execution


class AdaptiveAgent:
    """
    自适应Agent — 在约束内持续把世界状态推向目标状态。
    
    用法:
        agent = AdaptiveAgent(config)
        agent.register_observer(my_observer)
        agent.register_goal(my_goal)
        agent.register_constraint(my_constraint)
        agent.register_action(my_action)
        await agent.run()
    """

    def __init__(self, config: Optional[AgentConfig] = None):
        self.config = config or AgentConfig()
        if self.config.execution_mode not in ("dry_run", "live"):
            raise ValueError("execution_mode must be dry_run or live")
        self.observers: list[StateObserver] = []
        self.goal_evaluator = GoalEvaluator()
        self.constraint_checker = ConstraintChecker()
        self.action_selector = ActionSelector()
        self.feedback_collector = FeedbackCollector()
        
        self.phase = AgentPhase.IDLE
        self.current_state: Optional[WorldState] = None
        self.cycle_count = 0
        self.consecutive_failures = 0
        self.history: deque[CycleRecord] = deque(maxlen=self.config.history_size)
        self._running = False
        self._paused = False
        
        # 自适应学习参数
        self.learning_rate = 0.1
        self.action_weights: dict[str, float] = {}  # 学习到的动作权重
        
        logging.basicConfig(
            level=getattr(logging, self.config.log_level),
            format="%(asctime)s [%(name)s] %(levelname)s: %(message)s"
        )

    def register_observer(self, observer: StateObserver) -> None:
        """注册状态观测器"""
        self.observers.append(observer)
        logger.info(f"Observer registered: {observer.name}")

    def register_goal(self, name: str, target: float, weight: float = 1.0,
                      direction: str = "maximize",
                      evaluate_fn: Optional[Callable[[WorldState], float]] = None) -> None:
        """注册目标"""
        self.goal_evaluator.add_goal(name, target, weight, direction, evaluate_fn)

    def register_constraint(self, name: str, check_fn: Callable[[WorldState], bool],
                            severity: str = "hard", message: str = "") -> None:
        """注册约束"""
        self.constraint_checker.add_constraint(name, check_fn, severity, message)

    def register_action(self, name: str, execute_fn: Callable[[WorldState], ActionResult],
                        cost: float = 1.0, expected_benefit: float = 0.0,
                        risk: float = 0.0, reversible: bool = True) -> None:
        """注册动作"""
        self.action_selector.register(name, execute_fn, cost, expected_benefit, risk, reversible)
        self.action_weights.setdefault(name, 1.0)

    async def observe(self) -> WorldState:
        """Phase 1: 观察世界状态"""
        self._transition(AgentPhase.OBSERVE)
        state = WorldState()
        for obs in self.observers:
            try:
                obs_state = await obs.observe()
                state.merge(obs_state)
            except Exception as e:
                logger.error(f"Observer {obs.name} failed: {e}")
        state.timestamp = datetime.now()
        return state

    async def analyze(self, state: WorldState) -> dict[str, Any]:
        """Phase 2: 分析状态 — 提取关键变量、异常、趋势"""
        self._transition(AgentPhase.ANALYZE)
        analysis = {
            "timestamp": state.timestamp.isoformat(),
            "variable_count": len(state.variables),
            "recent_deltas": [],
            "anomalies": [],
            "trend": "stable",
        }
        
        # 分析最近状态变化
        if len(self.history) >= 2:
            prev = self.history[-1].state_before
            if prev:
                for key in state.variables:
                    if key in prev.variables:
                        delta = state.variables[key] - prev.variables[key]
                        analysis["recent_deltas"].append({
                            "variable": key, "delta": delta
                        })
                        # 异常检测
                        if abs(delta) > 10.0:
                            analysis["anomalies"].append({
                                "variable": key,
                                "delta": delta,
                                "severity": "high" if abs(delta) > 50 else "medium"
                            })
        
        # 趋势判断
        if len(analysis["recent_deltas"]) > 0:
            avg_delta = sum(d["delta"] for d in analysis["recent_deltas"]) / len(analysis["recent_deltas"])
            if avg_delta > 0.1:
                analysis["trend"] = "improving"
            elif avg_delta < -0.1:
                analysis["trend"] = "degrading"
        
        return analysis

    async def evaluate(self, state: WorldState) -> GoalVerdict:
        """Phase 3: 评估目标达成度"""
        self._transition(AgentPhase.EVALUATE)
        verdict = self.goal_evaluator.evaluate(state)
        
        if verdict.distance_to_target < self.config.convergence_threshold:
            verdict.converged = True
        
        return verdict

    async def select_action(self, state: WorldState, verdict: GoalVerdict) -> Optional[str]:
        """Phase 4: 选择最优动作"""
        self._transition(AgentPhase.SELECT)
        
        # 检查约束
        violations = self.constraint_checker.check(state)
        if violations.has_hard_violations:
            logger.warning(f"Hard constraint violations: {violations.hard_violations}")
            # 优先选择修复约束的动作
            return self.action_selector.select_repair_action(violations, self.action_weights)
        
        # 如果已收敛，不做动作
        if verdict.converged:
            logger.info("Goal converged — no action needed")
            return None
        
        # 选择最高预期收益的动作
        action_name = self.action_selector.select_best(
            state, verdict, self.action_weights, self.history
        )
        
        if action_name:
            logger.info(f"Selected action: {action_name} "
                       f"(score={self.action_selector.last_scores.get(action_name, 0):.3f})")
        
        return action_name

    async def execute(self, action_name: str, state: WorldState) -> ActionResult:
        """Phase 5: 执行动作"""
        self._transition(AgentPhase.EXECUTE)
        
        if self.config.execution_mode == "dry_run":
            logger.info("DRY-RUN: would execute '%s' (no side effects)", action_name)
            return ActionResult(
                success=False, output="dry-run: action not executed",
                side_effects={"simulated": True},
            )
        if action_name not in self.config.permitted_actions:
            logger.warning("BLOCKED: action '%s' not on explicit live allowlist", action_name)
            return ActionResult(
                success=False, error="action not on explicit live allowlist",
                side_effects={"blocked": True},
            )
        result = await self.action_selector.execute(action_name, state)

        if result.success:
            logger.info(f"Action '{action_name}' succeeded in {result.duration_ms:.0f}ms")
            self.consecutive_failures = 0
        else:
            logger.error(f"Action '{action_name}' failed: {result.error}")
            self.consecutive_failures += 1
        
        return result

    async def feedback(self, state_before: WorldState, state_after: WorldState,
                       action_name: Optional[str], result: Optional[ActionResult],
                       verdict: GoalVerdict) -> LearningSignal:
        """Phase 6: 收集反馈并学习"""
        self._transition(AgentPhase.FEEDBACK)
        
        signal = LearningSignal(
            action_name=action_name or "noop",
            success=result.success if result else True,
            delta_to_target=self.goal_evaluator.evaluate(state_after).distance_to_target,
            improvement=0.0,
            executed=bool(action_name and result and not (
                result.side_effects.get("simulated") or result.side_effects.get("blocked")))
        )

        # 计算改进量
        if action_name and result and result.success:
            signal.improvement = self._calculate_improvement(state_before, state_after)
        
        # Only learn from actions actually executed, not simulated/blocked operations.
        did_execute = signal.executed
        if did_execute and action_name in self.action_weights:
            if signal.improvement > 0:
                self.action_weights[action_name] += self.learning_rate * signal.improvement
            else:
                self.action_weights[action_name] *= 0.95
            self.action_weights[action_name] = max(0.1, min(10.0, self.action_weights[action_name]))
        
        self.feedback_collector.record(signal)
        
        return signal

    async def run_cycle(self) -> CycleRecord:
        """执行一次完整的 Agent 循环"""
        cycle_id = self.cycle_count
        record = CycleRecord(cycle_id=cycle_id, timestamp=datetime.now())
        
        try:
            # 1. 观察
            state = await self.observe()
            record.state_before = state
            
            # 2. 分析
            analysis = await self.analyze(state)
            
            # 3. 评估目标
            verdict = await self.evaluate(state)
            record.goal_verdict = verdict
            record.delta_to_target = verdict.distance_to_target
            
            logger.info(
                f"Cycle {cycle_id}: distance_to_target={verdict.distance_to_target:.4f}, "
                f"converged={verdict.converged}, trend={analysis['trend']}"
            )
            
            # 4. 选择动作
            action_name = await self.select_action(state, verdict)
            record.action_taken = action_name
            
            # 5. 执行（如果有动作）
            result = None
            if action_name:
                result = await self.execute(action_name, state)
                record.action_result = result
            
            # 4.5 如果无动作（收敛或无可行动作），跳过执行
            if not action_name:
                result = ActionResult(success=True, output="noop")
            
            # 6. 重新观察（获取动作后的新状态）
            new_state = await self.observe()
            record.state_after = new_state
            
            # 7. 反馈与学习
            signal = await self.feedback(
                state, new_state, action_name, result, verdict
            )
            record.learning_signal = signal
            record.improvement = signal.improvement

            # 8. 检查收敛
            verdict2 = self.goal_evaluator.evaluate(new_state)
            record.delta_to_target = verdict2.distance_to_target
            
        except Exception as e:
            logger.error(f"Cycle {cycle_id} failed: {e}", exc_info=True)
            record.action_result = ActionResult(success=False, error=str(e))
            self.consecutive_failures += 1
        
        return record

    async def run(self) -> None:
        """启动 Agent 主循环"""
        self._running = True
        self.phase = AgentPhase.IDLE
        logger.info(f"Agent starting — {len(self.observers)} observers, "
                   f"{len(self.goal_evaluator.goals)} goals, "
                   f"{len(self.constraint_checker.constraints)} constraints, "
                   f"{len(self.action_selector.registry)} actions")
        
        while self._running:
            if self._paused:
                await asyncio.sleep(1)
                continue
            
            # 熔断检查
            if self.consecutive_failures >= self.config.max_consecutive_failures:
                logger.critical(
                    f"Circuit breaker triggered: {self.consecutive_failures} consecutive failures. "
                    f"Cooling down for {self.config.cooldown_after_failure}s"
                )
                await asyncio.sleep(self.config.cooldown_after_failure)
                if self.config.auto_recover:
                    self.consecutive_failures = 0
                    logger.info("Auto-recovering from circuit breaker")
                else:
                    break
            
            # 执行循环
            record = await self.run_cycle()
            self.history.append(record)
            self.cycle_count += 1
            
            # 收敛检查
            if self._check_convergence():
                logger.info(f"Convergence detected after {self.cycle_count} cycles")
                if self.config.max_cycles == 0:
                    # 继续监控但不做动作
                    pass
            
            # Save every completed cycle, including the final cycle.
            if self.config.state_snapshot_dir:
                self._save_snapshot(record)

            if self.config.max_cycles > 0 and self.cycle_count >= self.config.max_cycles:
                logger.info(f"Max cycles ({self.config.max_cycles}) reached")
                break
            
            await asyncio.sleep(self.config.cycle_interval_seconds)
        
        logger.info(f"Agent stopped after {self.cycle_count} cycles")
        self._running = False

    def stop(self) -> None:
        """停止 Agent"""
        self._running = False

    def pause(self) -> None:
        """暂停 Agent"""
        self._paused = True
        self.phase = AgentPhase.PAUSED

    def resume(self) -> None:
        """恢复 Agent"""
        self._paused = False
        self.phase = AgentPhase.IDLE

    def _transition(self, new_phase: AgentPhase) -> None:
        """记录阶段转换"""
        self.phase = new_phase

    def _check_convergence(self) -> bool:
        """检查是否收敛"""
        if len(self.history) < self.config.convergence_cycles:
            return False
        recent = list(self.history)[-self.config.convergence_cycles:]
        for r in recent:
            if r.delta_to_target > self.config.convergence_threshold:
                return False
        return True

    def _calculate_improvement(self, before: WorldState, after: WorldState) -> float:
        """计算状态改进量（正=朝目标移动）"""
        total_improvement = 0.0
        for goal in self.goal_evaluator.goals:
            total_improvement += (
                goal.distance_to_target(before) - goal.distance_to_target(after)
            ) * goal.weight
        return total_improvement

    def _save_snapshot(self, record: CycleRecord) -> None:
        """持久化状态快照"""
        if not self.config.state_snapshot_dir:
            return
        path = Path(self.config.state_snapshot_dir)
        path.mkdir(parents=True, exist_ok=True)
        snapshot = {
            "cycle_id": record.cycle_id,
            "timestamp": record.timestamp.isoformat(),
            "delta_to_target": record.delta_to_target,
            "action_taken": record.action_taken,
            "improvement": record.improvement,
        }
        if record.state_before:
            snapshot["state"] = record.state_before.variables
        filepath = path / f"cycle_{record.cycle_id:05d}.json"
        filepath.write_text(json.dumps(snapshot, indent=2, default=str))

    def status_report(self) -> dict[str, Any]:
        """生成状态报告"""
        return {
            "phase": self.phase.value,
            "cycles_completed": self.cycle_count,
            "consecutive_failures": self.consecutive_failures,
            "observers": len(self.observers),
            "goals": self.goal_evaluator.summary(),
            "constraints": self.constraint_checker.summary(),
            "actions": self.action_selector.summary(),
            "history_size": len(self.history),
            "learning_signals": self.feedback_collector.summary(),
        }
