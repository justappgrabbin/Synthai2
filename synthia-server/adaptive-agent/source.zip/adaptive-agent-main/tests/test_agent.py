"""Safe deterministic tests for the repaired adaptive agent; no host mutations."""
import asyncio
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from actions import ActionResult, ActionSelector
from core import AdaptiveAgent, AgentConfig
from goals import Goal
from state import WorldState, StateObserver

class FakeObserver(StateObserver):
    def __init__(self, initial=0.0):
        super().__init__('mock')
        self.value=initial
    async def observe(self):
        state=WorldState();state.set('progress',self.value);return state

class AdaptiveAgentTests(unittest.TestCase):
    def build(self, **config_overrides):
        c=AgentConfig(cycle_interval_seconds=0,max_cycles=2,**config_overrides)
        a=AdaptiveAgent(c); obs=FakeObserver()
        a.register_observer(obs)
        a.register_goal('progress',2,direction='maximize')
        calls=[]
        def step(state):
            calls.append(1);obs.value+=1;return 'done'
        a.register_action('step',step,expected_benefit=5)
        return a,obs,calls

    def test_default_dry_run_cannot_execute(self):
        a,o,calls=self.build()
        asyncio.run(a.run())
        self.assertEqual(calls,[])
        self.assertEqual(o.value,0)
        self.assertEqual(a.action_weights['step'],1.0)
        self.assertTrue(a.history[0].action_result.side_effects['simulated'])
        self.assertEqual(a.feedback_collector.summary()['action_stats'], {})
        self.assertEqual(a.action_selector.summary()['actions'][0]['success_rate'], 'untried')

    def test_live_requires_explicit_allowlist(self):
        a,o,calls=self.build(execution_mode='live')
        asyncio.run(a.run())
        self.assertEqual(calls,[])
        self.assertEqual(o.value,0)
        self.assertTrue(a.history[0].action_result.side_effects['blocked'])

    def test_live_action_learns_and_converges(self):
        a,o,calls=self.build(execution_mode='live',permitted_actions=('step',))
        asyncio.run(a.run())
        self.assertEqual(len(calls),2)
        self.assertEqual(o.value,2)
        self.assertAlmostEqual(a.action_weights['step'],1.2)
        self.assertAlmostEqual(a.history[-1].delta_to_target,0)
        self.assertAlmostEqual(a.history[-1].improvement,1.0)
        self.assertEqual(a.feedback_collector.summary()['action_stats']['step']['successes'],2)

    def test_default_goal_evaluator_works_without_lambda(self):
        state=WorldState();state.set('progress',1)
        g=Goal('progress',target=2,direction='maximize')
        self.assertEqual(g.distance_to_target(state),1)
        state.set('progress',3)
        self.assertEqual(g.distance_to_target(state),0)
        g2=Goal('progress',target=2,direction='minimize')
        self.assertEqual(g2.distance_to_target(state),1)
        state.set('progress',1)
        self.assertEqual(g2.distance_to_target(state),0)
        g3=Goal('progress',target=2,direction='converge_to')
        self.assertEqual(g3.distance_to_target(state),1)

    def test_explicit_action_failure_is_failure(self):
        state=WorldState(); sel=ActionSelector()
        sel.register('error',lambda _:ActionResult(success=False,error='not done'))
        result=asyncio.run(sel.execute('error',state))
        self.assertFalse(result.success)
        self.assertEqual(sel.registry['error'].failure_count,1)

    def test_nonpositive_score_is_no_action(self):
        a,obs,calls=self.build()
        a.action_selector.registry['step'].cost=100
        asyncio.run(a.run())
        self.assertEqual(a.history[0].action_taken,None)

    def test_last_snapshot_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            a,o,calls=self.build(state_snapshot_dir=tmp)
            asyncio.run(a.run())
            self.assertTrue((Path(tmp)/'cycle_00000.json').exists())
            self.assertTrue((Path(tmp)/'cycle_00001.json').exists())

if __name__=='__main__': unittest.main()
