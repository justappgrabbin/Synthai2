"""
state.py — 世界状态建模与观测器

世界由三类对象构成:
1. 不可压缩的事实 — 可观测变量
2. 可验证的因果 — 状态转换函数
3. 不可证伪的叙事 — 元数据/标签
"""

from __future__ import annotations
import abc
import asyncio
from datetime import datetime
from typing import Any


class WorldState:
    """世界状态的统一表示"""

    def __init__(self):
        self.variables: dict[str, float] = {}        # 数值型状态变量
        self.tags: dict[str, str] = {}                # 标签型状态
        self.events: list[dict[str, Any]] = []        # 近期事件
        self.metadata: dict[str, Any] = {}            # 元数据
        self.timestamp: datetime = datetime.now()

    def set(self, key: str, value: float) -> None:
        """设置状态变量"""
        self.variables[key] = value

    def get(self, key: str, default: float = 0.0) -> float:
        """获取状态变量"""
        return self.variables.get(key, default)

    def tag(self, key: str, value: str) -> None:
        """设置标签"""
        self.tags[key] = value

    def event(self, event_type: str, data: dict[str, Any]) -> None:
        """记录事件"""
        self.events.append({
            "type": event_type,
            "timestamp": datetime.now().isoformat(),
            "data": data,
        })

    def merge(self, other: "WorldState") -> None:
        """合并另一个状态"""
        self.variables.update(other.variables)
        self.tags.update(other.tags)
        self.events.extend(other.events)
        self.metadata.update(other.metadata)

    def to_dict(self) -> dict[str, Any]:
        return {
            "variables": self.variables,
            "tags": self.tags,
            "events": self.events[-20:],  # 最近20条
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat(),
        }

    @property
    def size(self) -> int:
        return len(self.variables)

    def __repr__(self) -> str:
        vars_str = ", ".join(f"{k}={v:.2f}" for k, v in list(self.variables.items())[:5])
        return f"WorldState({vars_str}, +{max(0, len(self.variables)-5)} more)"


class StateObserver(abc.ABC):
    """状态观测器抽象基类 — 观测世界的一个维度"""

    def __init__(self, name: str):
        self.name = name

    @abc.abstractmethod
    async def observe(self) -> WorldState:
        """观察并返回当前状态快照"""
        ...


class SystemResourceObserver(StateObserver):
    """系统资源观测器（CPU/内存/磁盘）"""

    def __init__(self):
        super().__init__("system_resources")

    async def observe(self) -> WorldState:
        import os
        import shutil

        state = WorldState()
        
        try:
            import psutil
            state.set("cpu_percent", psutil.cpu_percent(interval=1))
            mem = psutil.virtual_memory()
            state.set("memory_percent", mem.percent)
            state.set("memory_available_gb", mem.available / (1024**3))
            disk = shutil.disk_usage("/")
            state.set("disk_percent", disk.used / disk.total * 100)
            state.set("disk_free_gb", disk.free / (1024**3))
        except ImportError:
            # fallback: 用 /proc 或内置模块
            state.set("cpu_percent", 0.0)
            disk = shutil.disk_usage("/")
            state.set("disk_percent", disk.used / disk.total * 100)
            state.set("disk_free_gb", disk.free / (1024**3))
        
        return state


class ProcessObserver(StateObserver):
    """进程状态观测器"""

    def __init__(self):
        super().__init__("processes")

    async def observe(self) -> WorldState:
        state = WorldState()
        try:
            import psutil
            state.set("process_count", len(psutil.pids()))
            # 检测僵尸进程
            zombies = sum(1 for p in psutil.process_iter(['status']) 
                         if p.info['status'] == 'zombie')
            state.set("zombie_count", zombies)
        except ImportError:
            import os
            try:
                state.set("process_count", float(len(os.listdir("/proc")) - len(
                    [x for x in os.listdir("/proc") if not x.isdigit()]
                )))
            except:
                state.set("process_count", 0)
        return state


class NetworkObserver(StateObserver):
    """网络状态观测器"""

    def __init__(self, check_host: str = "8.8.8.8"):
        super().__init__("network")
        self.check_host = check_host

    async def observe(self) -> WorldState:
        import subprocess
        state = WorldState()
        
        # 连通性检查
        try:
            result = subprocess.run(
                ["ping", "-c", "1", "-W", "1", self.check_host],
                capture_output=True, text=True, timeout=2
            )
            state.set("network_connected", 1.0 if result.returncode == 0 else 0.0)
        except:
            state.set("network_connected", 0.0)
        
        return state


class DockerObserver(StateObserver):
    """Docker 容器状态观测器"""

    def __init__(self):
        super().__init__("docker")

    async def observe(self) -> WorldState:
        import subprocess
        import json
        state = WorldState()
        
        try:
            result = subprocess.run(
                ["docker", "ps", "--format", "{{json .}}"],
                capture_output=True, text=True, timeout=5
            )
            containers = []
            for line in result.stdout.strip().split("\n"):
                if line:
                    try:
                        containers.append(json.loads(line))
                    except:
                        pass
            
            state.set("container_count", float(len(containers)))
            
            # 检查非运行容器
            exited = sum(1 for c in containers if c.get("Status", "").startswith("Exited"))
            state.set("exited_containers", float(exited))
            
        except FileNotFoundError:
            state.set("container_count", 0.0)
            state.set("exited_containers", 0.0)
        except Exception:
            state.set("container_count", -1.0)
        
        return state


class FileAgeObserver(StateObserver):
    """文件年龄观测器 — 检测过期日志/缓存"""

    def __init__(self, directories: list[str], max_age_hours: float = 24.0):
        super().__init__("file_age")
        self.directories = directories
        self.max_age_hours = max_age_hours

    async def observe(self) -> WorldState:
        import os
        from pathlib import Path
        from datetime import datetime, timezone
        
        state = WorldState()
        now = datetime.now(timezone.utc)
        old_files = 0
        total_size = 0
        
        for directory in self.directories:
            try:
                for filepath in Path(directory).rglob("*"):
                    if filepath.is_file():
                        mtime = datetime.fromtimestamp(filepath.stat().st_mtime, tz=timezone.utc)
                        age_hours = (now - mtime).total_seconds() / 3600
                        if age_hours > self.max_age_hours:
                            old_files += 1
                        total_size += filepath.stat().st_size
            except PermissionError:
                pass
        
        state.set("old_files_count", float(old_files))
        state.set("total_cache_size_mb", total_size / (1024 * 1024))
        return state
