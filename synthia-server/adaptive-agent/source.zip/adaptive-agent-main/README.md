# Adaptive Agent — 在约束内持续把世界状态推向目标状态的自适应系统

> AI Agent 不是模拟人类的程序，而是目标驱动的状态优化系统。

一个从第一性原理构建的自适应 Agent 框架。

## 核心循环

```
Observe → Analyze → Evaluate → Select → Execute → Feedback → (iterate)
```

## 架构

```
┌──────────────────────────────────────────────────────┐
│                  AdaptiveAgent                        │
│                                                      │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────┐   │
│  │ StateObs │  │  Goals   │  │   Constraints     │   │
│  │ CPU/MEM  │  │ minimize │  │ CPU<90% MEM<95%   │   │
│  │ Disk/NET │  │ converge │  │ NET=up DISK<95%   │   │
│  │ Docker   │  │ maximize │  │ no zombies         │   │
│  └────┬─────┘  └────┬─────┘  └────────┬─────────┘   │
│       │             │                 │              │
│       ▼             ▼                 ▼              │
│  ┌──────────────────────────────────────────────┐    │
│  │            Action Selector                    │    │
│  │   score(benefit × success_rate × weight      │    │
│  │         - cost - risk + reversibility)       │    │
│  └────────────────────┬─────────────────────────┘    │
│                       │                               │
│                       ▼                               │
│  ┌──────────────────────────────────────────────┐    │
│  │            Action Executor                    │    │
│  │   kill_heavy | clear_cache | cleanup_disk     │    │
│  │   retry_network | reap_zombies | restart_ctrs │    │
│  └────────────────────┬─────────────────────────┘    │
│                       │                               │
│                       ▼                               │
│  ┌──────────────────────────────────────────────┐    │
│  │          Feedback + Adaptive Learning         │    │
│  │   record → analyze → update_weights → iterate │    │
│  └──────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────┘
```

## 快速开始

```bash
pip install psutil  # 可选，用于精确资源监控
python3 demo.py          # 运行10个循环
python3 demo.py --stress # 压力测试
python3 demo.py --forever # 持续监控
```

## 核心概念

| 概念 | 说明 | 示例 |
|------|------|------|
| **StateObserver** | 观测世界的一个维度 | CPU/内存/网络/容器 |
| **Goal** | 目标函数（最大化/最小化/收敛到） | 系统健康度→最小化 |
| **Constraint** | 硬性/软性约束 | CPU不能超过90% |
| **Action** | 可执行的动作（带成本/风险/收益） | 清理缓存/重启容器 |
| **Feedback** | 动作效果的学习信号 | 动作后状态改进了多少 |
| **Adaptive** | 从反馈中学习最优策略 | 自动调整动作权重 |

## 可扩展性

所有组件都是可插拔的：

```python
# 自定义观测器
class MyObserver(StateObserver):
    async def observe(self) -> WorldState:
        state = WorldState()
        state.set("custom_metric", 42.0)
        return state

# 自定义目标
agent.register_goal("custom", target=100, direction="maximize",
                    evaluate_fn=lambda s: s.get("custom_metric"))

# 自定义约束
agent.register_constraint("custom_check", 
    lambda s: s.get("custom_metric") < 200)

# 自定义动作
agent.register_action("my_action", my_handler,
    cost=1.0, expected_benefit=5.0, risk=0.5)
```

## 设计原则（第一性原理）

1. **目标驱动** — 所有行为由目标函数决定，不是规则堆砌
2. **约束优先** — 硬约束不可违反，软约束在权衡中考虑
3. **反馈闭环** — 每个动作的效果都被记录和学习
4. **自适应** — 权重根据实际效果动态调整
5. **可观测** — 每个循环阶段可追踪、可回溯
6. **最小可验证** — 先做最小动作，快速反馈，再迭代
