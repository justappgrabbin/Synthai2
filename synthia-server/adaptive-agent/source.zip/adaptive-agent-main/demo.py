#!/usr/bin/env python3
"""
demo.py — 自适应Agent演示：系统健康监控与自修复

场景: Agent 持续监控系统状态（CPU/内存/磁盘/网络/容器），
      当检测到异常时自动执行修复动作，并学习哪些动作最有效。

运行:
  python3 demo.py              # 运行10个循环
  python3 demo.py --forever     # 持续运行
  python3 demo.py --stress      # 注入压力测试
"""

from __future__ import annotations
import asyncio
import sys
import os
import signal

# 确保能找到模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core import AdaptiveAgent, AgentConfig
from state import SystemResourceObserver, ProcessObserver, NetworkObserver, DockerObserver
from goals import GoalEvaluator
from constraints import (
    ConstraintChecker,
    cpu_not_overloaded, memory_not_exhausted, disk_not_full,
    network_must_be_up, no_zombie_processes, containers_must_be_running,
)
from actions import (
    ActionSelector,
    kill_heavy_processes, clear_cache, cleanup_disk,
    retry_network, reap_zombies, restart_containers,
)


async def create_demo_agent(live: bool = False, permitted_actions: tuple[str, ...] = ()) -> AdaptiveAgent:
    """创建演示Agent"""
    config = AgentConfig(
        max_cycles=10,
        cycle_interval_seconds=2.0,
        max_consecutive_failures=5,
        cooldown_after_failure=10.0,
        convergence_threshold=0.1,
        convergence_cycles=3,
        auto_recover=True,
        log_level="INFO",
        execution_mode="live" if live else "dry_run",
        permitted_actions=permitted_actions,
    )
    
    agent = AdaptiveAgent(config)
    
    # ---- 注册观测器 ----
    agent.register_observer(SystemResourceObserver())
    agent.register_observer(ProcessObserver())
    agent.register_observer(NetworkObserver())
    agent.register_observer(DockerObserver())
    
    # ---- 注册目标 ----
    # 目标1: 系统负载尽可能低
    agent.register_goal(
        name="system_health",
        target=0.0,
        direction="minimize",
        weight=1.0,
        evaluate_fn=lambda s: (
            s.get("cpu_percent", 0) * 0.35 +
            s.get("memory_percent", 0) * 0.35 +
            s.get("disk_percent", 0) * 0.15 +
            (1 - s.get("network_connected", 1)) * 100 * 0.15
        )
    )
    
    # ---- 注册约束 ----
    agent.register_constraint(
        "cpu_not_overloaded",
        cpu_not_overloaded(threshold=90.0),
        severity="hard",
        message="CPU usage exceeds 90%"
    )
    agent.register_constraint(
        "memory_not_exhausted",
        memory_not_exhausted(threshold=95.0),
        severity="hard",
        message="Memory usage exceeds 95%"
    )
    agent.register_constraint(
        "disk_not_full",
        disk_not_full(threshold=95.0),
        severity="hard",
        message="Disk usage exceeds 95%"
    )
    agent.register_constraint(
        "network_must_be_up",
        network_must_be_up(),
        severity="hard",
        message="Network is down"
    )
    agent.register_constraint(
        "no_zombie_processes",
        no_zombie_processes(),
        severity="soft",
        message="Zombie processes detected"
    )
    agent.register_constraint(
        "containers_must_be_running",
        containers_must_be_running(expected_count=1),
        severity="soft",
        message="Containers not running"
    )
    
    # ---- 注册动作 ----
    agent.register_action(
        "kill_heavy_processes",
        kill_heavy_processes,
        cost=3.0,
        expected_benefit=5.0,
        risk=2.0,
        reversible=False,
    )
    agent.register_action(
        "clear_cache",
        clear_cache,
        cost=0.5,
        expected_benefit=2.0,
        risk=0.2,
        reversible=True,
    )
    agent.register_action(
        "cleanup_disk",
        cleanup_disk,
        cost=0.5,
        expected_benefit=1.5,
        risk=0.1,
        reversible=False,
    )
    agent.register_action(
        "retry_network",
        retry_network,
        cost=0.2,
        expected_benefit=0.5,
        risk=0.1,
        reversible=True,
    )
    agent.register_action(
        "reap_zombies",
        reap_zombies,
        cost=0.3,
        expected_benefit=1.0,
        risk=0.05,
        reversible=True,
    )
    agent.register_action(
        "restart_containers",
        restart_containers,
        cost=1.0,
        expected_benefit=3.0,
        risk=0.5,
        reversible=True,
    )
    
    return agent


async def run_demo(max_cycles: int = 10, live: bool = False,
                   permitted_actions: tuple[str, ...] = ()):
    """运行演示"""
    agent = await create_demo_agent(live, permitted_actions)
    
    if max_cycles > 0:
        agent.config.max_cycles = max_cycles
    
    print("""
╔══════════════════════════════════════════════════════════╗
║  自适应Agent演示 — 系统健康监控与自修复                   ║
║                                                        ║
║  Agent持续监控CPU/内存/磁盘/网络/容器状态                  ║
║  当检测到异常时自动选择最优修复动作                         ║
║  从反馈中学习哪些动作最有效                                ║
╚══════════════════════════════════════════════════════════╝
    """)
    
    def handle_signal(signum, frame):
        print("\n信号接收，正在停止...")
        agent.stop()
    
    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)
    
    try:
        await agent.run()
    except KeyboardInterrupt:
        print("\n用户中断")
    finally:
        # 打印最终报告
        print("\n" + "=" * 60)
        print("最终状态报告")
        print("=" * 60)
        report = agent.status_report()
        
        print(f"阶段: {report['phase']}")
        print(f"循环数: {report['cycles_completed']}")
        print(f"连续失败: {report['consecutive_failures']}")
        print(f"历史记录: {report['history_size']} 条")
        print(f"学习趋势: {report['learning_signals']['trend']}")
        
        if report['learning_signals']['best_actions']:
            print("\n🏆 最有效动作:")
            for name, score in report['learning_signals']['best_actions']:
                print(f"  {name}: avg_improvement={score:.4f}")
        
        if report['learning_signals']['worst_actions']:
            print("\n📉 最无效动作:")
            for name, score in report['learning_signals']['worst_actions']:
                print(f"  {name}: avg_improvement={score:.4f}")
        
        print(f"\n目标: {report['goals']}")
        print(f"约束: {report['constraints']}")
        print(f"动作: {report['actions']}")


async def stress_test():
    """注入压力测试 — 创建临时高负载看Agent如何响应"""
    import subprocess
    import multiprocessing
    
    agent = await create_demo_agent()
    agent.config.max_cycles = 15
    agent.config.cycle_interval_seconds = 1.0
    
    print("""
╔══════════════════════════════════════════════════════════╗
║  压力测试 — 注入CPU负载观察Agent自适应响应                ║
╚══════════════════════════════════════════════════════════╝
    """)
    
    # 启动压力进程（在后台）
    stress_procs = []
    try:
        # 创建一些CPU密集型任务
        print("💥 注入CPU压力...")
        for _ in range(2):
            p = subprocess.Popen(
                ["python3", "-c", "import time; [x**2 for x in range(10**7)]; time.sleep(30)"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            stress_procs.append(p)
        
        await asyncio.sleep(2)
        await agent.run()
        
    except KeyboardInterrupt:
        pass
    finally:
        # 清理压力进程
        for p in stress_procs:
            try:
                p.terminate()
            except:
                pass
        print("\n压力进程已清理")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="自适应Agent演示")
    parser.add_argument("--forever", action="store_true", help="持续运行")
    parser.add_argument("--stress", action="store_true", help="注入压力测试")
    parser.add_argument("--cycles", type=int, default=10, help="运行循环数")
    parser.add_argument("--live", action="store_true", help="Execute authorized actions on host")
    parser.add_argument("--allow-action", action="append", default=[],
                        help="Explicitly allow a named action in live mode; repeat as needed")
    args = parser.parse_args()
    
    if args.forever:
        asyncio.run(run_demo(max_cycles=0, live=args.live,
                             permitted_actions=tuple(args.allow_action)))
    elif args.stress:
        asyncio.run(stress_test())
    else:
        asyncio.run(run_demo(max_cycles=args.cycles, live=args.live,
                             permitted_actions=tuple(args.allow_action)))
