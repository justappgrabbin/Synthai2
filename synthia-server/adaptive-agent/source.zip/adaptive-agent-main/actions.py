"""
actions.py — 动作注册表与选择器

优先处理同时满足以下条件的节点:
- 影响最大
- 成本最低
- 阻塞最强
- 可逆性最高
- 验证最快
"""

from __future__ import annotations
import asyncio
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from state import WorldState
from goals import GoalVerdict
from constraints import ConstraintReport


@dataclass
class ActionResult:
    """动作执行结果"""
    success: bool
    output: Any = None
    error: Optional[str] = None
    duration_ms: float = 0.0
    side_effects: dict[str, Any] = field(default_factory=dict)


@dataclass
class ActionDef:
    """动作定义"""
    name: str
    execute_fn: Callable[[WorldState], Any]  # 同步或异步
    cost: float = 1.0           # 执行成本
    expected_benefit: float = 0.0  # 预期收益
    risk: float = 0.0            # 风险
    reversible: bool = True      # 是否可逆
    success_count: int = 0
    failure_count: int = 0
    total_duration_ms: float = 0.0
    
    @property
    def success_rate(self) -> float:
        total = self.success_count + self.failure_count
        if total == 0:
            return 1.0
        return self.success_count / total


class ActionSelector:
    """动作选择器 — 选择最高预期收益的动作"""

    def __init__(self):
        self.registry: dict[str, ActionDef] = {}
        self.last_scores: dict[str, float] = {}

    def register(self, name: str, execute_fn: Callable,
                 cost: float = 1.0, expected_benefit: float = 0.0,
                 risk: float = 0.0, reversible: bool = True) -> None:
        """注册一个动作"""
        self.registry[name] = ActionDef(
            name=name,
            execute_fn=execute_fn,
            cost=cost,
            expected_benefit=expected_benefit,
            risk=risk,
            reversible=reversible,
        )

    async def execute(self, name: str, state: WorldState) -> ActionResult:
        """执行一个动作"""
        action = self.registry.get(name)
        if not action:
            return ActionResult(success=False, error=f"Action '{name}' not found")
        
        start = time.time()
        try:
            result = action.execute_fn(state)
            if asyncio.iscoroutine(result):
                output = await result
            else:
                output = result
            
            duration = (time.time() - start) * 1000
            if isinstance(output, ActionResult):
                result = output
                result.duration_ms = duration
            else:
                result = ActionResult(success=True, output=output, duration_ms=duration)
            if result.success:
                action.success_count += 1
            else:
                action.failure_count += 1
            action.total_duration_ms += duration
            return result
        except Exception as e:
            duration = (time.time() - start) * 1000
            action.failure_count += 1
            return ActionResult(
                success=False,
                error=str(e),
                duration_ms=duration,
            )

    def select_best(self, state: WorldState, verdict: GoalVerdict,
                    weights: dict[str, float], history: deque) -> Optional[str]:
        """
        选择最优动作。
        
        评分 = 期望收益 × 成功率 × 权重 - 成本 - 风险
        已经收敛时返回 None
        """
        if verdict.converged or not self.registry:
            return None
        
        self.last_scores.clear()
        best_action = None
        best_score = 0.0  # Never select a negative-value action.
        
        for name, action in self.registry.items():
            # 基础分：预期收益
            base = action.expected_benefit * action.success_rate
            
            # 学习权重加成
            learned_weight = weights.get(name, 1.0)
            
            # 风险惩罚
            risk_penalty = action.risk * (1 - action.success_rate)
            
            # 可逆性加成
            reversibility_bonus = 0.5 if action.reversible else 0
            
            score = base * learned_weight - action.cost - risk_penalty + reversibility_bonus
            
            # 如果离目标很远，增加收益权重
            if verdict.normalized_distance > 0.5:
                score *= 1.5
            
            self.last_scores[name] = score
            
            if score > best_score:
                best_score = score
                best_action = name
        
        return best_action

    def select_repair_action(self, violations: ConstraintReport,
                             weights: dict[str, float]) -> Optional[str]:
        """选择修复约束的动作（优先级最高）"""
        # 映射约束到修复动作
        repair_map = {
            "cpu_not_overloaded": "kill_heavy_processes",
            "memory_not_exhausted": "clear_cache",
            "disk_not_full": "cleanup_disk",
            "network_must_be_up": "retry_network",
            "no_zombie_processes": "reap_zombies",
            "containers_must_be_running": "restart_containers",
        }
        
        for violation in violations.hard_violations:
            action_name = repair_map.get(violation["constraint"])
            if action_name and action_name in self.registry:
                return action_name
        
        return None

    def summary(self) -> dict[str, Any]:
        return {
            "action_count": len(self.registry),
            "actions": [
                {
                    "name": a.name,
                    "success_rate": (f"{a.success_rate:.1%}" if
                                     a.success_count + a.failure_count else "untried"),
                    "cost": a.cost,
                    "risk": a.risk,
                    "reversible": a.reversible,
                }
                for a in self.registry.values()
            ]
        }


# ---- 预定义动作函数 ----

import os
import time


def kill_heavy_processes(state: WorldState) -> str:
    """杀死最占资源的进程（谨慎使用）"""
    try:
        import psutil
        procs = []
        for p in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
            try:
                procs.append(p.info)
            except:
                pass
        
        # 找出 CPU 或内存使用最高的非系统进程
        procs.sort(key=lambda x: (x.get('cpu_percent', 0) or 0) + (x.get('memory_percent', 0) or 0), reverse=True)
        
        killed = []
        for p in procs[:3]:
            if p['name'] not in ['systemd', 'init', 'kernel']:
                try:
                    proc = psutil.Process(p['pid'])
                    if proc.cpu_percent() > 80 or proc.memory_percent() > 50:
                        proc.terminate()
                        killed.append(p['name'])
                except:
                    pass
        
        return f"Killed: {killed}" if killed else "No heavy processes to kill"
    except ImportError:
        return "psutil not installed — cannot check processes"


def clear_cache(state: WorldState) -> str:
    """清理系统缓存"""
    import subprocess
    import platform
    
    results = []
    
    try:
        # 清理 apt/pip 缓存
        subprocess.run(["pip", "cache", "purge"], capture_output=True, timeout=30)
        results.append("pip cache cleared")
    except:
        pass
    
    # 清理临时文件
    import tempfile
    import shutil
    try:
        tmp = tempfile.gettempdir()
        count = 0
        for item in os.listdir(tmp):
            try:
                item_path = os.path.join(tmp, item)
                if os.path.isfile(item_path):
                    age = time.time() - os.path.getmtime(item_path)
                    if age > 86400:  # 超过24小时
                        os.unlink(item_path)
                        count += 1
            except:
                pass
        results.append(f"Cleaned {count} temp files")
    except:
        pass
    
    return "; ".join(results) if results else "Nothing to clean"


def cleanup_disk(state: WorldState) -> str:
    """清理磁盘空间"""
    import os
    import time
    
    freed = 0
    patterns = {
        "/tmp/*.log": 0,
        "~/.cache/pip/*": 0,
    }
    
    # 清理旧日志
    try:
        import glob
        for pattern in ["/tmp/*.log", "/tmp/*.tmp"]:
            for f in glob.glob(os.path.expanduser(pattern)):
                try:
                    size = os.path.getsize(f)
                    os.unlink(f)
                    freed += size
                except:
                    pass
    except:
        pass
    
    if freed > 0:
        return f"Freed {freed / (1024**2):.1f} MB"
    return "No files to clean"


def retry_network(state: WorldState) -> str:
    """尝试恢复网络"""
    import subprocess
    
    try:
        result = subprocess.run(
            ["ping", "-c", "1", "-W", "2", "8.8.8.8"],
            capture_output=True, text=True, timeout=3
        )
        if result.returncode == 0:
            return "Network is already working"
        return "Network down — check router/ISP"
    except:
        return "Network check failed"


def reap_zombies(state: WorldState) -> str:
    """清理僵尸进程"""
    try:
        import psutil
        count = 0
        for p in psutil.process_iter(['pid', 'status']):
            if p.info['status'] == 'zombie':
                try:
                    parent = psutil.Process(p.ppid())
                    parent.wait(timeout=1)
                    count += 1
                except:
                    pass
        return f"Reaped {count} zombies"
    except ImportError:
        return "psutil not installed"


def restart_containers(state: WorldState) -> str:
    """重启停止的容器"""
    import subprocess
    import json
    
    try:
        result = subprocess.run(
            ["docker", "ps", "-a", "--format", "{{json .}}"],
            capture_output=True, text=True, timeout=5
        )
        restarted = []
        for line in result.stdout.strip().split("\n"):
            if not line:
                continue
            try:
                c = json.loads(line)
                if "Exited" in c.get("Status", ""):
                    name = c.get("Names", "unknown")
                    subprocess.run(["docker", "start", name], capture_output=True, timeout=30)
                    restarted.append(name)
            except:
                pass
        return f"Restarted: {restarted}" if restarted else "No exited containers"
    except FileNotFoundError:
        return "Docker not installed"
    except Exception as e:
        return f"Failed: {e}"
