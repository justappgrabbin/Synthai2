"""
goals.py — 目标函数与目标评估器

AI Agent 的唯一价值标准：
是否真实降低用户达成目标的成本。

目标函数：要最大化或最小化什么。
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from state import WorldState


@dataclass
class Goal:
    """单个目标的定义"""
    name: str
    target: float  # 目标值
    weight: float = 1.0  # 权重（多目标时）
    direction: str = "maximize"  # maximize | minimize | converge_to
    evaluate_fn: Optional[Callable[[WorldState], float]] = None  # 自定义评估函数
    tolerance: float = 0.01  # 容差
    
    def current_value(self, state: WorldState) -> float:
        """计算当前值"""
        if self.evaluate_fn:
            return self.evaluate_fn(state)
        return state.get(self.name, 0.0)
    
    def distance_to_target(self, state: WorldState) -> float:
        """计算到目标的距离"""
        current = self.current_value(state)
        if self.direction == "maximize":
            return max(0.0, self.target - current)
        if self.direction == "minimize":
            return max(0.0, current - self.target)
        if self.direction == "converge_to":
            return abs(self.target - current)
        raise ValueError(f"unknown goal direction: {self.direction}")
    
    def normalized_distance(self, state: WorldState) -> float:
        """归一化距离（0=达到目标，1=最远）"""
        distance = self.distance_to_target(state)
        return min(distance / max(abs(self.target), 1.0), 1.0)


@dataclass
class GoalVerdict:
    """目标评估结果"""
    goal_name: str
    current_value: float
    target_value: float
    distance_to_target: float
    normalized_distance: float
    direction: str
    converged: bool = False


class GoalEvaluator:
    """目标评估器 — 多目标加权评估"""

    def __init__(self):
        self.goals: list[Goal] = []

    def add_goal(self, name: str, target: float, weight: float = 1.0,
                 direction: str = "maximize",
                 evaluate_fn: Optional[Callable[[WorldState], float]] = None) -> None:
        """添加一个目标"""
        goal = Goal(
            name=name,
            target=target,
            weight=weight,
            direction=direction,
            evaluate_fn=evaluate_fn,
        )
        self.goals.append(goal)

    def evaluate(self, state: WorldState) -> GoalVerdict:
        """评估所有目标，返回聚合结果"""
        if not self.goals:
            return GoalVerdict(
                goal_name="_empty_",
                current_value=0, target_value=0,
                distance_to_target=0, normalized_distance=0,
                direction="maximize", converged=True,
            )
        
        total_weight = sum(g.weight for g in self.goals)
        weighted_distance = 0.0
        weighted_normalized = 0.0
        
        for goal in self.goals:
            dist = goal.distance_to_target(state)
            norm_dist = goal.normalized_distance(state)
            w = goal.weight / total_weight if total_weight > 0 else 1.0
            weighted_distance += dist * w
            weighted_normalized += norm_dist * w
        
        return GoalVerdict(
            goal_name="|".join(g.name for g in self.goals),
            current_value=self.goals[0].current_value(state),
            target_value=self.goals[0].target,
            distance_to_target=weighted_distance,
            normalized_distance=weighted_normalized,
            direction=self.goals[0].direction,
        )

    def evaluate_all(self, state: WorldState) -> list[GoalVerdict]:
        """逐个评估每个目标"""
        return [
            GoalVerdict(
                goal_name=g.name,
                current_value=g.current_value(state),
                target_value=g.target,
                distance_to_target=g.distance_to_target(state),
                normalized_distance=g.normalized_distance(state),
                direction=g.direction,
            )
            for g in self.goals
        ]

    def summary(self) -> dict[str, Any]:
        return {
            "goal_count": len(self.goals),
            "goals": [
                {"name": g.name, "target": g.target, "direction": g.direction, "weight": g.weight}
                for g in self.goals
            ]
        }
