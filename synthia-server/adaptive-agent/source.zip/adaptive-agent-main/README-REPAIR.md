# Adaptive Agent — repaired copy of your uploaded archive

The archive's original implementation is **preserved verbatim** as `original-upload.zip` alongside this repaired project.

## What this artifact is
An adaptive observe/evaluate/act/feedback agent framework. It is **not** a conversational language model or Synthia itself. To use with Computer, an adapter to the current Computer action registry, state sources, and authorization model is still required.

## Changes to existing code
- Initialize action weights when actions are registered, allowing feedback to update them.
- Calculate improvement from the change in goal distance, supporting both goals backed by state variables and goals with custom evaluators.
- Use correct direction-specific goal distances and normalized distances.
- Write `CycleRecord.improvement`; save a snapshot even for the final cycle.
- Respect explicit `ActionResult` failures returned from action handlers.
- Avoid selecting actions with nonpositive utility scores.
- **Default to dry-run mode**: merely invoking the demo no longer terminates processes, deletes temporary files, or restarts containers.
- For live execution, require both `execution_mode="live"` and a per-action allowlist in `AgentConfig.permitted_actions`. This is only a basic execution gate, NOT user identity or operation-level authorization. Integrate with Computer's actual authorization prior to production deployment.
- Treat blocked and simulated actions as non-executions, so they cannot spuriously train action weights or count as action failures. Untried action success rates are labeled `untried`, not 100%.

## Safe quick check
```
python3 -m unittest discover -s tests -v
python3 demo.py --cycles 1
```
Optional `psutil` helps observe host resource metrics. Network/Docker observer failure is handled in the demo. The demo's monitoring probes may call `ping` or `docker ps`, and `--stress` deliberately starts load-generating processes. Do not run `--stress` unless intended.

## Explicit live mode (not recommended until audited for your environment)
```
python3 demo.py --live --allow-action retry_network --cycles 1
```
Note: `retry_network` invokes a diagnostic ping, not a network repair. Other bundled example handlers may delete cache/temp files, terminate processes or start Docker containers; do not allow them on production hosts without a reviewed resource scope and approval workflow.

## Limits and integration boundary
- Adaptive weights are heuristic, not neural learning.
- No conversation interface, model weights, tenant identity, persistence of learned weights, distributed task queue, or Computer connector yet.
- `ActionSelector.select_repair_action` uses static names for six demo cases; a production Computer bridge should use semantic capabilities/resource identities and a policy-aware action planner.
- Live approval policy is a simple allowlist. It does not verify operation targets. Never expose live mode to untrusted input.
