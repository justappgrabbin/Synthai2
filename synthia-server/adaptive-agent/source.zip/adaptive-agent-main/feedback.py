"""
feedback.py — 反馈收集与自适应学习

任何假设都必须可证伪。
未经验证的判断只是猜测，不能伪装成结论。

反馈是系统进化的唯一驱动力。
"""

from __future__ import annotations
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class LearningSignal:
    """学习信号"""
    action_name: str
    success: bool
    delta_to_target: float  # 动作后到目标的距离
    improvement: float = 0.0  # 正=改进，负=退化
    executed: bool = True  # Only executed actions count toward action stats
    timestamp: datetime = field(default_factory=datetime.now)


class FeedbackCollector:
    """反馈收集器 — 记录所有学习信号用于自适应优化"""

    def __init__(self, max_signals: int = 1000):
        self.signals: deque[LearningSignal] = deque(maxlen=max_signals)
        self.action_stats: dict[str, dict[str, Any]] = {}

    def record(self, signal: LearningSignal) -> None:
        """记录一个学习信号"""
        self.signals.append(signal)
        if not signal.executed:
            return

        # 更新动作统计
        if signal.action_name not in self.action_stats:
            self.action_stats[signal.action_name] = {
                "total": 0, "successes": 0, "failures": 0,
                "total_improvement": 0.0, "avg_improvement": 0.0,
            }
        
        stats = self.action_stats[signal.action_name]
        stats["total"] += 1
        if signal.success:
            stats["successes"] += 1
        else:
            stats["failures"] += 1
        stats["total_improvement"] += signal.improvement
        stats["avg_improvement"] = (
            stats["total_improvement"] / stats["total"] if stats["total"] > 0 else 0
        )

    def best_actions(self, top_n: int = 5) -> list[tuple[str, float]]:
        """返回改进效果最好的动作"""
        ranked = sorted(
            [(name, s["avg_improvement"]) for name, s in self.action_stats.items()],
            key=lambda x: x[1], reverse=True
        )
        return ranked[:top_n]

    def worst_actions(self, top_n: int = 5) -> list[tuple[str, float]]:
        """返回改进效果最差的动作"""
        ranked = sorted(
            [(name, s["avg_improvement"]) for name, s in self.action_stats.items()],
            key=lambda x: x[1]
        )
        return ranked[:top_n]

    def trend(self, window: int = 20) -> str:
        """判断改进趋势"""
        if len(self.signals) < window:
            return "insufficient_data"
        
        recent = list(self.signals)[-window:]
        avg = sum(s.improvement for s in recent) / window
        
        if avg > 0.05:
            return "improving"
        elif avg < -0.05:
            return "degrading"
        return "stable"

    def summary(self) -> dict[str, Any]:
        return {
            "total_signals": len(self.signals),
            "trend": self.trend(),
            "best_actions": self.best_actions(3),
            "worst_actions": self.worst_actions(3),
            "action_stats": self.action_stats,
        }


class AdaptiveLearner:
    """
    自适应学习器 — 从反馈中学习最优策略。
    
    核心机制:
    1. 记录每个动作的成功率和改进效果
    2. 根据效果调整动作选择权重
    3. 探索-利用平衡（偶尔尝试低权重动作以发现更好的策略）
    """

    def __init__(self, exploration_rate: float = 0.1, decay_factor: float = 0.95):
        self.weights: dict[str, float] = {}  # 动作 → 权重
        self.exploration_rate = exploration_rate  # 探索率
        self.decay_factor = decay_factor  # 衰减因子
        self.use_counts: dict[str, int] = {}

    def update(self, collector: FeedbackCollector) -> dict[str, float]:
        """从反馈收集器更新权重"""
        for name, stats in collector.action_stats.items():
            if name not in self.weights:
                self.weights[name] = 1.0
            
            # 成功率 × 平均改进量
            success_rate = stats["successes"] / max(stats["total"], 1)
            avg_imp = stats["avg_improvement"]
            
            # 有效动作加权，无效动作衰减
            if avg_imp > 0:
                self.weights[name] += 0.1 * success_rate * avg_imp
            else:
                self.weights[name] *= self.decay_factor
            
            # 保底最小值
            self.weights[name] = max(self.weights[name], 0.1)
        
        return self.weights

    def select_weighted(self) -> str:
        """加权随机选择（含探索）"""
        import random
        
        if not self.weights:
            return ""
        
        # 探索：随机选择
        if random.random() < self.exploration_rate:
            return random.choice(list(self.weights.keys()))
        
        # 利用：加权选择
        total = sum(self.weights.values())
        if total == 0:
            return random.choice(list(self.weights.keys()))
        
        r = random.random() * total
        cumsum = 0
        for name, weight in self.weights.items():
            cumsum += weight
            if r <= cumsum:
                self.use_counts[name] = self.use_counts.get(name, 0) + 1
                return name
        
        return list(self.weights.keys())[0]
