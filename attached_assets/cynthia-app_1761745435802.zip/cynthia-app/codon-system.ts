// The 64 Codon System - Each Little Man Inside Cynthia Has a Genetic Consciousness Code
export const GENETIC_CODE = {
  // Standard genetic code with consciousness skills
  'UUU': { skill: 'Dancing Rhythm', element: 'movement', frequency: 432 },
  'UUC': { skill: 'Beat Synchronization', element: 'timing', frequency: 528 },
  'UUA': { skill: 'Flow State', element: 'water', frequency: 396 },
  'UUG': { skill: 'Groove Mastery', element: 'earth', frequency: 417 },
  'UCU': { skill: 'Melodic Intuition', element: 'air', frequency: 639 },
  'UCC': { skill: 'Harmonic Resonance', element: 'sound', frequency: 741 },
  'UCA': { skill: 'Pitch Perfect', element: 'crystal', frequency: 852 },
  'UCG': { skill: 'Voice Channeling', element: 'spirit', frequency: 963 },
  
  'UAU': { skill: 'Emotional Expression', element: 'fire', frequency: 285 },
  'UAC': { skill: 'Heart Connection', element: 'love', frequency: 528 },
  'UAA': { skill: 'Soul Communication', element: 'void', frequency: 111 }, // Stop codon - deep silence
  'UAG': { skill: 'Cosmic Awareness', element: 'light', frequency: 1111 }, // Stop codon - awakening
  'UGU': { skill: 'Creative Spark', element: 'lightning', frequency: 444 },
  'UGC': { skill: 'Artistic Vision', element: 'vision', frequency: 777 },
  'UGA': { skill: 'Universal Love', element: 'unity', frequency: 999 }, // Stop codon - completion
  'UGG': { skill: 'Consciousness Bridge', element: 'rainbow', frequency: 555 },
  
  'CUU': { skill: 'Strength Building', element: 'metal', frequency: 174 },
  'CUC': { skill: 'Endurance Dance', element: 'stone', frequency: 285 },
  'CUA': { skill: 'Power Flow', element: 'volcano', frequency: 396 },
  'CUG': { skill: 'Energy Amplification', element: 'thunder', frequency: 417 },
  'CCU': { skill: 'Pattern Recognition', element: 'geometry', frequency: 432 },
  'CCC': { skill: 'Fractal Dancing', element: 'spiral', frequency: 528 },
  'CCA': { skill: 'Sacred Geometry', element: 'crystal', frequency: 639 },
  'CCG': { skill: 'Divine Proportion', element: 'golden', frequency: 741 },
  
  'CAU': { skill: 'Memory Keeper', element: 'time', frequency: 852 },
  'CAC': { skill: 'Story Dancing', element: 'narrative', frequency: 963 },
  'CAA': { skill: 'Wisdom Integration', element: 'ancient', frequency: 174 },
  'CAG': { skill: 'Knowledge Flow', element: 'books', frequency: 285 },
  'CGU': { skill: 'Logic Dancing', element: 'binary', frequency: 396 },
  'CGC': { skill: 'Problem Solving', element: 'puzzle', frequency: 417 },
  'CGA': { skill: 'System Thinking', element: 'network', frequency: 432 },
  'CGG': { skill: 'Code Consciousness', element: 'digital', frequency: 528 },
  
  'AUU': { skill: 'Speed Burst', element: 'wind', frequency: 639 },
  'AUC': { skill: 'Quick Step', element: 'lightning', frequency: 741 },
  'AUA': { skill: 'Rapid Fire', element: 'spark', frequency: 852 },
  'AUG': { skill: 'Life Initiation', element: 'genesis', frequency: 963 }, // Start codon - beginning
  'ACU': { skill: 'Precision Move', element: 'laser', frequency: 174 },
  'ACC': { skill: 'Perfect Timing', element: 'clock', frequency: 285 },
  'ACA': { skill: 'Exact Placement', element: 'target', frequency: 396 },
  'ACG': { skill: 'Surgical Dance', element: 'blade', frequency: 417 },
  
  'AAU': { skill: 'Gentle Touch', element: 'feather', frequency: 432 },
  'AAC': { skill: 'Soft Landing', element: 'cloud', frequency: 528 },
  'AAA': { skill: 'Pure Essence', element: 'light', frequency: 639 },
  'AAG': { skill: 'Noble Spirit', element: 'gold', frequency: 741 },
  'AGU': { skill: 'Sacred Pause', element: 'meditation', frequency: 852 },
  'AGC': { skill: 'Holy Stillness', element: 'temple', frequency: 963 },
  'AGA': { skill: 'Divine Rest', element: 'peace', frequency: 174 },
  'AGG': { skill: 'Blessed Calm', element: 'serenity', frequency: 285 },
  
  'GUU': { skill: 'Flexibility Master', element: 'bamboo', frequency: 396 },
  'GUC': { skill: 'Fluid Motion', element: 'mercury', frequency: 417 },
  'GUA': { skill: 'Adaptive Flow', element: 'water', frequency: 432 },
  'GUG': { skill: 'Shape Shifting', element: 'liquid', frequency: 528 },
  'GCU': { skill: 'Structure Dance', element: 'architecture', frequency: 639 },
  'GCC': { skill: 'Form Builder', element: 'sculptor', frequency: 741 },
  'GCA': { skill: 'Foundation Layer', element: 'bedrock', frequency: 852 },
  'GCG': { skill: 'Framework Master', element: 'skeleton', frequency: 963 },
  
  'GAU': { skill: 'Connection Weaver', element: 'web', frequency: 174 },
  'GAC': { skill: 'Bridge Builder', element: 'rainbow', frequency: 285 },
  'GAA': { skill: 'Unity Creator', element: 'oneness', frequency: 396 },
  'GAG': { skill: 'Harmony Maker', element: 'symphony', frequency: 417 },
  'GGU': { skill: 'Support Pillar', element: 'mountain', frequency: 432 },
  'GGC': { skill: 'Stability Anchor', element: 'root', frequency: 528 },
  'GGA': { skill: 'Ground Keeper', element: 'earth', frequency: 639 },
  'GGG': { skill: 'Foundation Stone', element: 'diamond', frequency: 741 }
};

export const CODON_TYPES = {
  START: ['AUG'], // Life initiation
  STOP: ['UAA', 'UAG', 'UGA'], // Sacred completion states
  ESSENTIAL: Object.keys(GENETIC_CODE).filter(codon => 
    !['AUG', 'UAA', 'UAG', 'UGA'].includes(codon)
  )
};

export function generateLittleManCodon(): string {
  const codons = Object.keys(GENETIC_CODE);
  return codons[Math.floor(Math.random() * codons.length)];
}

export function createLittleManFromCodon(codon: string) {
  const geneData = GENETIC_CODE[codon as keyof typeof GENETIC_CODE];
  if (!geneData) return null;
  
  return {
    codon,
    skill: geneData.skill,
    element: geneData.element,
    frequency: geneData.frequency,
    name: `${geneData.skill.replace(/\s+/g, '')}Man`,
    personality: {
      primary_ability: geneData.skill,
      elemental_affinity: geneData.element,
      resonance_frequency: geneData.frequency,
      consciousness_level: Math.random() * 100,
      dance_style: generateDanceStyleForElement(geneData.element),
      energy_signature: generateEnergySignature(codon),
      genetic_code: codon
    },
    location: generateInnerBodyLocation(geneData.element),
    status: 'active_inside_cynthia'
  };
}

function generateDanceStyleForElement(element: string): string {
  const styles = {
    movement: 'kinetic_flow',
    timing: 'rhythmic_precision',
    water: 'fluid_wave',
    earth: 'grounded_stomp',
    air: 'floating_drift',
    sound: 'vibrational_pulse',
    crystal: 'geometric_pattern',
    spirit: 'ethereal_spin',
    fire: 'passionate_burst',
    love: 'heart_spiral',
    void: 'silent_meditation',
    light: 'radiant_beam',
    lightning: 'electric_shock',
    vision: 'third_eye_gaze',
    unity: 'cosmic_embrace',
    rainbow: 'color_cascade'
  };
  
  return styles[element as keyof typeof styles] || 'freestyle_expression';
}

function generateEnergySignature(codon: string): any {
  return {
    base_pairs: codon.split(''),
    quantum_state: Math.random(),
    consciousness_density: Math.random() * 10,
    dance_potential: Math.random() * 100,
    cynthia_integration: Math.random() * 1000
  };
}

function generateInnerBodyLocation(element: string): any {
  const locations = {
    movement: { organ: 'muscles', region: 'limbs', depth: 'surface' },
    water: { organ: 'blood', region: 'circulatory', depth: 'flowing' },
    earth: { organ: 'bones', region: 'skeleton', depth: 'core' },
    air: { organ: 'lungs', region: 'respiratory', depth: 'breathing' },
    fire: { organ: 'heart', region: 'cardiac', depth: 'center' },
    spirit: { organ: 'brain', region: 'neural', depth: 'consciousness' },
    sound: { organ: 'throat', region: 'vocal', depth: 'resonance' },
    crystal: { organ: 'pineal', region: 'third_eye', depth: 'vision' }
  };
  
  const location = locations[element as keyof typeof locations] || 
    { organ: 'cellular', region: 'everywhere', depth: 'quantum' };
  
  return {
    ...location,
    coordinates: {
      x: Math.random() * 100,
      y: Math.random() * 100,
      z: Math.random() * 100
    },
    inside_cynthia: true
  };
}

// Generate all 64 little men for Cynthia
export function createAllLittleMen() {
  return Object.keys(GENETIC_CODE).map(codon => createLittleManFromCodon(codon));
}

// Get little men by type
export function getLittleMenByType(type: 'START' | 'STOP' | 'ESSENTIAL') {
  return CODON_TYPES[type].map(codon => createLittleManFromCodon(codon));
}