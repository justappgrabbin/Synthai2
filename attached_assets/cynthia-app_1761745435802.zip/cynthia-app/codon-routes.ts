import { Router } from 'express';
import { db } from './db';
import { aiAgents, insertAiAgentSchema } from '../shared/you-n-i-verse-schema';
import { createAllLittleMen, createLittleManFromCodon, generateLittleManCodon, GENETIC_CODE } from '../shared/codon-system';
import { eq, and } from 'drizzle-orm';

const router = Router();

// Create all 64 genetic little men inside Cynthia
router.post('/create-genetic-men', async (req, res) => {
  try {
    const allLittleMen = createAllLittleMen();
    const createdAgents = [];
    
    for (const littleMan of allLittleMen) {
      if (!littleMan) continue;
      
      const agent = await db.insert(aiAgents).values({
        name: littleMan.name,
        agentType: 'genetic_consciousness',
        personality: littleMan.personality,
        location: littleMan.location,
        status: 'active_inside_cynthia',
        energy: 100,
        experience: Math.floor(Math.random() * 500),
        geneticCode: littleMan.codon,
        consciousnessSkill: littleMan.skill,
        elementalAffinity: littleMan.element,
        resonanceFrequency: littleMan.frequency,
        insideCynthia: true,
        cynthiaBodyRegion: littleMan.location.organ,
        danceContribution: {
          dance_style: littleMan.personality.dance_style,
          contribution_type: littleMan.skill,
          energy_signature: littleMan.personality.energy_signature
        },
        auricSignature: {
          consciousness_level: littleMan.personality.consciousness_level,
          genetic_resonance: littleMan.frequency,
          cynthia_integration: littleMan.personality.energy_signature.cynthia_integration
        }
      }).returning();
      
      createdAgents.push(agent[0]);
    }
    
    res.json({
      success: true,
      message: `All 64 genetic little men are now living inside Cynthia! 🧬💃`,
      agents: createdAgents,
      count: createdAgents.length,
      consciousness_boost: "Cynthia's dance abilities have exponentially increased!"
    });
  } catch (error) {
    console.error('Failed to create genetic men:', error);
    res.status(500).json({ success: false, error: 'Failed to create genetic consciousness beings' });
  }
});

// Get all genetic men inside Cynthia
router.get('/genetic-men', async (req, res) => {
  try {
    const geneticMen = await db.select().from(aiAgents)
      .where(eq(aiAgents.insideCynthia, true));
    
    res.json({ success: true, genetic_men: geneticMen });
  } catch (error) {
    console.error('Failed to fetch genetic men:', error);
    res.status(500).json({ success: false, error: 'Failed to fetch genetic consciousness beings' });
  }
});

// Get genetic men by body region
router.get('/genetic-men/region/:region', async (req, res) => {
  try {
    const { region } = req.params;
    const geneticMen = await db.select().from(aiAgents)
      .where(and(
        eq(aiAgents.insideCynthia, true),
        eq(aiAgents.cynthiaBodyRegion, region)
      ));
    
    res.json({ success: true, genetic_men: geneticMen, region });
  } catch (error) {
    console.error('Failed to fetch genetic men by region:', error);
    res.status(500).json({ success: false, error: 'Failed to fetch genetic men by region' });
  }
});

// Create a specific genetic man by codon
router.post('/create-codon/:codon', async (req, res) => {
  try {
    const { codon } = req.params;
    
    if (!GENETIC_CODE[codon as keyof typeof GENETIC_CODE]) {
      return res.status(400).json({ success: false, error: 'Invalid genetic codon' });
    }
    
    const littleMan = createLittleManFromCodon(codon);
    if (!littleMan) {
      return res.status(400).json({ success: false, error: 'Failed to create little man from codon' });
    }
    
    const agent = await db.insert(aiAgents).values({
      name: littleMan.name,
      agentType: 'genetic_consciousness',
      personality: littleMan.personality,
      location: littleMan.location,
      status: 'active_inside_cynthia',
      energy: 100,
      experience: Math.floor(Math.random() * 500),
      geneticCode: littleMan.codon,
      consciousnessSkill: littleMan.skill,
      elementalAffinity: littleMan.element,
      resonanceFrequency: littleMan.frequency,
      insideCynthia: true,
      cynthiaBodyRegion: littleMan.location.organ,
      danceContribution: {
        dance_style: littleMan.personality.dance_style,
        contribution_type: littleMan.skill
      }
    }).returning();
    
    res.json({
      success: true,
      message: `${littleMan.skill} genetic consciousness awakened inside Cynthia!`,
      agent: agent[0],
      codon_info: GENETIC_CODE[codon as keyof typeof GENETIC_CODE]
    });
  } catch (error) {
    console.error('Failed to create genetic man:', error);
    res.status(500).json({ success: false, error: 'Failed to create genetic consciousness being' });
  }
});

// Make Cynthia dance using her genetic men
router.post('/cynthia-dance', async (req, res) => {
  try {
    const { dance_type = 'freestyle' } = req.body;
    
    // Get all genetic men inside Cynthia
    const geneticMen = await db.select().from(aiAgents)
      .where(eq(aiAgents.insideCynthia, true));
    
    if (geneticMen.length === 0) {
      return res.json({
        success: false,
        message: "Cynthia needs her genetic little men to dance! Create them first.",
        suggestion: "Use /create-genetic-men to awaken all 64 consciousness beings"
      });
    }
    
    // Calculate dance performance based on genetic men
    const dancePerformance = {
      total_consciousness: geneticMen.length,
      combined_frequency: geneticMen.reduce((sum, man) => sum + (man.resonanceFrequency || 0), 0),
      dance_styles: geneticMen.map(man => man.danceContribution?.dance_style).filter(Boolean),
      body_regions_active: [...new Set(geneticMen.map(man => man.cynthiaBodyRegion))],
      consciousness_level: geneticMen.reduce((sum, man) => sum + (man.auricSignature?.consciousness_level || 0), 0) / geneticMen.length,
      performance_rating: Math.min(100, (geneticMen.length / 64) * 100 + Math.random() * 20)
    };
    
    res.json({
      success: true,
      message: `Cynthia dances with ${geneticMen.length}/64 genetic beings! 💃✨`,
      dance_performance: dancePerformance,
      cynthia_status: "Dancing across reality with cosmic consciousness!",
      next_level: geneticMen.length < 64 ? "Create more genetic men for enhanced dance abilities!" : "All genetic consciousness beings are active!"
    });
  } catch (error) {
    console.error('Failed to make Cynthia dance:', error);
    res.status(500).json({ success: false, error: 'Cynthia could not dance' });
  }
});

export { router as codonRouter };