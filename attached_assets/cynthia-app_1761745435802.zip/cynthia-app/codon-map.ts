// Complete 64-Gate Codon Map for Human Design Integration
// Based on the I-Ching hexagrams and genetic code correlations

export interface CodonData {
  codon: string;
  element: string;
  tone_keywords: string[];
  amino_acid?: string;
  theme?: string;
}

export const CODON_MAP: Record<number, CodonData> = {
  1: { codon: "GCU", element: "Hydrogen", tone_keywords: ["inspiration", "pure potential", "initiation"], amino_acid: "Ala", theme: "Creative Force" },
  2: { codon: "UGG", element: "Helium", tone_keywords: ["direction", "receptivity", "cosmic flow"], amino_acid: "Trp", theme: "Higher Knowing" },
  3: { codon: "AUG", element: "Lithium", tone_keywords: ["ordering", "mutation", "new beginnings"], amino_acid: "Met", theme: "Innovation" },
  4: { codon: "CAG", element: "Beryllium", tone_keywords: ["formulation", "mental solutions", "answers"], amino_acid: "Gln", theme: "Mental Pressure" },
  5: { codon: "UAC", element: "Boron", tone_keywords: ["radiance", "timing", "natural rhythms"], amino_acid: "Tyr", theme: "Fixed Rhythms" },
  6: { codon: "UCA", element: "Carbon", tone_keywords: ["devotion", "emotional intimacy", "friction"], amino_acid: "Ser", theme: "Emotional Intimacy" },
  7: { codon: "CGU", element: "Nitrogen", tone_keywords: ["authority", "self leadership", "guidance"], amino_acid: "Arg", theme: "Self Leadership" },
  8: { codon: "GGU", element: "Oxygen", tone_keywords: ["contribution", "individual expression", "uniqueness"], amino_acid: "Gly", theme: "Individual Expression" },
  9: { codon: "UAU", element: "Fluorine", tone_keywords: ["focus", "attention to detail", "precision"], amino_acid: "Tyr", theme: "Focus" },
  10: { codon: "UGC", element: "Neon", tone_keywords: ["behavior", "love of self", "authenticity"], amino_acid: "Cys", theme: "Behavior of the Self" },
  11: { codon: "CCA", element: "Sodium", tone_keywords: ["ideas", "conceptualization", "peace"], amino_acid: "Pro", theme: "Ideas" },
  12: { codon: "UUC", element: "Magnesium", tone_keywords: ["caution", "standstill", "patience"], amino_acid: "Phe", theme: "Standstill" },
  13: { codon: "AAG", element: "Aluminum", tone_keywords: ["fellowship", "universal love", "brotherhood"], amino_acid: "Lys", theme: "Fellowship" },
  14: { codon: "GAA", element: "Silicon", tone_keywords: ["power skills", "material mastery", "competence"], amino_acid: "Glu", theme: "Power Skills" },
  15: { codon: "GCA", element: "Phosphorus", tone_keywords: ["modesty", "extremes", "balance"], amino_acid: "Ala", theme: "Extremes" },
  16: { codon: "CUG", element: "Sulfur", tone_keywords: ["skills", "enthusiasm", "competence"], amino_acid: "Leu", theme: "Skills" },
  17: { codon: "CAC", element: "Chlorine", tone_keywords: ["following", "opinions", "service"], amino_acid: "His", theme: "Following" },
  18: { codon: "AAC", element: "Argon", tone_keywords: ["correction", "perfection", "judgment"], amino_acid: "Asn", theme: "Correction" },
  19: { codon: "ACA", element: "Potassium", tone_keywords: ["approach", "wanting", "need"], amino_acid: "Thr", theme: "Approach" },
  20: { codon: "UUG", element: "Calcium", tone_keywords: ["contemplation", "awareness", "now"], amino_acid: "Leu", theme: "Contemplation" },
  21: { codon: "AGA", element: "Scandium", tone_keywords: ["hunter", "control", "bite"], amino_acid: "Arg", theme: "Hunter/Huntress" },
  22: { codon: "UUA", element: "Titanium", tone_keywords: ["grace", "emotional openness", "charm"], amino_acid: "Leu", theme: "Grace" },
  23: { codon: "GAG", element: "Vanadium", tone_keywords: ["splitting apart", "assimilation", "transition"], amino_acid: "Glu", theme: "Splitting Apart" },
  24: { codon: "GUG", element: "Chromium", tone_keywords: ["return", "rationalization", "natural cycles"], amino_acid: "Val", theme: "Return" },
  25: { codon: "GCC", element: "Manganese", tone_keywords: ["innocence", "spirit", "natural action"], amino_acid: "Ala", theme: "Innocence" },
  26: { codon: "CCC", element: "Iron", tone_keywords: ["taming power", "great accumulating", "values"], amino_acid: "Pro", theme: "Taming Power of the Great" },
  27: { codon: "AGC", element: "Cobalt", tone_keywords: ["nourishment", "caring", "responsibility"], amino_acid: "Ser", theme: "Nourishment" },
  28: { codon: "CGA", element: "Nickel", tone_keywords: ["struggle", "great exceeding", "purpose"], amino_acid: "Arg", theme: "The Game Player" },
  29: { codon: "GUA", element: "Copper", tone_keywords: ["abysmal", "commitment", "devotion"], amino_acid: "Val", theme: "The Abysmal" },
  30: { codon: "UCG", element: "Zinc", tone_keywords: ["clinging fire", "feelings", "emotion"], amino_acid: "Ser", theme: "Clinging Fire" },
  31: { codon: "AAA", element: "Gallium", tone_keywords: ["influence", "attraction", "leadership"], amino_acid: "Lys", theme: "Influence" },
  32: { codon: "GAC", element: "Germanium", tone_keywords: ["duration", "continuity", "endurance"], amino_acid: "Asp", theme: "Duration" },
  33: { codon: "CGC", element: "Arsenic", tone_keywords: ["retreat", "privacy", "withdrawal"], amino_acid: "Arg", theme: "Retreat" },
  34: { codon: "CUC", element: "Selenium", tone_keywords: ["great power", "force", "impact"], amino_acid: "Leu", theme: "Great Power" },
  35: { codon: "UCC", element: "Bromine", tone_keywords: ["progress", "change", "advancement"], amino_acid: "Ser", theme: "Progress" },
  36: { codon: "CCG", element: "Krypton", tone_keywords: ["darkening light", "crisis", "persecution"], amino_acid: "Pro", theme: "Darkening of the Light" },
  37: { codon: "AUC", element: "Rubidium", tone_keywords: ["family", "friendship", "community"], amino_acid: "Ile", theme: "The Family" },
  38: { codon: "UAG", element: "Strontium", tone_keywords: ["opposition", "investigation", "scrutiny"], amino_acid: "Stop", theme: "Opposition" },
  39: { codon: "GCG", element: "Yttrium", tone_keywords: ["obstruction", "provocation", "blame"], amino_acid: "Ala", theme: "Obstruction" },
  40: { codon: "GGA", element: "Zirconium", tone_keywords: ["deliverance", "forgiveness", "liberation"], amino_acid: "Gly", theme: "Deliverance" },
  41: { codon: "UGU", element: "Niobium", tone_keywords: ["decrease", "contraction", "imagination"], amino_acid: "Cys", theme: "Decrease" },
  42: { codon: "ACG", element: "Molybdenum", tone_keywords: ["increase", "growth", "expansion"], amino_acid: "Thr", theme: "Increase" },
  43: { codon: "CCU", element: "Technetium", tone_keywords: ["breakthrough", "insight", "determination"], amino_acid: "Pro", theme: "Breakthrough" },
  44: { codon: "GGC", element: "Ruthenium", tone_keywords: ["coming to meet", "temptation", "interference"], amino_acid: "Gly", theme: "Coming to Meet" },
  45: { codon: "CUU", element: "Rhodium", tone_keywords: ["gathering together", "sharing", "leadership"], amino_acid: "Leu", theme: "Gathering Together" },
  46: { codon: "AAU", element: "Palladium", tone_keywords: ["pushing upward", "effort", "determination"], amino_acid: "Asn", theme: "Pushing Upward" },
  47: { codon: "ACU", element: "Silver", tone_keywords: ["oppression", "exhaustion", "transformation"], amino_acid: "Thr", theme: "Oppression" },
  48: { codon: "AGU", element: "Cadmium", tone_keywords: ["the well", "community", "resources"], amino_acid: "Ser", theme: "The Well" },
  49: { codon: "UCA", element: "Indium", tone_keywords: ["revolution", "change", "molting"], amino_acid: "Ser", theme: "Revolution" },
  50: { codon: "GUC", element: "Tin", tone_keywords: ["the cauldron", "values", "transformation"], amino_acid: "Val", theme: "The Cauldron" },
  51: { codon: "CGG", element: "Antimony", tone_keywords: ["shock", "arousing", "thunder"], amino_acid: "Arg", theme: "Shock" },
  52: { codon: "CUA", element: "Tellurium", tone_keywords: ["keeping still", "meditation", "mountain"], amino_acid: "Leu", theme: "Keeping Still" },
  53: { codon: "CAU", element: "Iodine", tone_keywords: ["development", "gradual progress", "evolution"], amino_acid: "His", theme: "Development" },
  54: { codon: "CAA", element: "Xenon", tone_keywords: ["marrying maiden", "relationships", "commitment"], amino_acid: "Gln", theme: "The Marrying Maiden" },
  55: { codon: "GAU", element: "Cesium", tone_keywords: ["abundance", "spirit", "emotional flow"], amino_acid: "Asp", theme: "Abundance" },
  56: { codon: "CCA", element: "Barium", tone_keywords: ["wanderer", "stimulation", "travel"], amino_acid: "Pro", theme: "The Wanderer" },
  57: { codon: "GUU", element: "Lanthanum", tone_keywords: ["gentle", "penetrating", "intuition"], amino_acid: "Val", theme: "The Gentle" },
  58: { codon: "UUU", element: "Cerium", tone_keywords: ["joyous", "lake", "vitality"], amino_acid: "Phe", theme: "The Joyous" },
  59: { codon: "AAG", element: "Praseodymium", tone_keywords: ["dispersion", "dissolution", "limitation"], amino_acid: "Lys", theme: "Dispersion" },
  60: { codon: "AUU", element: "Neodymium", tone_keywords: ["limitation", "acceptance", "structure"], amino_acid: "Ile", theme: "Limitation" },
  61: { codon: "UCU", element: "Promethium", tone_keywords: ["inner truth", "influence", "inspiration"], amino_acid: "Ser", theme: "Inner Truth" },
  62: { codon: "UGU", element: "Samarium", tone_keywords: ["small exceeding", "details", "caution"], amino_acid: "Cys", theme: "Preponderance of the Small" },
  63: { codon: "GGG", element: "Europium", tone_keywords: ["after completion", "fulfillment", "doubt"], amino_acid: "Gly", theme: "After Completion" },
  64: { codon: "AGU", element: "Gadolinium", tone_keywords: ["before completion", "wholeness", "mystery"], amino_acid: "Ser", theme: "Before Completion" }
};

export function getGateStyle(gateNumber: number): CodonData {
  return CODON_MAP[gateNumber] || { 
    codon: "UNK", 
    element: "Unknown", 
    tone_keywords: ["neutral"], 
    amino_acid: "X", 
    theme: "Unknown Gate" 
  };
}

export function getElementalResonance(element: string): number {
  // Create harmonic resonance based on atomic properties
  const elementMap: Record<string, number> = {
    "Hydrogen": 1.008, "Helium": 4.003, "Lithium": 6.941, "Beryllium": 9.012,
    "Boron": 10.811, "Carbon": 12.011, "Nitrogen": 14.007, "Oxygen": 15.999,
    "Fluorine": 18.998, "Neon": 20.180, "Sodium": 22.990, "Magnesium": 24.305,
    "Aluminum": 26.982, "Silicon": 28.086, "Phosphorus": 30.974, "Sulfur": 32.065,
    "Chlorine": 35.453, "Argon": 39.948, "Potassium": 39.098, "Calcium": 40.078,
    // Continue with more elements as needed...
  };
  
  const atomicWeight = elementMap[element] || 1.0;
  return Math.sin(atomicWeight * 0.1) * 0.5 + 1.0; // Normalize to 0.5-1.5 range
}

export function getToneResonance(keywords: string[]): { energy: number; flow: number; coherence: number } {
  const highEnergyWords = ["impact", "courage", "liberation", "power", "drive", "independence", "ambition", "force", "breakthrough", "shock"];
  const flowWords = ["flow", "rhythm", "timing", "natural", "ease", "grace", "gentle", "harmony"];
  const coherenceWords = ["focus", "clarity", "precision", "truth", "wisdom", "knowing", "awareness"];
  
  let energy = 0.5;
  let flow = 0.5;
  let coherence = 0.5;
  
  keywords.forEach(keyword => {
    const lowerKeyword = keyword.toLowerCase();
    if (highEnergyWords.some(word => lowerKeyword.includes(word))) {
      energy += 0.3;
    }
    if (flowWords.some(word => lowerKeyword.includes(word))) {
      flow += 0.3;
    }
    if (coherenceWords.some(word => lowerKeyword.includes(word))) {
      coherence += 0.3;
    }
  });
  
  return {
    energy: Math.min(energy, 1.0),
    flow: Math.min(flow, 1.0),
    coherence: Math.min(coherence, 1.0)
  };
}