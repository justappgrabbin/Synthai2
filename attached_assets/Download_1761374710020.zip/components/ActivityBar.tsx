import { 
  Files, 
  Search, 
  GitBranch, 
  Package, 
  Settings,
  Layers,
  Code2
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface ActivityBarProps {
  activeView: 'files' | 'search' | 'source-control' | 'extensions' | 'settings';
  onViewChange: (view: 'files' | 'search' | 'source-control' | 'extensions' | 'settings') => void;
}

export function ActivityBar({ activeView, onViewChange }: ActivityBarProps) {
  const activities = [
    { id: 'files' as const, icon: Files, label: 'Explorer' },
    { id: 'search' as const, icon: Search, label: 'Search' },
    { id: 'source-control' as const, icon: GitBranch, label: 'Source Control' },
    { id: 'extensions' as const, icon: Package, label: 'Extensions' },
  ];

  return (
    <div className="w-12 bg-[#333333] flex flex-col items-center border-r border-[#2b2b2b]">
      {/* Top Icons */}
      <div className="flex flex-col items-center w-full py-2">
        {activities.map((activity) => {
          const Icon = activity.icon;
          return (
            <Button
              key={activity.id}
              variant="ghost"
              size="icon"
              className={`w-12 h-12 rounded-none hover:bg-[#2a2a2a] ${
                activeView === activity.id 
                  ? 'border-l-2 border-l-[#007acc] bg-[#2a2a2a]' 
                  : 'border-l-2 border-l-transparent'
              }`}
              onClick={() => onViewChange(activity.id)}
              data-testid={`activity-${activity.id}`}
              title={activity.label}
            >
              <Icon className={`h-6 w-6 ${
                activeView === activity.id ? 'text-white' : 'text-[#cccccc]'
              }`} />
            </Button>
          );
        })}
      </div>

      {/* Bottom Icons */}
      <div className="flex flex-col items-center w-full mt-auto pb-2">
        <Button
          variant="ghost"
          size="icon"
          className={`w-12 h-12 rounded-none hover:bg-[#2a2a2a] ${
            activeView === 'settings' 
              ? 'border-l-2 border-l-[#007acc] bg-[#2a2a2a]' 
              : 'border-l-2 border-l-transparent'
          }`}
          onClick={() => onViewChange('settings')}
          data-testid="activity-settings"
          title="Settings"
        >
          <Settings className={`h-6 w-6 ${
            activeView === 'settings' ? 'text-white' : 'text-[#cccccc]'
          }`} />
        </Button>
      </div>
    </div>
  );
}
