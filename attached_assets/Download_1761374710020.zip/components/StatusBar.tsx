import { GitBranch, AlertCircle, Info } from "lucide-react";

interface StatusBarProps {
  language?: string;
  lineNumber?: number;
  columnNumber?: number;
  errors?: number;
  warnings?: number;
}

export function StatusBar({ 
  language = 'JavaScript', 
  lineNumber = 1, 
  columnNumber = 1,
  errors = 0,
  warnings = 0
}: StatusBarProps) {
  return (
    <div className="h-6 bg-[#007acc] flex items-center justify-between px-2 text-xs text-white">
      {/* Left Section */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1 hover:bg-[#0066b3] px-2 py-0.5 rounded cursor-pointer">
          <GitBranch className="h-3 w-3" />
          <span>main</span>
        </div>
        
        {errors > 0 && (
          <div className="flex items-center gap-1 hover:bg-[#0066b3] px-2 py-0.5 rounded cursor-pointer">
            <AlertCircle className="h-3 w-3" />
            <span>{errors}</span>
          </div>
        )}
        
        {warnings > 0 && (
          <div className="flex items-center gap-1 hover:bg-[#0066b3] px-2 py-0.5 rounded cursor-pointer">
            <Info className="h-3 w-3" />
            <span>{warnings}</span>
          </div>
        )}
      </div>

      {/* Right Section */}
      <div className="flex items-center gap-3">
        <div className="hover:bg-[#0066b3] px-2 py-0.5 rounded cursor-pointer">
          Ln {lineNumber}, Col {columnNumber}
        </div>
        <div className="hover:bg-[#0066b3] px-2 py-0.5 rounded cursor-pointer">
          {language}
        </div>
        <div className="hover:bg-[#0066b3] px-2 py-0.5 rounded cursor-pointer">
          UTF-8
        </div>
        <div className="hover:bg-[#0066b3] px-2 py-0.5 rounded cursor-pointer">
          LF
        </div>
      </div>
    </div>
  );
}
