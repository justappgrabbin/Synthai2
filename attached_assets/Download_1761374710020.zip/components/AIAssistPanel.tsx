import { useState } from "react";
import { Sparkles, Send, X, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";

interface AIAssistPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AIAssistPanel({ isOpen, onClose }: AIAssistPanelProps) {
  const [prompt, setPrompt] = useState("");
  const [messages, setMessages] = useState<Array<{ role: "user" | "assistant"; content: string }>>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const quickPrompts = [
    "Build me a calculator app",
    "Create a todo list",
    "Make a game",
    "Build a chat interface",
    "Generate a landing page",
  ];

  const handleSend = async () => {
    if (!prompt.trim()) return;

    const userMessage = prompt;
    setPrompt("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setIsLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        `I'm Llama, your self-building AI! I can help you create: "${userMessage}"\n\nTo enable full self-building capabilities, you'll need to:\n1. Add an AI API key (OpenAI, Anthropic, or Hugging Face)\n2. Or use Replit's built-in AI Integrations\n\nOnce configured, I can automatically generate complete applications based on your descriptions!`,
        `Great idea! "${userMessage}" sounds interesting.\n\nI'm ready to build this for you! To activate my self-building powers, please add an AI API key in Settings or enable Replit AI Integrations.\n\nWith AI enabled, I can:\n- Generate complete code\n- Create UIs from descriptions\n- Build entire applications\n- Debug and optimize code`,
        `I love building things! For "${userMessage}", I would create:\n\n- A clean, modern interface\n- Responsive design\n- Full functionality\n- Ready to deploy\n\nTo make this happen automatically, enable AI in Settings!`,
      ];
      
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: responses[Math.floor(Math.random() * responses.length)],
        },
      ]);
      setIsLoading(false);
    }, 1000);
  };

  const handleQuickPrompt = (promptText: string) => {
    setPrompt(promptText);
  };

  const handleCopy = (content: string, index: number) => {
    navigator.clipboard.writeText(content);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 h-80 bg-card border-t z-30 flex flex-col" data-testid="ai-assist-panel">
      <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-[#007acc]/10 to-transparent">
        <div className="flex items-center gap-2">
          <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-[#007acc] to-[#005a9e] flex items-center justify-center shadow-lg">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-lg">Llama AI</h3>
            <p className="text-xs text-muted-foreground">Your Self-Building Assistant</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          data-testid="button-close-ai"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="flex-1 p-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-4 px-4">
            <div className="text-center space-y-3">
              <div className="text-4xl mb-2">🦙</div>
              <h4 className="text-lg font-semibold">Hi! I'm Llama AI</h4>
              <p className="text-sm text-muted-foreground max-w-md">
                I can build entire applications from your descriptions! Just tell me what you want to create.
              </p>
              <div className="flex flex-wrap gap-2 justify-center mt-4">
                {quickPrompts.map((qp) => (
                  <Button
                    key={qp}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickPrompt(qp)}
                    data-testid={`button-quick-${qp.toLowerCase().replace(/\s+/g, '-')}`}
                    className="bg-[#007acc]/5 hover:bg-[#007acc]/10 border-[#007acc]/20"
                  >
                    {qp}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex gap-3 ${msg.role === "user" ? "justify-end" : ""}`}
              >
                {msg.role === "assistant" && (
                  <div className="h-8 w-8 rounded-md bg-chart-3/10 flex items-center justify-center flex-shrink-0">
                    <Sparkles className="h-4 w-4 text-chart-3" />
                  </div>
                )}
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                  {msg.role === "assistant" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="mt-2 h-7 text-xs"
                      onClick={() => handleCopy(msg.content, idx)}
                      data-testid={`button-copy-${idx}`}
                    >
                      {copiedIndex === idx ? (
                        <>
                          <Check className="h-3 w-3 mr-1" />
                          Copied
                        </>
                      ) : (
                        <>
                          <Copy className="h-3 w-3 mr-1" />
                          Copy
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-3">
                <div className="h-8 w-8 rounded-md bg-chart-3/10 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="h-4 w-4 text-chart-3 animate-pulse" />
                </div>
                <div className="bg-muted rounded-lg p-3">
                  <p className="text-sm text-muted-foreground">Thinking...</p>
                </div>
              </div>
            )}
          </div>
        )}
      </ScrollArea>

      <div className="p-4 border-t">
        <div className="flex gap-2">
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe what you want to build... (e.g., 'Build me a weather app')"
            className="resize-none"
            rows={1}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            data-testid="input-ai-prompt"
          />
          <Button
            onClick={handleSend}
            disabled={!prompt.trim() || isLoading}
            data-testid="button-send-ai"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
