import { Sparkles, Code, Zap, Package, Download, Star, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

interface BrowserHomepageProps {
  onEnableDevMode: () => void;
  onShowTemplates: () => void;
  onShowPlainEnglish: () => void;
  onShowAgentCreator: () => void;
  onShowAPKBuilder: () => void;
  onShowDeploy: () => void;
}

export function BrowserHomepage({
  onEnableDevMode,
  onShowTemplates,
  onShowPlainEnglish,
  onShowAgentCreator,
  onShowAPKBuilder,
  onShowDeploy
}: BrowserHomepageProps) {
  
  const mods = [
    {
      id: 'ai-builder',
      name: 'AI Code Builder',
      description: 'Build apps using plain English with AI assistance',
      icon: Sparkles,
      category: 'AI Tools',
      downloads: '12.5K',
      rating: 4.8,
      featured: true,
      onClick: onShowPlainEnglish
    },
    {
      id: 'templates',
      name: 'Code Templates',
      description: 'Pre-built templates for games, apps, and websites',
      icon: Code,
      category: 'Templates',
      downloads: '8.2K',
      rating: 4.9,
      featured: true,
      onClick: onShowTemplates
    },
    {
      id: 'agent-creator',
      name: 'Agent Creator',
      description: 'Create custom AI agents for automation',
      icon: Zap,
      category: 'AI Tools',
      downloads: '5.1K',
      rating: 4.7,
      onClick: onShowAgentCreator
    },
    {
      id: 'apk-builder',
      name: 'APK Builder',
      description: 'Build Android apps from your web code',
      icon: Package,
      category: 'Builders',
      downloads: '3.8K',
      rating: 4.6,
      onClick: onShowAPKBuilder
    },
    {
      id: 'github-deploy',
      name: 'GitHub Deploy',
      description: 'Deploy your projects to GitHub Pages instantly',
      icon: Download,
      category: 'Deploy',
      downloads: '6.9K',
      rating: 4.8,
      onClick: onShowDeploy
    }
  ];

  const quickActions = [
    {
      title: 'Start Coding',
      description: 'Open the VS Code-style IDE',
      icon: Code,
      color: 'text-blue-400',
      onClick: onEnableDevMode
    },
    {
      title: 'AI Builder',
      description: 'Build with plain English',
      icon: Sparkles,
      color: 'text-purple-400',
      onClick: onShowPlainEnglish
    },
    {
      title: 'Browse Templates',
      description: 'Games, apps & more',
      icon: Package,
      color: 'text-emerald-400',
      onClick: onShowTemplates
    },
    {
      title: 'Create Agent',
      description: 'AI automation tools',
      icon: Zap,
      color: 'text-yellow-400',
      onClick: onShowAgentCreator
    }
  ];

  return (
    <ScrollArea className="h-full">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
        {/* Hero Section */}
        <div className="text-center space-y-3 sm:space-y-4 py-4 sm:py-8">
          <div className="flex items-center justify-center gap-2 sm:gap-3">
            <Sparkles className="w-8 h-8 sm:w-12 sm:h-12 text-[#007acc]" />
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white">YOU-N-I-VERSE</h1>
          </div>
          <p className="text-sm sm:text-base lg:text-lg text-[#969696] px-4">
            Your Cross-Platform Recursive IDE - Build Anywhere, Deploy Everywhere
          </p>
        </div>

        {/* Dashboard - Quick Actions */}
        <div>
          <h2 className="text-2xl font-semibold text-white mb-4">Dashboard</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Card 
                  key={action.title}
                  className="bg-[#252526] border-[#3c3c3c] hover:bg-[#2a2a2a] cursor-pointer transition-colors"
                  onClick={action.onClick}
                  data-testid={`quick-action-${action.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <CardHeader className="pb-3">
                    <Icon className={`w-8 h-8 ${action.color} mb-2`} />
                    <CardTitle className="text-white text-lg">{action.title}</CardTitle>
                    <CardDescription className="text-[#969696]">
                      {action.description}
                    </CardDescription>
                  </CardHeader>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Mod Store */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-semibold text-white">Mod Store</h2>
            <Badge variant="secondary" className="bg-[#007acc] text-white">
              {mods.length} Available
            </Badge>
          </div>

          {/* Featured Mods */}
          <div className="space-y-4">
            {mods.filter(mod => mod.featured).map((mod) => {
              const Icon = mod.icon;
              return (
                <Card 
                  key={mod.id}
                  className="bg-[#252526] border-[#3c3c3c] hover:bg-[#2a2a2a] transition-colors"
                  data-testid={`mod-${mod.id}`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-[#007acc]/20 rounded-lg flex items-center justify-center">
                          <Icon className="w-6 h-6 text-[#007acc]" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <CardTitle className="text-white">{mod.name}</CardTitle>
                            <Badge variant="outline" className="text-xs">
                              {mod.category}
                            </Badge>
                            {mod.featured && (
                              <Badge className="bg-yellow-500/20 text-yellow-400 text-xs">
                                <Star className="w-3 h-3 mr-1" />
                                Featured
                              </Badge>
                            )}
                          </div>
                          <CardDescription className="text-[#969696]">
                            {mod.description}
                          </CardDescription>
                          <div className="flex items-center gap-4 mt-2 text-sm text-[#969696]">
                            <div className="flex items-center gap-1">
                              <Download className="w-4 h-4" />
                              <span>{mod.downloads}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                              <span>{mod.rating}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <Button
                        onClick={mod.onClick}
                        className="bg-[#007acc] hover:bg-[#005a9e]"
                        data-testid={`button-install-${mod.id}`}
                      >
                        <TrendingUp className="w-4 h-4 mr-2" />
                        Launch
                      </Button>
                    </div>
                  </CardHeader>
                </Card>
              );
            })}
          </div>

          {/* All Mods */}
          <div className="mt-6">
            <h3 className="text-lg font-semibold text-white mb-3">All Mods</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mods.filter(mod => !mod.featured).map((mod) => {
                const Icon = mod.icon;
                return (
                  <Card 
                    key={mod.id}
                    className="bg-[#252526] border-[#3c3c3c] hover:bg-[#2a2a2a] cursor-pointer transition-colors"
                    onClick={mod.onClick}
                    data-testid={`mod-${mod.id}`}
                  >
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 bg-[#007acc]/20 rounded flex items-center justify-center">
                          <Icon className="w-5 h-5 text-[#007acc]" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-white text-base">{mod.name}</CardTitle>
                          <Badge variant="outline" className="text-xs mt-1">
                            {mod.category}
                          </Badge>
                        </div>
                      </div>
                      <CardDescription className="text-[#969696] text-sm">
                        {mod.description}
                      </CardDescription>
                      <div className="flex items-center gap-3 mt-2 text-xs text-[#969696]">
                        <div className="flex items-center gap-1">
                          <Download className="w-3 h-3" />
                          <span>{mod.downloads}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                          <span>{mod.rating}</span>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center py-8 text-sm text-[#969696]">
          <p>YOU-N-I-VERSE - A living code organism that can evolve itself</p>
          <p className="mt-2">Works on Phone, Tablet, and Desktop</p>
        </div>
      </div>
    </ScrollArea>
  );
}
