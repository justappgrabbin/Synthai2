import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Zap, 
  FileText, 
  Code2, 
  GitBranch, 
  Play, 
  Package, 
  Sparkles, 
  Download, 
  Settings 
} from "lucide-react";

interface DeveloperPanelProps {
  onDeploy: () => void;
  onTemplates: () => void;
  onAgentCreator: () => void;
  onAPKBuilder: () => void;
  onSettings: () => void;
  onPlainEnglish: () => void;
  onExport: () => void;
  onSelfEdit: () => void;
  onWorkflowCreator: () => void;
}

export function DeveloperPanel({
  onDeploy,
  onTemplates,
  onAgentCreator,
  onAPKBuilder,
  onSettings,
  onPlainEnglish,
  onExport,
  onSelfEdit,
  onWorkflowCreator
}: DeveloperPanelProps) {
  return (
    <div className="h-full flex flex-col bg-card border-l">
      <div className="p-4 border-b">
        <h2 className="font-semibold">Developer Tools</h2>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          <Button 
            onClick={onPlainEnglish} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-plain-english"
          >
            <Zap className="h-4 w-4 mr-2" />
            AI Builder
          </Button>

          <Button 
            onClick={onTemplates} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-templates"
          >
            <FileText className="h-4 w-4 mr-2" />
            Templates
          </Button>

          <Button 
            onClick={onSelfEdit} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-self-edit"
          >
            <Code2 className="h-4 w-4 mr-2" />
            Edit Source Code
          </Button>

          <Button 
            onClick={onWorkflowCreator} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-workflow"
          >
            <GitBranch className="h-4 w-4 mr-2" />
            Workflow Creator
          </Button>

          <div className="h-px bg-border my-2" />

          <Button 
            onClick={onDeploy} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-web-deploy"
          >
            <Play className="h-4 w-4 mr-2" />
            Deploy to Web
          </Button>

          <Button 
            onClick={onDeploy}
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-github"
          >
            <GitBranch className="h-4 w-4 mr-2" />
            Push to GitHub
          </Button>

          <Button 
            onClick={onAPKBuilder}
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-apk"
          >
            <Package className="h-4 w-4 mr-2" />
            Build APK
          </Button>

          <div className="h-px bg-border my-2" />

          <Button 
            onClick={onAgentCreator}
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-agent-creator"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Agent Creator
          </Button>

          <Button 
            onClick={onExport} 
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-export"
          >
            <Download className="h-4 w-4 mr-2" />
            Download Project
          </Button>

          <Button 
            onClick={onSettings}
            className="w-full justify-start"
            variant="ghost"
            data-testid="button-dev-settings"
          >
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
        </div>
      </ScrollArea>
    </div>
  );
}
