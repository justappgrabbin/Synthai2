# AI Guard Integration Guide

## What You Got

Three files that create your permanent AI assistant with multi-backend support:

1. **AIBackendSelector.tsx** - Dropdown settings panel for choosing AI model
2. **AIService.ts** - Router that handles all AI API calls
3. **PersistentAssistant.tsx** - The guard dog that can't be removed

## Color Theme
Lavender accent (#9b87f5) throughout - matches your preference

## How To Integrate

### Step 1: Add to your Settings Panel
```tsx
import { AIBackendSelector } from "@/components/AIBackendSelector";

// Inside your settings component:
<AIBackendSelector />
```

### Step 2: Add the Persistent Assistant to your App
```tsx
import { PersistentAssistant } from "@/components/PersistentAssistant";

// In your main App.tsx or layout component:
function App() {
  return (
    <>
      {/* Your existing app content */}
      <YourBrowserInterface />
      
      {/* The guard dog - always present */}
      <PersistentAssistant />
    </>
  );
}
```

### Step 3: Copy AIService to lib folder
Move `AIService.ts` to `/client/src/lib/AIService.ts`

## Supported Backends

✓ **Claude** (Anthropic) - Requires API key
✓ **GPT** (OpenAI) - Requires API key  
✓ **CodeLlama** (Local via Ollama) - No key needed
✓ **DeepSeek** - Requires API key
✓ **Grok** (xAI) - Requires API key

## Features

### AI Backend Selector
- Clean dropdown to switch between models
- Saves API keys per backend in localStorage
- Visual status indicator (configured/not configured)
- Lavender accent colors

### Persistent Assistant
- Floating button in bottom-right (always accessible)
- Can't be accidentally deleted
- Minimizes to save space
- Full chat history
- Auto-routes to selected backend
- Error handling with toast notifications
- Keyboard shortcuts (Enter to send, Shift+Enter for newline)

## Critical Notes

**DO NOT REMOVE** the PersistentAssistant component from your app. It's designed to be permanent architecture.

**DO NOT REBUILD** - Only modify CSS/styling if needed. The structure is locked.

**Settings are stored in localStorage:**
- `ai_backend` - Currently selected backend ID
- `ai_key_claude` - Claude API key
- `ai_key_gpt` - OpenAI API key
- `ai_key_deepseek` - DeepSeek API key
- `ai_key_grok` - Grok API key

## For CodeLlama (Local)
Make sure Ollama is installed and running:
```bash
ollama run codellama
```

## API Key Links
- Claude: https://console.anthropic.com/
- GPT: https://platform.openai.com/api-keys
- DeepSeek: https://platform.deepseek.com/
- Grok: https://x.ai/api

## Future Backends
To add more AI backends, edit `AIService.ts` and add:
1. New entry in `AI_BACKENDS` array (AIBackendSelector.tsx)
2. New case in the switch statement (AIService.ts)
3. New private method for API call (AIService.ts)

---

**Remember:** This assistant is your guard dog. It watches, helps, and protects your work. Don't let other AIs remove it.
