# Zip Depot - Design Guidelines

## Design Approach

**Selected Approach:** Design System with modern developer tool inspiration

**References:** Linear (clean data displays), Vercel Dashboard (status indicators), VS Code (file tree patterns), GitHub (file previews)

**Design Principles:**
1. Clarity over decoration - information-dense without cognitive overload
2. Functional hierarchy - most-used actions always accessible
3. Scan-optimized - users can quickly identify file types and structures
4. Trust through transparency - all operations clearly explained before execution

---

## Typography System

**Font Stack:** Inter (primary), SF Mono (code/file paths)

**Hierarchy:**
- Page titles: 2.5rem (40px), font-weight 700
- Section headers: 1.5rem (24px), font-weight 600
- Card titles: 1.125rem (18px), font-weight 600
- Body text: 0.875rem (14px), font-weight 400
- Metadata/captions: 0.75rem (12px), font-weight 500
- File paths/code: 0.8125rem (13px), SF Mono, font-weight 400

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8
- Micro spacing: p-2, gap-2
- Standard spacing: p-4, gap-4, m-4
- Section spacing: p-6, py-6
- Major sections: p-8, py-8

**Grid Structure:**
- Main container: max-w-7xl mx-auto px-6
- Two-column layout for main workspace: 320px sidebar + flex-1 content area
- Three-column grid for archive display: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4
- File tree: Hierarchical indentation using pl-4 per level

---

## Component Library

### 1. Upload Zone
- Large drop area: min-h-64, border-2 border-dashed, rounded-lg
- Center-aligned upload icon (cloud with arrow) and text
- Active state on drag-over with subtle border treatment
- File input hidden, triggered by zone click
- Progress indicator during upload (linear bar below zone)

### 2. File Tree Viewer
**Structure:**
- Collapsible folder rows with chevron icons (right-pointing collapsed, down-pointing expanded)
- Indented hierarchy with connection lines (subtle borders)
- File type icons from Heroicons (document, code, image, etc.)
- File size and type metadata right-aligned in each row
- Row height: h-8 for compact scanning
- Hover state with subtle background

**Layout:**
- Tree container: border, rounded-lg, p-4, max-h-96 overflow-y-auto
- Header row with "Name", "Size", "Type" columns
- Sticky header when scrolling

### 3. Archive Cards
**Card Design:**
- Aspect ratio: aspect-[4/3] for consistency
- Border, rounded-xl, p-6
- Top section: zip file icon + filename (truncated with ellipsis)
- Middle: AI analysis badge ("React App", "WordPress Theme", etc.) with icon
- File count and total size metadata
- Bottom: Action buttons row (Preview, Select, Download)
- Checkbox in top-right corner for multi-select

**States:**
- Default: standard border
- Selected: thicker border, subtle background tint
- Hover: elevated with shadow

### 4. Zip Analysis Panel
**Layout:**
- Full-width card with rounded-lg, p-6
- Header: "AI Analysis" with sparkle icon
- Analysis text: prose format, line-height relaxed
- Detected technologies: Tag badges in flex-wrap gap-2
- File structure summary: Compact tree preview
- Confidence indicator: Progress bar showing analysis certainty

### 5. Stitching Interface
**Layout:**
- Split view: 50/50 on desktop, stacked on mobile
- Left panel: "Selected Zips" list with reorder handles (drag icon)
- Right panel: "Preview Merged Structure" with conflict warnings
- Conflict resolution: Expandable accordion showing duplicate files
- Resolution options: radio buttons (Keep first, Keep last, Rename both)
- Bottom bar: Total file count, size estimate, "Create Merged Zip" button

### 6. Action Buttons
**Primary Button:**
- Height: h-10
- Padding: px-6
- Rounded: rounded-lg
- Font: text-sm font-semibold
- Icon + text layout with gap-2

**Secondary Button:**
- Same dimensions as primary
- Border style instead of filled

**Icon Button:**
- Size: w-10 h-10
- Rounded: rounded-lg
- Icon centered

### 7. Status Indicators
**Processing States:**
- Spinner icon with animated rotation
- Status text below (e.g., "Analyzing zip contents...")
- Progress percentage when available

**Success/Error Alerts:**
- Full-width banner at top: p-4, rounded-lg
- Icon (check/warning) + message + dismiss button
- Auto-dismiss after 5 seconds

### 8. Navigation Header
**Layout:**
- Fixed top, full-width, h-16
- Container: max-w-7xl mx-auto px-6
- Left: Logo + "Zip Depot" wordmark
- Center: Breadcrumb navigation (Home > Archive > [Zip Name])
- Right: Upload button (primary style) + Help icon button

### 9. Sidebar Navigation
**Structure:**
- Fixed left, w-64, h-screen, border-r
- Padding: p-4
- Navigation items: h-10, rounded-lg, px-4
- Icons from Heroicons (folder, archive, settings, etc.)
- Active state with background treatment
- Sections: "Upload", "Archive", "Recent", "Settings"

### 10. File Preview Modal
**Layout:**
- Overlay with backdrop blur
- Modal: max-w-4xl, max-h-[90vh], rounded-2xl
- Header: File name + close button, border-b, p-6
- Content area: Scrollable with p-6
- Code files: Syntax highlighted with line numbers
- Images: Centered with max dimensions
- Text files: Monospace font, preserved formatting
- Footer: Download button + "Open in New Tab" link

---

## Page Structure

### Main Dashboard Layout
1. **Header** (fixed, h-16)
2. **Sidebar** (fixed left, w-64)
3. **Main Content** (ml-64, p-8):
   - Upload zone (full-width)
   - Recent uploads section (grid of cards)
   - Archive section (grid of cards with filters)

### Upload Flow
1. Empty state with large upload zone
2. Processing state with analysis progress
3. Results view with file tree + AI analysis side-by-side

### Archive View
1. Filter bar (search, file type filter, date range)
2. Sort controls (name, date, size)
3. Grid of archive cards (3-column on desktop)
4. Pagination controls at bottom

### Stitching Workspace
1. Breadcrumb showing "Stitch Mode"
2. Multi-select grid on left (40% width)
3. Preview panel on right (60% width)
4. Bottom action bar (sticky)

---

## Animations

**Minimal, purposeful only:**
- File tree expand/collapse: smooth height transition (150ms)
- Card hover: subtle lift with shadow (100ms ease-out)
- Modal open/close: scale and fade (200ms)
- Progress indicators: smooth width transitions
- Drag-and-drop: visual feedback during drag (cursor change, drop zone highlight)

---

## Images

**Hero Section:** NO - This is a utility tool; launch directly into functionality

**Icons Throughout:**
- File type icons from Heroicons throughout file trees and lists
- Zip file icon (archive box) for zip representations
- Cloud upload icon for upload zones
- Sparkle/star icon for AI analysis sections
- Warning triangle for conflicts
- Check circle for success states

**Illustrations:**
- Empty state illustration: Minimalist line drawing of organized files/folders when archive is empty
- Processing illustration: Simple animated dots or spinner during analysis