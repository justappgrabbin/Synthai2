# Zip Depot

## Overview

Zip Depot is a web application for uploading, analyzing, and managing zip files with AI-powered insights. Users can upload zip archives, preview their contents, receive automated analysis about the project type and technologies, and merge multiple archives together while handling file conflicts intelligently.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript, using Vite as the build tool and development server.

**Routing**: Wouter for lightweight client-side routing, currently with a single-page application structure (Home page + 404).

**State Management**: TanStack Query (React Query) for server state management with aggressive caching settings (staleTime: Infinity, no automatic refetching). This minimizes unnecessary API calls and provides optimistic updates.

**UI Component System**: Radix UI primitives wrapped with custom styling via shadcn/ui component library. Components follow the "New York" style variant with a neutral base color scheme and CSS variables for theming.

**Styling Approach**: Tailwind CSS with custom design tokens defined in CSS variables. The design system prioritizes information density and scan-optimized layouts inspired by developer tools (Linear, Vercel, VS Code, GitHub). Typography uses Inter for UI and SF Mono for code/file paths.

**File Upload Strategy**: Direct-to-S3 uploads using pre-signed URLs to minimize server load. The flow is:
1. Request upload URL from backend
2. Upload file directly to object storage
3. Send object path to backend for processing and database entry

### Backend Architecture

**Server Framework**: Express.js with TypeScript running on Node.js.

**API Design**: RESTful API with routes organized by resource (`/api/zips`). Key endpoints:
- `POST /api/zips/upload-url` - Generate pre-signed upload URL
- `POST /api/zips` - Create zip record after upload
- `GET /api/zips` - List all uploaded zips
- `GET /api/zips/:id` - Get specific zip details
- `DELETE /api/zips/:id` - Delete zip record
- `GET /api/zips/:id/download` - Download original zip
- `POST /api/zips/merge` - Merge multiple zips with conflict resolution

**Data Storage Strategy**: Currently using in-memory storage (`MemStorage` class) implementing the `IStorage` interface. This abstraction allows easy migration to PostgreSQL with Drizzle ORM (configuration already present in `drizzle.config.ts`). The schema is defined in TypeScript and validated with Zod.

**File Processing**: JSZip library handles zip file extraction and manipulation. The system:
1. Downloads zip from object storage
2. Extracts complete file structure (paths, sizes, types)
3. Samples file contents for AI analysis
4. Stores metadata in database

**AI Integration**: OpenAI GPT-4o-mini analyzes zip contents to identify:
- Project type (Web Application, Python Library, etc.)
- Technologies and frameworks detected
- Confidence score for the analysis

The AI receives file statistics, sample paths, and snippet of file contents to make determinations.

### Data Models

**Core Entities**:

- `StoredZip`: Primary entity containing filename, size, upload date, object storage path, file structure, and AI analysis
- `ZipFileStructure`: Nested structure containing entries array, total size, file count, and directory count
- `ZipFileEntry`: Individual file/directory metadata (path, name, type, size)
- `AIAnalysis`: AI-generated insights (description, project type, technologies, framework, confidence)

**Validation**: Zod schemas ensure type safety between frontend and backend, with shared schema definitions in `/shared/schema.ts`.

### Development Environment

**Development Mode**: Vite dev server with HMR (Hot Module Replacement) runs in middleware mode alongside Express. The Express server proxies frontend requests to Vite during development.

**Production Build**: Frontend built to `dist/public`, backend bundled with esbuild to `dist/index.js` as an ESM module with external dependencies.

**Type Safety**: Strict TypeScript configuration with path aliases (`@/` for client, `@shared/` for shared code) ensuring consistent imports across the codebase.

## External Dependencies

### Object Storage
- **AWS S3-compatible storage** (configured for Google Cloud Storage endpoint)
- Uses `@aws-sdk/client-s3` and `@aws-sdk/s3-request-presigner` for pre-signed URL generation
- Stores zip files with UUID-based keys under `zips/` prefix
- Credentials managed via `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` environment variables
- Bucket ID specified in `DEFAULT_OBJECT_STORAGE_BUCKET_ID`

### Database
- **Drizzle ORM** with PostgreSQL dialect (schema defined, not currently connected)
- Connection string expected in `DATABASE_URL` environment variable
- Migration files configured to output to `./migrations`
- Schema location: `./shared/schema.ts`

### AI Service
- **OpenAI API** (GPT-4o-mini model) for zip content analysis
- Base URL and API key configured via:
  - `AI_INTEGRATIONS_OPENAI_API_KEY`
  - `AI_INTEGRATIONS_OPENAI_BASE_URL`
- Analyzes file structures, paths, and contents to identify project types and technologies

### External Storage Integrations
- **GitHub**: Connected via Replit connection (connection:conn_github_01K7GZDMDWBTDZGXBJJ7CVQG3P)
  - Client library: `@octokit/rest` v22.0.0
  - Permissions: read:org, read:project, read:user, repo, user:email
  - Can fetch zip archives from repositories
- **Google Drive**: Connected via Replit connection (connection:conn_google-drive_01K8D9VR45MXH9GE7CW3SAV0ER)
  - Client library: `googleapis` v148.0.0
  - Can import zip files from Google Drive
- **Dropbox**: User declined integration setup
  - Note: Future implementation would require manual credential management

### Third-Party Libraries
- **Uppy**: File upload UI components (`@uppy/core`, `@uppy/aws-s3`, `@uppy/react`)
- **JSZip**: Zip file manipulation and extraction
- **Neon Database Serverless**: PostgreSQL driver (`@neondatabase/serverless`)
- **Octokit**: GitHub REST API client for GitHub integration
- **googleapis**: Google Drive API client for Drive integration