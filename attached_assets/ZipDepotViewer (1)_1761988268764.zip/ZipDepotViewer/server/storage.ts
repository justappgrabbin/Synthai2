import type { StoredZip, ZipFileStructure, AIAnalysis } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createZip(zip: Omit<StoredZip, 'id' | 'uploadDate'>): Promise<StoredZip>;
  getZip(id: string): Promise<StoredZip | undefined>;
  getAllZips(): Promise<StoredZip[]>;
  deleteZip(id: string): Promise<boolean>;
  updateZipAnalysis(id: string, analysis: AIAnalysis): Promise<void>;
  updateZipStructure(id: string, structure: ZipFileStructure): Promise<void>;
}

export class MemStorage implements IStorage {
  private zips: Map<string, StoredZip>;

  constructor() {
    this.zips = new Map();
  }

  async createZip(zip: Omit<StoredZip, 'id' | 'uploadDate'>): Promise<StoredZip> {
    const id = randomUUID();
    const storedZip: StoredZip = {
      ...zip,
      id,
      uploadDate: new Date().toISOString(),
    };
    this.zips.set(id, storedZip);
    return storedZip;
  }

  async getZip(id: string): Promise<StoredZip | undefined> {
    return this.zips.get(id);
  }

  async getAllZips(): Promise<StoredZip[]> {
    return Array.from(this.zips.values()).sort(
      (a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime()
    );
  }

  async deleteZip(id: string): Promise<boolean> {
    return this.zips.delete(id);
  }

  async updateZipAnalysis(id: string, analysis: AIAnalysis): Promise<void> {
    const zip = this.zips.get(id);
    if (zip) {
      zip.analysis = analysis;
      this.zips.set(id, zip);
    }
  }

  async updateZipStructure(id: string, structure: ZipFileStructure): Promise<void> {
    const zip = this.zips.get(id);
    if (zip) {
      zip.structure = structure;
      this.zips.set(id, zip);
    }
  }
}

export const storage = new MemStorage();
