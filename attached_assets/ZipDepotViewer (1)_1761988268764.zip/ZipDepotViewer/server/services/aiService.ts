import type { AIAnalysis } from '@shared/schema';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

interface AnalysisInput {
  fileCount: number;
  fileTypes: Record<string, number>;
  filePaths: string[];
  sampleContents: { path: string; content: string }[];
}

export async function analyzeWithAI(input: AnalysisInput): Promise<AIAnalysis> {
  const prompt = `Analyze this zip file contents and provide a concise analysis:

File Statistics:
- Total files: ${input.fileCount}
- File types: ${JSON.stringify(input.fileTypes, null, 2)}

Sample file paths:
${input.filePaths.slice(0, 30).join('\n')}

${input.sampleContents.length > 0 ? `\nSample file contents:\n${input.sampleContents.map(s => `\n--- ${s.path} ---\n${s.content}`).join('\n')}` : ''}

Based on this information, provide a JSON response with:
1. projectType: A brief category (e.g., "Web Application", "Python Library", "Mobile App", "Game", "Data Science Project")
2. description: A 1-2 sentence description of what this project does or contains
3. technologies: Array of detected technologies/languages (e.g., ["React", "TypeScript", "Node.js"])
4. framework: The main framework if detected (e.g., "Next.js", "Django", "Unity"), or null
5. confidence: A number between 0 and 1 indicating confidence in the analysis

Respond only with valid JSON matching this structure:
{
  "projectType": "string",
  "description": "string",
  "technologies": ["string"],
  "framework": "string or null",
  "confidence": number
}`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are an expert at analyzing project structures and identifying technologies. Always respond with valid JSON only.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      max_completion_tokens: 500,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error('No response from AI');
    }

    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No JSON found in response');
    }

    const analysis: AIAnalysis = JSON.parse(jsonMatch[0]);
    
    return {
      projectType: analysis.projectType || 'Unknown',
      description: analysis.description || 'Unable to determine project description',
      technologies: analysis.technologies || [],
      framework: analysis.framework,
      confidence: Math.min(1, Math.max(0, analysis.confidence || 0.5)),
    };
  } catch (error) {
    console.error('AI analysis error:', error);
    
    const guessedType = guessProjectType(input.fileTypes, input.filePaths);
    
    return {
      projectType: guessedType.type,
      description: guessedType.description,
      technologies: guessedType.technologies,
      framework: guessedType.framework,
      confidence: 0.4,
    };
  }
}

function guessProjectType(fileTypes: Record<string, number>, filePaths: string[]) {
  const hasFile = (pattern: RegExp) => filePaths.some(p => pattern.test(p));
  
  if (hasFile(/package\.json/)) {
    return {
      type: 'JavaScript Project',
      description: 'A JavaScript or Node.js project with npm dependencies.',
      technologies: ['JavaScript', 'Node.js'],
      framework: hasFile(/next\.config/) ? 'Next.js' : hasFile(/vite\.config/) ? 'Vite' : undefined,
    };
  }
  
  if (hasFile(/requirements\.txt/) || hasFile(/setup\.py/)) {
    return {
      type: 'Python Project',
      description: 'A Python project with pip dependencies.',
      technologies: ['Python'],
      framework: hasFile(/manage\.py/) ? 'Django' : hasFile(/app\.py/) ? 'Flask' : undefined,
    };
  }
  
  if (hasFile(/Cargo\.toml/)) {
    return {
      type: 'Rust Project',
      description: 'A Rust project built with Cargo.',
      technologies: ['Rust'],
      framework: undefined,
    };
  }
  
  if (hasFile(/go\.mod/)) {
    return {
      type: 'Go Project',
      description: 'A Go project with module dependencies.',
      technologies: ['Go'],
      framework: undefined,
    };
  }
  
  if (fileTypes['html'] || fileTypes['css']) {
    return {
      type: 'Web Project',
      description: 'A web project containing HTML and CSS files.',
      technologies: ['HTML', 'CSS'],
      framework: undefined,
    };
  }
  
  return {
    type: 'Mixed Archive',
    description: 'An archive containing various files and directories.',
    technologies: Object.keys(fileTypes).slice(0, 5),
    framework: undefined,
  };
}
