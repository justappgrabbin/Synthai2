import JSZip from 'jszip';
import { ObjectStorageService } from './objectStorage';
import { randomUUID } from 'crypto';

export async function getFileContent(objectPath: string, filePath: string): Promise<{ content: Buffer; mimeType: string } | null> {
  const objectStorage = new ObjectStorageService();
  const buffer = await objectStorage.downloadObjectAsBuffer(objectPath);
  const zip = await JSZip.loadAsync(buffer);
  
  let normalizedPath = filePath.startsWith('/') ? filePath.substring(1) : filePath;
  const file = zip.file(normalizedPath);
  
  if (!file) {
    return null;
  }
  
  const content = await file.async('nodebuffer');
  const mimeType = getMimeType(filePath);
  
  return { content, mimeType };
}

export async function createModifiedZip(
  objectPath: string,
  modifications: {
    deletedPaths?: string[];
    renamedPaths?: { oldPath: string; newPath: string }[];
  }
): Promise<{ buffer: Buffer; objectKey: string }> {
  const objectStorage = new ObjectStorageService();
  const buffer = await objectStorage.downloadObjectAsBuffer(objectPath);
  const zip = await JSZip.loadAsync(buffer);
  
  const newZip = new JSZip();
  const deletedSet = new Set(modifications.deletedPaths || []);
  const renameMap = new Map(
    (modifications.renamedPaths || []).map(r => [r.oldPath, r.newPath])
  );
  
  await Promise.all(
    Object.keys(zip.files).map(async (path) => {
      if (deletedSet.has(path)) {
        return;
      }
      
      const file = zip.files[path];
      if (file.dir) {
        return;
      }
      
      const newPath = renameMap.get(path) || path;
      const content = await file.async('nodebuffer');
      newZip.file(newPath, content);
    })
  );
  
  const modifiedBuffer = await newZip.generateAsync({ type: 'nodebuffer' });
  
  const objectKey = `zips/${randomUUID()}.zip`;
  const privateDir = objectStorage.getPrivateObjectDir();
  const fullPath = `${privateDir}/${objectKey}`;
  
  const pathParts = fullPath.startsWith('/') ? fullPath.substring(1).split('/') : fullPath.split('/');
  const bucketName = pathParts[0];
  const objectName = pathParts.slice(1).join('/');
  
  const { Storage } = await import('@google-cloud/storage');
  const storage = new Storage({
    credentials: {
      audience: "replit",
      subject_token_type: "access_token",
      token_url: "http://127.0.0.1:1106/token",
      type: "external_account",
      credential_source: {
        url: "http://127.0.0.1:1106/credential",
        format: {
          type: "json",
          subject_token_field_name: "access_token",
        },
      },
      universe_domain: "googleapis.com",
    },
    projectId: "",
  });
  
  const bucket = storage.bucket(bucketName);
  await bucket.file(objectName).save(modifiedBuffer);
  
  return { buffer: modifiedBuffer, objectKey };
}

function getMimeType(filePath: string): string {
  const ext = filePath.split('.').pop()?.toLowerCase();
  const mimeTypes: Record<string, string> = {
    'txt': 'text/plain',
    'html': 'text/html',
    'htm': 'text/html',
    'css': 'text/css',
    'js': 'application/javascript',
    'jsx': 'application/javascript',
    'ts': 'application/typescript',
    'tsx': 'application/typescript',
    'json': 'application/json',
    'xml': 'application/xml',
    'md': 'text/markdown',
    'yaml': 'text/yaml',
    'yml': 'text/yaml',
    'py': 'text/x-python',
    'java': 'text/x-java',
    'c': 'text/x-c',
    'cpp': 'text/x-c++',
    'go': 'text/x-go',
    'rs': 'text/x-rust',
    'php': 'text/x-php',
    'rb': 'text/x-ruby',
    'sh': 'application/x-sh',
    'png': 'image/png',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'gif': 'image/gif',
    'svg': 'image/svg+xml',
    'pdf': 'application/pdf',
  };
  
  return mimeTypes[ext || ''] || 'application/octet-stream';
}
