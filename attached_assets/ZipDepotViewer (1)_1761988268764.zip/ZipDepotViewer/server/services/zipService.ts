import JSZip from 'jszip';
import type { ZipFileStructure, ZipFileEntry, AIAnalysis } from '@shared/schema';
import { analyzeWithAI } from './aiService';

export async function extractZipStructure(zipBuffer: Buffer): Promise<ZipFileStructure> {
  const zip = await JSZip.loadAsync(zipBuffer);
  const entries: ZipFileEntry[] = [];
  let totalSize = 0;
  let fileCount = 0;
  let directoryCount = 0;

  for (const [path, file] of Object.entries(zip.files)) {
    const entry: ZipFileEntry = {
      path,
      name: path.split('/').filter(Boolean).pop() || path,
      isDirectory: file.dir,
      size: file.dir ? 0 : (file as any)._data?.uncompressedSize || 0,
    };

    if (!file.dir) {
      const ext = path.split('.').pop()?.toLowerCase();
      if (ext) {
        entry.type = ext;
      }
      fileCount++;
      totalSize += entry.size;
    } else {
      directoryCount++;
    }

    entries.push(entry);
  }

  return {
    entries,
    totalSize,
    fileCount,
    directoryCount,
  };
}

export async function analyzeZip(zipBuffer: Buffer, structure: ZipFileStructure): Promise<AIAnalysis> {
  const zip = await JSZip.loadAsync(zipBuffer);
  
  const fileTypes = new Map<string, number>();
  const filePaths: string[] = [];
  const sampleContents: { path: string; content: string }[] = [];

  for (const entry of structure.entries) {
    if (!entry.isDirectory) {
      const ext = entry.type || 'unknown';
      fileTypes.set(ext, (fileTypes.get(ext) || 0) + 1);
      filePaths.push(entry.path);
    }
  }

  const importantFiles = [
    'package.json', 'requirements.txt', 'Cargo.toml', 'go.mod', 'pom.xml',
    'README.md', 'index.html', 'main.py', 'main.js', 'App.tsx', 'App.jsx'
  ];

  for (const filename of importantFiles) {
    const file = zip.file(new RegExp(filename + '$', 'i'))[0];
    if (file && !file.dir) {
      try {
        const content = await file.async('string');
        if (content.length < 10000) {
          sampleContents.push({
            path: file.name,
            content: content.substring(0, 2000),
          });
        }
      } catch (error) {
        console.error(`Error reading ${file.name}:`, error);
      }
    }
  }

  const analysis = await analyzeWithAI({
    fileCount: structure.fileCount,
    fileTypes: Object.fromEntries(fileTypes),
    filePaths: filePaths.slice(0, 50),
    sampleContents,
  });

  return analysis;
}

export async function mergeZips(
  zipBuffers: Buffer[],
  conflictResolutions: Record<string, 'first' | 'last' | 'rename'>
): Promise<Buffer> {
  const mergedZip = new JSZip();
  const seenPaths = new Map<string, number>();

  for (let i = 0; i < zipBuffers.length; i++) {
    const zip = await JSZip.loadAsync(zipBuffers[i]);

    for (const [path, file] of Object.entries(zip.files)) {
      if (file.dir) {
        continue;
      }

      let finalPath = path;
      const resolution = conflictResolutions[path];

      if (seenPaths.has(path)) {
        if (resolution === 'first') {
          continue;
        } else if (resolution === 'last') {
          finalPath = path;
        } else if (resolution === 'rename') {
          const ext = path.split('.').pop();
          const basePath = path.substring(0, path.length - (ext ? ext.length + 1 : 0));
          finalPath = `${basePath}-${i + 1}${ext ? '.' + ext : ''}`;
        }
      }

      const content = await file.async('nodebuffer');
      mergedZip.file(finalPath, content);
      seenPaths.set(path, i);
    }
  }

  const buffer = await mergedZip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  return buffer;
}
