import JSZip from 'jszip';
import { ObjectStorageService } from './objectStorage';

interface ZipCache {
  zip: JSZip;
  timestamp: number;
}

const zipCache = new Map<string, ZipCache>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

export async function getZipInstance(objectPath: string): Promise<JSZip> {
  const cached = zipCache.get(objectPath);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.zip;
  }

  const objectStorage = new ObjectStorageService();
  const buffer = await objectStorage.downloadObjectAsBuffer(objectPath);
  const zip = await JSZip.loadAsync(buffer);
  
  zipCache.set(objectPath, { zip, timestamp: Date.now() });
  
  setTimeout(() => zipCache.delete(objectPath), CACHE_TTL);
  
  return zip;
}

export async function getFileFromZip(objectPath: string, filePath: string): Promise<Buffer | null> {
  const zip = await getZipInstance(objectPath);
  
  let normalizedPath = filePath.startsWith('/') ? filePath.substring(1) : filePath;
  
  const file = zip.file(normalizedPath);
  if (!file) {
    return null;
  }
  
  const content = await file.async('nodebuffer');
  return content;
}

export function detectEntryFile(files: string[]): string | null {
  const priorities = [
    'index.html',
    'index.htm',
    'main.html',
    'home.html',
    'app.html',
  ];
  
  for (const priority of priorities) {
    const found = files.find(f => f.toLowerCase().endsWith(priority));
    if (found) return found;
  }
  
  const htmlFiles = files.filter(f => f.toLowerCase().endsWith('.html') || f.toLowerCase().endsWith('.htm'));
  if (htmlFiles.length > 0) {
    return htmlFiles[0];
  }
  
  return null;
}

export function getContentType(filePath: string): string {
  const ext = filePath.split('.').pop()?.toLowerCase();
  const mimeTypes: Record<string, string> = {
    'html': 'text/html',
    'htm': 'text/html',
    'css': 'text/css',
    'js': 'application/javascript',
    'json': 'application/json',
    'png': 'image/png',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'gif': 'image/gif',
    'svg': 'image/svg+xml',
    'ico': 'image/x-icon',
    'woff': 'font/woff',
    'woff2': 'font/woff2',
    'ttf': 'font/ttf',
    'eot': 'application/vnd.ms-fontobject',
  };
  
  return mimeTypes[ext || ''] || 'application/octet-stream';
}
