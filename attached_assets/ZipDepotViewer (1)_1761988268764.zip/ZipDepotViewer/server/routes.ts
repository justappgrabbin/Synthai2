import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { analyzeZip, extractZipStructure, mergeZips } from "./services/zipService";
import { ObjectStorageService } from "./services/objectStorage";
import { zipUploadSchema, mergeZipsSchema } from "@shared/schema";
import { listUserRepos, downloadGitHubRepoAsZip } from "./services/githubService";
import { listZipFiles, downloadDriveFile } from "./services/googleDriveService";
import { getFileFromZip, detectEntryFile, getContentType } from "./services/zipPlayerService";
import { getFileContent, createModifiedZip } from "./services/archiveManagerService";
import { randomUUID } from "crypto";

export function registerRoutes(app: Express) {
  const server = createServer(app);
  const objectStorage = new ObjectStorageService();

  app.post('/api/zips/upload-url', async (req, res) => {
    try {
      const uploadURL = await objectStorage.getObjectEntityUploadURL();
      res.json({ uploadURL });
    } catch (error) {
      console.error('Error creating upload URL:', error);
      res.status(500).json({ error: 'Failed to create upload URL' });
    }
  });

  app.post('/api/zips', async (req, res) => {
    try {
      const validatedData = zipUploadSchema.parse(req.body);
      
      const urlObj = new URL(validatedData.objectPath);
      let objectKey = urlObj.pathname;
      
      if (objectKey.startsWith('/')) {
        objectKey = objectKey.substring(1);
      }
      
      const privateDir = objectStorage.getPrivateObjectDir();
      const cleanPrivateDir = privateDir.startsWith('/') ? privateDir.substring(1) : privateDir;
      
      if (objectKey.startsWith(cleanPrivateDir + '/')) {
        objectKey = objectKey.substring(cleanPrivateDir.length + 1);
      }
      
      const zipBuffer = await objectStorage.downloadObjectAsBuffer(objectKey);
      
      const structure = await extractZipStructure(zipBuffer);
      const analysis = await analyzeZip(zipBuffer, structure);

      const zip = await storage.createZip({
        filename: validatedData.filename,
        originalName: validatedData.filename,
        size: validatedData.size,
        objectPath: objectKey,
        structure,
        analysis,
      });

      res.json(zip);
    } catch (error) {
      console.error('Error creating zip:', error);
      res.status(500).json({ error: 'Failed to create zip record' });
    }
  });

  app.get('/api/zips', async (_req, res) => {
    try {
      const zips = await storage.getAllZips();
      res.json(zips);
    } catch (error) {
      console.error('Error fetching zips:', error);
      res.status(500).json({ error: 'Failed to fetch zips' });
    }
  });

  app.get('/api/zips/:id', async (req, res) => {
    try {
      const zip = await storage.getZip(req.params.id);
      if (!zip) {
        return res.status(404).json({ error: 'Zip not found' });
      }
      res.json(zip);
    } catch (error) {
      console.error('Error fetching zip:', error);
      res.status(500).json({ error: 'Failed to fetch zip' });
    }
  });

  app.get('/api/zips/:id/download', async (req, res) => {
    try {
      const zip = await storage.getZip(req.params.id);
      if (!zip) {
        return res.status(404).json({ error: 'Zip not found' });
      }

      const zipBuffer = await objectStorage.downloadObjectAsBuffer(zip.objectPath);
      
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${zip.originalName}"`);
      res.send(zipBuffer);
    } catch (error) {
      console.error('Error downloading zip:', error);
      res.status(500).json({ error: 'Failed to download zip' });
    }
  });

  app.delete('/api/zips/:id', async (req, res) => {
    try {
      const deleted = await storage.deleteZip(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: 'Zip not found' });
      }
      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting zip:', error);
      res.status(500).json({ error: 'Failed to delete zip' });
    }
  });

  app.post('/api/zips/merge', async (req, res) => {
    try {
      const validatedData = mergeZipsSchema.parse(req.body);
      
      const zips = await Promise.all(
        validatedData.zipIds.map(id => storage.getZip(id))
      );

      if (zips.some(z => !z)) {
        return res.status(404).json({ error: 'One or more zips not found' });
      }

      const zipBuffers = await Promise.all(
        zips.map(z => objectStorage.downloadObjectAsBuffer(z!.objectPath))
      );

      const mergedBuffer = await mergeZips(zipBuffers, validatedData.conflictResolutions);

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="merged-${Date.now()}.zip"`);
      res.send(mergedBuffer);
    } catch (error) {
      console.error('Error merging zips:', error);
      res.status(500).json({ error: 'Failed to merge zips' });
    }
  });

  app.get('/api/integrations/github/repos', async (_req, res) => {
    try {
      const repos = await listUserRepos();
      res.json(repos);
    } catch (error) {
      console.error('Error fetching GitHub repos:', error);
      res.status(500).json({ error: 'Failed to fetch GitHub repositories' });
    }
  });

  app.post('/api/integrations/github/import', async (req, res) => {
    try {
      const { owner, repo, ref } = req.body;
      if (!owner || !repo) {
        return res.status(400).json({ error: 'Owner and repo are required' });
      }

      const zipBuffer = await downloadGitHubRepoAsZip(owner, repo, ref || 'main');
      
      const structure = await extractZipStructure(zipBuffer);
      const analysis = await analyzeZip(zipBuffer, structure);

      const objectKey = `zips/${randomUUID()}.zip`;
      const privateDir = objectStorage.getPrivateObjectDir();
      const { bucketName, objectName } = parseObjectPath(`${privateDir}/${objectKey}`);
      
      const { Storage } = await import('@google-cloud/storage');
      const bucket = new Storage().bucket(bucketName);
      await bucket.file(objectName).save(zipBuffer);

      const zip = await storage.createZip({
        filename: `${repo}.zip`,
        originalName: `${repo}.zip`,
        size: zipBuffer.length,
        objectPath: objectKey,
        structure,
        analysis,
      });

      res.json(zip);
    } catch (error) {
      console.error('Error importing from GitHub:', error);
      res.status(500).json({ error: 'Failed to import from GitHub' });
    }
  });

  app.get('/api/integrations/google-drive/files', async (_req, res) => {
    try {
      const files = await listZipFiles();
      res.json(files);
    } catch (error) {
      console.error('Error fetching Google Drive files:', error);
      res.status(500).json({ error: 'Failed to fetch Google Drive files' });
    }
  });

  app.post('/api/integrations/google-drive/import', async (req, res) => {
    try {
      const { fileId, fileName } = req.body;
      if (!fileId) {
        return res.status(400).json({ error: 'File ID is required' });
      }

      const zipBuffer = await downloadDriveFile(fileId);
      
      const structure = await extractZipStructure(zipBuffer);
      const analysis = await analyzeZip(zipBuffer, structure);

      const objectKey = `zips/${randomUUID()}.zip`;
      const privateDir = objectStorage.getPrivateObjectDir();
      const { bucketName, objectName } = parseObjectPath(`${privateDir}/${objectKey}`);
      
      const { Storage } = await import('@google-cloud/storage');
      const bucket = new Storage().bucket(bucketName);
      await bucket.file(objectName).save(zipBuffer);

      const zip = await storage.createZip({
        filename: fileName || 'imported.zip',
        originalName: fileName || 'imported.zip',
        size: zipBuffer.length,
        objectPath: objectKey,
        structure,
        analysis,
      });

      res.json(zip);
    } catch (error) {
      console.error('Error importing from Google Drive:', error);
      res.status(500).json({ error: 'Failed to import from Google Drive' });
    }
  });

  app.get('/api/zips/:id/play/:filePath(*)', async (req, res) => {
    try {
      const zip = await storage.getZip(req.params.id);
      if (!zip) {
        return res.status(404).json({ error: 'Zip not found' });
      }

      const filePath = req.params.filePath || '';
      const fileContent = await getFileFromZip(zip.objectPath, filePath);
      
      if (!fileContent) {
        return res.status(404).send('File not found in zip');
      }

      const contentType = getContentType(filePath);
      res.setHeader('Content-Type', contentType);
      res.setHeader('X-Frame-Options', 'SAMEORIGIN');
      res.send(fileContent);
    } catch (error) {
      console.error('Error serving file from zip:', error);
      res.status(500).json({ error: 'Failed to serve file' });
    }
  });

  app.get('/api/zips/:id/entry-file', async (req, res) => {
    try {
      const zip = await storage.getZip(req.params.id);
      if (!zip) {
        return res.status(404).json({ error: 'Zip not found' });
      }

      const files = zip.structure.entries
        .filter(e => e.type === 'file')
        .map(e => e.path);
      
      const entryFile = detectEntryFile(files);
      res.json({ entryFile });
    } catch (error) {
      console.error('Error detecting entry file:', error);
      res.status(500).json({ error: 'Failed to detect entry file' });
    }
  });

  app.get('/api/zips/:id/file/:filePath(*)', async (req, res) => {
    try {
      const zip = await storage.getZip(req.params.id);
      if (!zip) {
        return res.status(404).json({ error: 'Zip not found' });
      }

      const filePath = req.params.filePath;
      const fileData = await getFileContent(zip.objectPath, filePath);
      
      if (!fileData) {
        return res.status(404).json({ error: 'File not found in zip' });
      }

      res.setHeader('Content-Type', fileData.mimeType);
      res.send(fileData.content);
    } catch (error) {
      console.error('Error getting file content:', error);
      res.status(500).json({ error: 'Failed to get file content' });
    }
  });

  app.post('/api/zips/:id/modify', async (req, res) => {
    try {
      const zip = await storage.getZip(req.params.id);
      if (!zip) {
        return res.status(404).json({ error: 'Zip not found' });
      }

      const { deletedPaths, renamedPaths } = req.body;
      const { buffer, objectKey } = await createModifiedZip(zip.objectPath, {
        deletedPaths,
        renamedPaths,
      });

      const { extractZipStructure, analyzeZip } = await import('./services/zipService');
      const structure = await extractZipStructure(buffer);
      const analysis = await analyzeZip(buffer, structure);

      const newZip = await storage.createZip({
        filename: `modified-${zip.filename}`,
        originalName: `modified-${zip.originalName}`,
        size: buffer.length,
        objectPath: objectKey,
        structure,
        analysis,
      });

      res.json(newZip);
    } catch (error) {
      console.error('Error modifying zip:', error);
      res.status(500).json({ error: 'Failed to modify zip' });
    }
  });

  return server;
}

function parseObjectPath(path: string): { bucketName: string; objectName: string } {
  if (!path.startsWith("/")) {
    path = `/${path}`;
  }
  const pathParts = path.split("/");
  if (pathParts.length < 3) {
    throw new Error("Invalid path: must contain at least a bucket name");
  }

  const bucketName = pathParts[1];
  const objectName = pathParts.slice(2).join("/");

  return { bucketName, objectName };
}
