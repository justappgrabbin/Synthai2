import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Archive, Layers, Search, Cloud } from "lucide-react";
import { ZipUploader } from "@/components/ZipUploader";
import { ZipCard } from "@/components/ZipCard";
import { ZipPreviewModal } from "@/components/ZipPreviewModal";
import { StitchingWorkspace } from "@/components/StitchingWorkspace";
import { ImportModal } from "@/components/ImportModal";
import { ZipPlayer } from "@/components/ZipPlayer";
import { ArchiveManager } from "@/components/ArchiveManager";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { StoredZip } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedZipIds, setSelectedZipIds] = useState<Set<string>>(new Set());
  const [previewZip, setPreviewZip] = useState<StoredZip | null>(null);
  const [playerZip, setPlayerZip] = useState<StoredZip | null>(null);
  const [managerZip, setManagerZip] = useState<StoredZip | null>(null);
  const [stitchMode, setStitchMode] = useState(false);
  const [importModalOpen, setImportModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: zips = [], isLoading } = useQuery<StoredZip[]>({
    queryKey: ['/api/zips'],
  });

  const deleteMutation = useMutation({
    mutationFn: async (zipId: string) => {
      await apiRequest('DELETE', `/api/zips/${zipId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/zips'] });
      toast({
        title: "Zip deleted",
        description: "The zip file has been removed from your archive.",
      });
    },
  });

  const downloadMutation = useMutation({
    mutationFn: async (zipId: string) => {
      const response = await fetch(`/api/zips/${zipId}/download`);
      if (!response.ok) throw new Error('Download failed');
      return response.blob();
    },
    onSuccess: (blob, zipId) => {
      const zip = zips.find(z => z.id === zipId);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = zip?.originalName || 'download.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Download started",
        description: "Your zip file is being downloaded.",
      });
    },
  });

  const stitchMutation = useMutation({
    mutationFn: async (data: { zipIds: string[]; conflictResolutions: Record<string, 'first' | 'last' | 'rename'> }) => {
      const response = await apiRequest('POST', '/api/zips/merge', data);
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `merged-${Date.now()}.zip`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      setStitchMode(false);
      setSelectedZipIds(new Set());
      
      toast({
        title: "Merge complete",
        description: "Your merged zip file is being downloaded.",
      });
    },
  });

  const handleUploadComplete = (zipId: string) => {
    queryClient.invalidateQueries({ queryKey: ['/api/zips'] });
  };

  const handleSelectZip = (zipId: string, selected: boolean) => {
    setSelectedZipIds(prev => {
      const newSet = new Set(prev);
      if (selected) {
        newSet.add(zipId);
      } else {
        newSet.delete(zipId);
      }
      return newSet;
    });
  };

  const handleStitch = (conflictResolutions: Record<string, 'first' | 'last' | 'rename'>) => {
    stitchMutation.mutate({
      zipIds: Array.from(selectedZipIds),
      conflictResolutions,
    });
  };

  const selectedZips = zips.filter(z => selectedZipIds.has(z.id));

  const filteredZips = zips.filter(zip => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      zip.originalName.toLowerCase().includes(query) ||
      zip.analysis.projectType.toLowerCase().includes(query) ||
      zip.analysis.description.toLowerCase().includes(query) ||
      zip.analysis.technologies.some(tech => tech.toLowerCase().includes(query)) ||
      zip.analysis.framework?.toLowerCase().includes(query) ||
      zip.structure.entries.some(entry => entry.path.toLowerCase().includes(query))
    );
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Archive className="w-5 h-5 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-bold text-foreground">Zip Depot</h1>
          </div>

          <div className="flex items-center gap-2">
            {selectedZipIds.size > 0 && (
              <Button
                variant={stitchMode ? "default" : "outline"}
                onClick={() => setStitchMode(!stitchMode)}
                data-testid="button-toggle-stitch"
              >
                <Layers className="w-4 h-4 mr-2" />
                Stitch ({selectedZipIds.size})
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {!stitchMode ? (
          <>
            <section className="space-y-6">
              <div className="space-y-2">
                <h2 className="text-2.5xl font-bold text-foreground">Upload & Analyze</h2>
                <p className="text-sm text-muted-foreground">
                  Upload zip files to analyze their contents with AI, preview files, and stitch multiple archives together
                </p>
              </div>

              <ZipUploader onUploadComplete={handleUploadComplete} />

              <div className="flex items-center gap-4 pt-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Cloud className="w-4 h-4" />
                  <span>Import from cloud storage:</span>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setImportModalOpen(true)}
                  data-testid="button-import-cloud"
                >
                  <Cloud className="w-4 h-4 mr-1.5" />
                  Import from GitHub/Drive
                </Button>
              </div>
            </section>

            <section className="space-y-6">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="space-y-1">
                  <h2 className="text-1.5xl font-semibold text-foreground">Your Archive</h2>
                  <p className="text-sm text-muted-foreground">
                    {zips.length} zip file{zips.length !== 1 ? 's' : ''} in your collection
                  </p>
                </div>

                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search by name, type, or technology..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                    data-testid="input-search"
                  />
                </div>
              </div>

              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="h-80 bg-muted rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : filteredZips.length === 0 ? (
                <div className="border-2 border-dashed rounded-lg p-16 text-center">
                  <Archive className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-semibold text-foreground mb-2">
                    {searchQuery ? 'No matching zip files' : 'No zip files yet'}
                  </p>
                  <p className="text-sm text-muted-foreground max-w-md mx-auto">
                    {searchQuery 
                      ? 'Try adjusting your search query to find what you\'re looking for'
                      : 'Upload your first zip file to get started with analysis and stitching'
                    }
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredZips.map(zip => (
                    <ZipCard
                      key={zip.id}
                      zip={zip}
                      selected={selectedZipIds.has(zip.id)}
                      onSelect={(selected) => handleSelectZip(zip.id, selected)}
                      onPreview={() => setPreviewZip(zip)}
                      onDownload={() => downloadMutation.mutate(zip.id)}
                      onDelete={() => deleteMutation.mutate(zip.id)}
                      onPlay={() => setPlayerZip(zip)}
                      onManage={() => setManagerZip(zip)}
                    />
                  ))}
                </div>
              )}
            </section>
          </>
        ) : (
          <section className="space-y-6">
            <div className="space-y-2">
              <h2 className="text-2.5xl font-bold text-foreground">Stitch Zips Together</h2>
              <p className="text-sm text-muted-foreground">
                Combine multiple zip files into one merged archive. Resolve any file conflicts below.
              </p>
            </div>

            <StitchingWorkspace
              selectedZips={selectedZips}
              onRemoveZip={(zipId) => handleSelectZip(zipId, false)}
              onStitch={handleStitch}
              onClose={() => {
                setStitchMode(false);
                setSelectedZipIds(new Set());
              }}
            />
          </section>
        )}
      </main>

      <ZipPreviewModal
        zip={previewZip}
        open={!!previewZip}
        onClose={() => setPreviewZip(null)}
      />

      <ImportModal
        open={importModalOpen}
        onOpenChange={setImportModalOpen}
        onImportComplete={handleUploadComplete}
      />

      <ZipPlayer
        zip={playerZip}
        open={!!playerZip}
        onClose={() => setPlayerZip(null)}
      />

      <ArchiveManager
        zip={managerZip}
        open={!!managerZip}
        onClose={() => setManagerZip(null)}
      />
    </div>
  );
}
