import { Sparkles, Code2, Package } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { AIAnalysis } from "@shared/schema";

interface AIAnalysisPanelProps {
  analysis: AIAnalysis;
  loading?: boolean;
}

export function AIAnalysisPanel({ analysis, loading }: AIAnalysisPanelProps) {
  if (loading) {
    return (
      <Card data-testid="analysis-loading">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="w-5 h-5 text-primary animate-pulse" />
            AI Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/10 animate-pulse" />
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-muted rounded animate-pulse w-3/4" />
              <div className="h-3 bg-muted rounded animate-pulse w-1/2" />
            </div>
          </div>
          <div className="space-y-2">
            <div className="h-3 bg-muted rounded animate-pulse" />
            <div className="h-3 bg-muted rounded animate-pulse w-5/6" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="analysis-panel">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="w-5 h-5 text-primary" />
          AI Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            {analysis.framework ? (
              <Code2 className="w-5 h-5 text-primary mt-0.5" />
            ) : (
              <Package className="w-5 h-5 text-primary mt-0.5" />
            )}
            <div className="flex-1 space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="secondary" className="font-semibold">
                  {analysis.projectType}
                </Badge>
                {analysis.framework && (
                  <Badge variant="outline">{analysis.framework}</Badge>
                )}
              </div>
              <p className="text-sm text-foreground leading-relaxed">
                {analysis.description}
              </p>
            </div>
          </div>
        </div>

        {analysis.technologies.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              Detected Technologies
            </p>
            <div className="flex flex-wrap gap-2">
              {analysis.technologies.map((tech) => (
                <Badge key={tech} variant="outline" className="text-xs">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-muted-foreground">Analysis Confidence</span>
            <span className="font-semibold text-foreground">{Math.round(analysis.confidence * 100)}%</span>
          </div>
          <Progress value={analysis.confidence * 100} className="h-2" />
        </div>
      </CardContent>
    </Card>
  );
}
