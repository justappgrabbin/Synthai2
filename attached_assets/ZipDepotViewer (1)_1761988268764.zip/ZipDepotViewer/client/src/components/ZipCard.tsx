import { useState } from "react";
import { Archive, Eye, Download, Trash2, Check, Play, FolderOpen } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import type { StoredZip } from "@shared/schema";

interface ZipCardProps {
  zip: StoredZip;
  selected?: boolean;
  onSelect?: (selected: boolean) => void;
  onPreview: () => void;
  onDownload: () => void;
  onDelete: () => void;
  onPlay?: () => void;
  onManage?: () => void;
}

function formatSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function ZipCard({ zip, selected, onSelect, onPreview, onDownload, onDelete, onPlay, onManage }: ZipCardProps) {
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    setIsDeleting(true);
    await onDelete();
  };

  return (
    <Card 
      className={`
        relative transition-all duration-150 hover-elevate
        ${selected ? 'ring-2 ring-primary ring-offset-2' : ''}
        ${isDeleting ? 'opacity-50 pointer-events-none' : ''}
      `}
      data-testid={`zip-card-${zip.id}`}
    >
      {onSelect && (
        <div className="absolute top-4 right-4 z-10">
          <Checkbox
            checked={selected}
            onCheckedChange={onSelect}
            className="w-5 h-5"
            data-testid={`checkbox-select-${zip.id}`}
          />
        </div>
      )}

      <CardHeader className="space-y-3 pb-4">
        <div className="flex items-start gap-3 pr-8">
          <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Archive className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-base text-foreground truncate" title={zip.originalName}>
              {zip.originalName}
            </h3>
            <p className="text-xs text-muted-foreground mt-1">
              {formatDate(zip.uploadDate)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="secondary" className="text-xs">
            {zip.analysis.projectType}
          </Badge>
          {zip.analysis.framework && (
            <Badge variant="outline" className="text-xs">
              {zip.analysis.framework}
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="pb-4 space-y-3">
        <p className="text-sm text-foreground line-clamp-2 leading-relaxed">
          {zip.analysis.description}
        </p>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{zip.structure.fileCount} files</span>
          <span>{formatSize(zip.size)}</span>
        </div>
      </CardContent>

      <CardFooter className="gap-2 pt-4 border-t flex-wrap">
        {onPlay && (
          <Button
            size="sm"
            variant="default"
            onClick={onPlay}
            className="flex-1 min-w-[100px]"
            data-testid={`button-play-${zip.id}`}
          >
            <Play className="w-4 h-4 mr-1.5" />
            Play
          </Button>
        )}
        {onManage && (
          <Button
            size="sm"
            variant="secondary"
            onClick={onManage}
            className="flex-1 min-w-[100px]"
            data-testid={`button-manage-${zip.id}`}
          >
            <FolderOpen className="w-4 h-4 mr-1.5" />
            Manage
          </Button>
        )}
        <Button
          size="sm"
          variant="outline"
          onClick={onPreview}
          className="flex-1 min-w-[90px]"
          data-testid={`button-preview-${zip.id}`}
        >
          <Eye className="w-4 h-4 mr-1.5" />
          Preview
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={onDownload}
          data-testid={`button-download-${zip.id}`}
        >
          <Download className="w-4 h-4" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={handleDelete}
          disabled={isDeleting}
          data-testid={`button-delete-${zip.id}`}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}
