import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileTreeViewer } from "./FileTreeViewer";
import { AIAnalysisPanel } from "./AIAnalysisPanel";
import type { StoredZip } from "@shared/schema";

interface ZipPreviewModalProps {
  zip: StoredZip | null;
  open: boolean;
  onClose: () => void;
}

export function ZipPreviewModal({ zip, open, onClose }: ZipPreviewModalProps) {
  if (!zip) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0" data-testid="modal-preview">
        <DialogHeader className="p-6 border-b">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold">{zip.originalName}</DialogTitle>
            <Button
              size="icon"
              variant="ghost"
              onClick={onClose}
              data-testid="button-close-modal"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </DialogHeader>

        <ScrollArea className="flex-1">
          <div className="p-6">
            <Tabs defaultValue="structure" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="structure" data-testid="tab-structure">
                  File Structure
                </TabsTrigger>
                <TabsTrigger value="analysis" data-testid="tab-analysis">
                  AI Analysis
                </TabsTrigger>
              </TabsList>

              <TabsContent value="structure" className="mt-0">
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <div className="space-y-1">
                      <p className="text-muted-foreground">
                        <span className="font-semibold text-foreground">{zip.structure.fileCount}</span> files
                        {' • '}
                        <span className="font-semibold text-foreground">{zip.structure.directoryCount}</span> folders
                      </p>
                    </div>
                  </div>

                  <FileTreeViewer entries={zip.structure.entries} />
                </div>
              </TabsContent>

              <TabsContent value="analysis" className="mt-0">
                <AIAnalysisPanel analysis={zip.analysis} />
              </TabsContent>
            </Tabs>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
