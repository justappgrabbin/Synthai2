import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Github, Cloud, Download, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface ImportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImportComplete?: () => void;
}

export function ImportModal({ open, onOpenChange, onImportComplete }: ImportModalProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("github");

  const { data: githubRepos = [], isLoading: loadingRepos } = useQuery({
    queryKey: ['/api/integrations/github/repos'],
    enabled: open && activeTab === 'github',
  });

  const { data: driveFiles = [], isLoading: loadingDrive } = useQuery({
    queryKey: ['/api/integrations/google-drive/files'],
    enabled: open && activeTab === 'drive',
  });

  const importGithubMutation = useMutation({
    mutationFn: async (repo: { owner: string; name: string; defaultBranch: string }) => {
      return await apiRequest('POST', '/api/integrations/github/import', {
        owner: repo.owner,
        repo: repo.name,
        ref: repo.defaultBranch,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/zips'] });
      toast({
        title: "Import successful",
        description: "Repository has been imported and analyzed.",
      });
      onImportComplete?.();
      onOpenChange(false);
    },
    onError: () => {
      toast({
        title: "Import failed",
        description: "Failed to import repository. Please try again.",
        variant: "destructive",
      });
    },
  });

  const importDriveMutation = useMutation({
    mutationFn: async (file: { id: string; name: string }) => {
      return await apiRequest('POST', '/api/integrations/google-drive/import', {
        fileId: file.id,
        fileName: file.name,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/zips'] });
      toast({
        title: "Import successful",
        description: "File has been imported and analyzed.",
      });
      onImportComplete?.();
      onOpenChange(false);
    },
    onError: () => {
      toast({
        title: "Import failed",
        description: "Failed to import file. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh]" data-testid="dialog-import">
        <DialogHeader>
          <DialogTitle>Import from Cloud Storage</DialogTitle>
          <DialogDescription>
            Import zip files from your GitHub repositories or Google Drive
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="github" className="gap-2" data-testid="tab-github">
              <Github className="w-4 h-4" />
              GitHub
            </TabsTrigger>
            <TabsTrigger value="drive" className="gap-2" data-testid="tab-drive">
              <Cloud className="w-4 h-4" />
              Google Drive
            </TabsTrigger>
          </TabsList>

          <TabsContent value="github" className="space-y-4">
            {loadingRepos ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <ScrollArea className="h-[400px]">
                <div className="space-y-2 pr-4">
                  {githubRepos.map((repo: any) => (
                    <div
                      key={repo.fullName}
                      className="flex items-start justify-between p-3 border rounded-md hover-elevate"
                      data-testid={`repo-${repo.name}`}
                    >
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="font-medium truncate">{repo.name}</div>
                        {repo.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {repo.description}
                          </p>
                        )}
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs">
                            {repo.defaultBranch}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            Updated {new Date(repo.updatedAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => importGithubMutation.mutate({
                          owner: repo.owner,
                          name: repo.name,
                          defaultBranch: repo.defaultBranch,
                        })}
                        disabled={importGithubMutation.isPending}
                        className="ml-4"
                        data-testid={`button-import-${repo.name}`}
                      >
                        {importGithubMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <Download className="w-4 h-4 mr-2" />
                            Import
                          </>
                        )}
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </TabsContent>

          <TabsContent value="drive" className="space-y-4">
            {loadingDrive ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : driveFiles.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No zip files found in Google Drive
              </div>
            ) : (
              <ScrollArea className="h-[400px]">
                <div className="space-y-2 pr-4">
                  {driveFiles.map((file: any) => (
                    <div
                      key={file.id}
                      className="flex items-start justify-between p-3 border rounded-md hover-elevate"
                      data-testid={`file-${file.id}`}
                    >
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="font-medium truncate">{file.name}</div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">
                            {file.size ? `${(parseInt(file.size) / 1024 / 1024).toFixed(2)} MB` : 'Unknown size'}
                          </span>
                          {file.modifiedTime && (
                            <span className="text-xs text-muted-foreground">
                              • Modified {new Date(file.modifiedTime).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => importDriveMutation.mutate({
                          id: file.id,
                          name: file.name,
                        })}
                        disabled={importDriveMutation.isPending}
                        className="ml-4"
                        data-testid={`button-import-${file.id}`}
                      >
                        {importDriveMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <Download className="w-4 h-4 mr-2" />
                            Import
                          </>
                        )}
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
