import { useState } from "react";
import { ChevronRight, ChevronDown, File, Folder, FolderOpen, Code, Image, FileText } from "lucide-react";
import type { ZipFileEntry } from "@shared/schema";

interface FileTreeViewerProps {
  entries: ZipFileEntry[];
}

interface TreeNode {
  name: string;
  path: string;
  isDirectory: boolean;
  size: number;
  type?: string;
  children: TreeNode[];
  parent?: TreeNode;
}

function buildTree(entries: ZipFileEntry[]): TreeNode[] {
  const root: TreeNode[] = [];
  const nodeMap = new Map<string, TreeNode>();

  const sortedEntries = [...entries].sort((a, b) => a.path.localeCompare(b.path));

  for (const entry of sortedEntries) {
    const parts = entry.path.split('/').filter(Boolean);
    let currentLevel = root;
    let currentPath = '';

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      currentPath += (currentPath ? '/' : '') + part;
      const isLastPart = i === parts.length - 1;

      if (!nodeMap.has(currentPath)) {
        const node: TreeNode = {
          name: part,
          path: currentPath,
          isDirectory: isLastPart ? entry.isDirectory : true,
          size: isLastPart ? entry.size : 0,
          type: entry.type,
          children: [],
        };

        nodeMap.set(currentPath, node);
        currentLevel.push(node);
      }

      currentLevel = nodeMap.get(currentPath)!.children;
    }
  }

  return root;
}

function getFileIcon(node: TreeNode) {
  if (node.isDirectory) {
    return null;
  }

  const ext = node.name.split('.').pop()?.toLowerCase();
  
  if (['js', 'ts', 'jsx', 'tsx', 'py', 'java', 'cpp', 'c', 'go', 'rs'].includes(ext || '')) {
    return <Code className="w-4 h-4 text-blue-500" />;
  }
  if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext || '')) {
    return <Image className="w-4 h-4 text-green-500" />;
  }
  if (['md', 'txt', 'json', 'xml', 'yaml', 'yml'].includes(ext || '')) {
    return <FileText className="w-4 h-4 text-yellow-600" />;
  }
  
  return <File className="w-4 h-4 text-muted-foreground" />;
}

function formatSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}

function TreeNodeComponent({ node, level = 0 }: { node: TreeNode; level?: number }) {
  const [isExpanded, setIsExpanded] = useState(level < 2);

  if (!node.isDirectory) {
    return (
      <div 
        className="flex items-center gap-2 h-8 px-2 rounded-md hover-elevate"
        style={{ paddingLeft: `${level * 16 + 8}px` }}
        data-testid={`file-${node.name}`}
      >
        {getFileIcon(node)}
        <span className="flex-1 text-sm text-foreground truncate">{node.name}</span>
        <span className="text-xs text-muted-foreground">{formatSize(node.size)}</span>
      </div>
    );
  }

  return (
    <div>
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center gap-2 h-8 px-2 rounded-md hover-elevate cursor-pointer"
        style={{ paddingLeft: `${level * 16 + 8}px` }}
        data-testid={`folder-${node.name}`}
      >
        {isExpanded ? (
          <ChevronDown className="w-4 h-4 text-muted-foreground" />
        ) : (
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        )}
        {isExpanded ? (
          <FolderOpen className="w-4 h-4 text-primary" />
        ) : (
          <Folder className="w-4 h-4 text-primary" />
        )}
        <span className="flex-1 text-sm font-medium text-foreground truncate">{node.name}</span>
        {node.children.length > 0 && (
          <span className="text-xs text-muted-foreground">{node.children.length} items</span>
        )}
      </div>
      
      {isExpanded && node.children.length > 0 && (
        <div className="space-y-0.5">
          {node.children.map((child, i) => (
            <TreeNodeComponent key={child.path} node={child} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

export function FileTreeViewer({ entries }: FileTreeViewerProps) {
  const tree = buildTree(entries);

  return (
    <div className="border rounded-lg overflow-hidden" data-testid="file-tree">
      <div className="bg-muted border-b px-4 py-2 sticky top-0 z-10">
        <div className="flex items-center gap-4 text-xs font-semibold text-muted-foreground">
          <div className="flex-1">Name</div>
          <div className="w-20 text-right">Size</div>
        </div>
      </div>
      
      <div className="max-h-96 overflow-y-auto p-2">
        {tree.length === 0 ? (
          <div className="flex items-center justify-center h-32 text-sm text-muted-foreground">
            No files found
          </div>
        ) : (
          <div className="space-y-0.5">
            {tree.map(node => (
              <TreeNodeComponent key={node.path} node={node} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
