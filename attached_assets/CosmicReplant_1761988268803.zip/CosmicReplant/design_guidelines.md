# YOUNIVERSE Replant System - Design Guidelines

## Design Approach

**Selected Approach**: Design System (Linear + VS Code) with Cosmic Branding Layer

This developer tool requires the precision and efficiency of established productivity systems while maintaining YOUNIVERSE's cosmic identity. Drawing from Linear's clean development aesthetics and VS Code's editor patterns, enhanced with subtle space-themed accents.

**Core Principles**:
- Function-first: Developer efficiency takes priority over decoration
- Spatial clarity: Clear zones for input, organization, and output
- Progressive disclosure: Complex features revealed contextually
- Immediate feedback: Visual confirmation for all auto-organization actions

---

## Typography System

**Primary Font**: Inter (via Google Fonts CDN)
- UI Labels: 14px, weight 500
- Section Headers: 18px, weight 600
- Panel Titles: 16px, weight 600
- Helper Text: 13px, weight 400

**Code Font**: JetBrains Mono (via Google Fonts CDN)
- Editor Content: 14px, weight 400, line-height 1.6
- File Names: 13px, weight 500
- Code Snippets: 13px, weight 400

**Cosmic Accents**: Space Grotesk (via Google Fonts CDN)
- App Title: 24px, weight 700
- Achievement Notifications: 16px, weight 600

---

## Layout Architecture

**Spacing System**: Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-4 or p-6
- Section spacing: gap-6 or gap-8
- Panel margins: m-4
- Tight elements: space-y-2

**Core Layout Structure**:

Three-panel dashboard layout (not marketing columns):
```
┌─────────────────────────────────────────────┐
│  Top Bar (h-16)                             │
├──────────┬─────────────────────┬────────────┤
│          │                     │            │
│  File    │   Main Editor/      │  Live      │
│  Tree    │   Code Input        │  Preview   │
│  (w-64)  │   (flex-1)          │  (w-96)    │
│          │                     │            │
└──────────┴─────────────────────┴────────────┘
```

**Responsive Behavior**:
- Desktop (lg): Three-panel view
- Tablet (md): Two-panel (hide preview, show via toggle)
- Mobile: Single panel with bottom navigation tabs

**Panel Containers**:
- All panels: Distinct visual boundaries (subtle borders or elevation)
- Scrollable independently
- Min-height: calc(100vh - 4rem) for full viewport usage
- Max-width constraints: Editor max-w-7xl for readability

---

## Component Library

### Navigation & Top Bar
**App Header**:
- Fixed top bar with backdrop blur
- Left: YOUNIVERSE logo + "Replant System" title
- Center: Project name (editable inline)
- Right: "Export to GitHub" button (primary CTA) + user menu

### File Organization Panel

**Auto-Detected File Tree**:
- Nested folder structure with expand/collapse icons (Heroicons chevron)
- File type icons (Heroicons document variants)
- Visual indicators for auto-placement:
  - Green pulse animation for newly placed files
  - Badge showing detection confidence ("Auto", "Suggested", "Manual")
- Drag-and-drop reordering with visual drop zones
- Right-click context menu (rename, move, delete)

**Pattern Detection Feedback**:
- Tooltip on hover showing why file was placed there
- Keywords highlighted in file names
- File type badges (Component, Style, Config, Asset)

### Code Input Area

**Multi-Input Tabs**:
- Tab 1: "Paste Code" - Large textarea with Monaco-style syntax highlighting
- Tab 2: "Upload Files" - Drag-and-drop zone with file list preview
- Tab 3: "Import Repo" - GitHub URL input with clone options

**Code Editor** (Monaco-style):
- Line numbers on left
- Syntax highlighting for detected language
- Auto-detection indicator at top-right ("Detected: React Component")
- Bottom toolbar: File type selector, "Add to Project" button

### Live Preview Panel

**Preview Frame**:
- Full-height iframe with device size toggles (mobile/tablet/desktop icons at top)
- Refresh button + "Open in New Tab" link
- Error overlay for build failures (red banner with clear message)
- Loading state: Cosmic animation (subtle orbital spinner)

**Build Status Bar**:
- Bottom-fixed status: "✓ Build successful" or "⚠ 3 errors"
- Click to expand error details
- Real-time update indicator (pulsing dot when changes detected)

### Export Controls

**GitHub Export Panel** (Modal or slide-out):
- Repo selector (dropdown of your repos or "Create New")
- Branch input (default: main)
- Commit message textarea (auto-generated suggestion shown)
- File change summary (x files added, y modified)
- Primary button: "Commit & Push" with GitHub icon
- Secondary: "Download ZIP"

---

## Interactions & Animations

**Minimal Motion Philosophy**:
- Use animations ONLY for feedback, not decoration
- All animations: 200-300ms duration, ease-in-out

**Critical Animations**:
1. File Auto-Placement: 300ms slide-in with green glow fade
2. Build Success: Subtle checkmark animation (500ms)
3. Panel Resize: Smooth transition (200ms)
4. Drag-and-Drop: Opacity change (0.7) + visual drop zones appear

**Cosmic Touches** (very subtle):
- App logo: Faint pulse animation (2s interval)
- Success states: Brief star particle effect (1s, non-intrusive)
- Background: Optional subtle gradient shift (slow, 30s cycle)

---

## Visual Feedback System

**Auto-Organization Indicators**:
- Success: Green accent border around newly placed file
- Suggestion: Yellow accent with "Confirm placement?" tooltip
- Conflict: Red accent with alternative location suggestions
- Manual: Grey accent, no special highlighting

**Status Communication**:
- Toast notifications: Top-right corner, auto-dismiss in 4s
- Inline validation: Below input fields (red for error, green for success)
- Progress indicators: Linear progress bar at panel top during operations

**Pattern Detection Visualization**:
- Keyword highlighting: Subtle background color on matched text
- Import path analysis: Visual tree showing detected dependencies
- File type confidence meter: 3-dot indicator (1-3 filled dots)

---

## Cosmic Theme Integration

**Restrained Application**:
- DO NOT overwhelm functional UI with space graphics
- Use cosmic theme in branding moments only:
  - App logo area
  - Success celebration screens
  - Empty states ("Your cosmic code garden awaits")
  - Achievement notifications ("Module grafted successfully!")

**Subtle Cosmic Elements**:
- Panel borders: Very faint glow effect (not distracting)
- Buttons: Slight gradient on hover (not constant)
- Success states: Brief shimmer effect

---

## Icons

**Library**: Heroicons (via CDN)
- File types: document, folder, code-bracket icons
- Actions: plus, trash, pencil, arrow-path
- Status: check-circle, exclamation-triangle, information-circle
- Navigation: chevron-down, chevron-right, bars-3

---

## Images

**Hero Section**: NOT APPLICABLE (this is an app interface, not a landing page)

**Decorative Images**:
- Background: Optional subtle cosmic gradient (CSS gradient, not image)
- Empty States: Simple icon-based illustrations, not photographs
- Logo: SVG icon of cosmic/plant hybrid symbol

**No hero images needed** - this is a functional development tool dashboard.

---

## Accessibility

- All interactive elements: min-height of h-10 for touch targets
- Form inputs: Consistent styling across all panels (border, padding, focus states)
- Focus indicators: Clear outline on all focusable elements
- Color contrast: Maintain WCAG AA standards for all text
- Keyboard navigation: Full support with visible focus states