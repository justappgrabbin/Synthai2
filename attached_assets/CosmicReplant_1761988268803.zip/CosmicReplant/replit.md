# YOUNIVERSE Replant System

## Overview
A cosmic code assembly tool that intelligently organizes pasted code, uploaded files, and imported GitHub repositories into cohesive project structures. Features pattern-based file detection (no AI needed), live preview, and one-click GitHub export.

## Purpose
Simplify the process of assembling code from multiple sources (snippets, files, repos) into well-organized projects. Auto-detect where files belong based on patterns and keywords, then export complete projects to GitHub.

## Tech Stack
- **Frontend**: React + TypeScript, Tailwind CSS, shadcn/ui components
- **Backend**: Express.js + TypeScript
- **Storage**: In-memory (MemStorage)
- **External APIs**: GitHub REST API via Octokit
- **State Management**: TanStack Query (React Query)
- **Routing**: Wouter

## Current State
Fully functional MVP with:
- ✅ Three-panel dashboard (File Tree, Code Editor, Live Preview)
- ✅ Mobile-responsive tabbed layout
- ✅ Pattern-based file detection and auto-placement
- ✅ Multiple input methods (paste code, upload files, import GitHub repos)
- ✅ File tree visualization with confidence badges
- ✅ GitHub export with repository creation
- ✅ Dark mode support
- ✅ Cosmic-themed UI with subtle animations

## Project Architecture

### Data Models (`shared/schema.ts`)
- **Projects**: Container for assembled code projects
- **Files**: Individual code files with auto-detected paths
- **FileNode**: Tree structure for UI visualization

### Frontend Components (`client/src/components/`)
- `Dashboard.tsx`: Main page with responsive layout
- `FileTreePanel.tsx`: Hierarchical file browser with auto-placement indicators
- `CodeEditorPanel.tsx`: Multi-tab input (Paste/Upload/Import)
- `LivePreviewPanel.tsx`: Device-responsive preview frame
- `GitHubExportDialog.tsx`: Repository export configuration
- `ThemeToggle.tsx`: Dark/light mode switcher

### Backend Routes (`server/routes.ts`)
- **Projects**: CRUD operations for project management
- **Files**: File creation with auto-detection, retrieval, updates
- **GitHub Export**: Push assembled projects to GitHub
- **GitHub Import**: Clone and import repository contents

### Pattern Detection (`server/lib/fileDetection.ts`, `client/src/lib/filePatterns.ts`)
Detects file types and suggests paths based on:
- File extensions (.tsx, .css, .json, etc.)
- Content patterns (React components, API routes, configs)
- Naming conventions (pages, utils, types, etc.)
- Import statements and code structure

## User Preferences
- **Design Philosophy**: Clean, cosmic-themed developer tool inspired by Linear/VS Code
- **Mobile Support**: Full responsive design with tab-based mobile layout
- **Module Flexibility**: Support for both individual file exports and full project exports
- **Auto-organization**: Pattern-based placement with manual override capability
- **GitHub Integration**: Seamless repository creation and file pushing

## Recent Changes
- Implemented complete MVP feature set
- Added responsive mobile layout with three-tab system
- Built pattern detection system for automatic file placement
- Integrated GitHub API for import/export functionality
- Designed cosmic theme with subtle animations
- Created comprehensive component library following design guidelines

## Next Steps (Post-MVP)
- Add drag-and-drop file repositioning
- Implement zip file extraction
- Add project templates and presets
- Create commit history and version control
- Enable collaborative project sharing
- Add syntax highlighting in code editor (Monaco integration)
- Implement actual live preview with sandboxed execution
