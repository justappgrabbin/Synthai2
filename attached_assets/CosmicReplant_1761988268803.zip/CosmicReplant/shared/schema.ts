import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Project schema - represents an assembled code project
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// File schema - represents individual files in a project
export const files = pgTable("files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  path: text("path").notNull(), // e.g., "src/components/Button.tsx"
  content: text("content").notNull(),
  language: text("language"), // detected language (js, tsx, css, etc.)
  detectionConfidence: text("detection_confidence"), // "auto", "suggested", "manual"
  detectionReason: text("detection_reason"), // why it was placed here
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFileSchema = createInsertSchema(files).omit({
  id: true,
  createdAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertFile = z.infer<typeof insertFileSchema>;
export type File = typeof files.$inferSelect;

// Frontend-only types for file tree structure
export interface FileNode {
  id: string;
  name: string;
  path: string;
  type: "file" | "folder";
  children?: FileNode[];
  content?: string;
  language?: string;
  detectionConfidence?: "auto" | "suggested" | "manual";
  detectionReason?: string;
  isExpanded?: boolean;
}

// GitHub export payload
export const githubExportSchema = z.object({
  projectId: z.string(),
  repoName: z.string().min(1),
  branch: z.string().default("main"),
  commitMessage: z.string().min(1),
  createNewRepo: z.boolean().default(false),
});

export type GitHubExportPayload = z.infer<typeof githubExportSchema>;
