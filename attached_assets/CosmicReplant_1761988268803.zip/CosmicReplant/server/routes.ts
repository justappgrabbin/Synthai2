import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema, insertFileSchema, githubExportSchema } from "@shared/schema";
import { detectFileLocation } from "./lib/fileDetection";
import { getUncachableGitHubClient } from "./lib/github";

export async function registerRoutes(app: Express): Promise<Server> {
  // Project routes
  app.post("/api/projects", async (req, res) => {
    try {
      const data = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(data);
      res.json(project);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/projects/current", async (req, res) => {
    try {
      const projects = await storage.getAllProjects();
      // Return most recent project
      const current = projects.sort((a, b) => 
        b.updatedAt.getTime() - a.updatedAt.getTime()
      )[0];
      res.json(current || null);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const updates = insertProjectSchema.partial().parse(req.body);
      const project = await storage.updateProject(req.params.id, updates);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteProject(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // File routes
  app.post("/api/files", async (req, res) => {
    try {
      const { projectId, name, content, path } = req.body;
      
      // Auto-detect file location if path not provided
      let finalPath = path;
      let detectionConfidence = "manual";
      let detectionReason = "Manual placement";
      let language = undefined;

      if (!path || path === "") {
        const detection = detectFileLocation(name, content);
        finalPath = detection.suggestedPath;
        detectionConfidence = detection.confidence;
        detectionReason = detection.reason;
        language = detection.language;
      }

      const fileData = {
        projectId,
        name,
        path: finalPath,
        content,
        language,
        detectionConfidence,
        detectionReason,
      };

      const validated = insertFileSchema.parse(fileData);
      const file = await storage.createFile(validated);
      res.json(file);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/files/:projectId", async (req, res) => {
    try {
      const files = await storage.getFilesByProject(req.params.projectId);
      res.json(files);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/files/:id", async (req, res) => {
    try {
      const updates = insertFileSchema.partial().parse(req.body);
      const file = await storage.updateFile(req.params.id, updates);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      res.json(file);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/files/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteFile(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "File not found" });
      }
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GitHub export route
  app.post("/api/github/export", async (req, res) => {
    try {
      const { projectId, repoName, branch, commitMessage, createNewRepo } = 
        githubExportSchema.parse(req.body);

      const octokit = await getUncachableGitHubClient();
      const { data: user } = await octokit.users.getAuthenticated();

      // Get all files for the project
      const files = await storage.getFilesByProject(projectId);

      if (createNewRepo) {
        // Create new repository
        await octokit.repos.createForAuthenticatedUser({
          name: repoName,
          private: false,
          auto_init: false,
        });
      }

      // Push files to repository
      for (const file of files) {
        const content = Buffer.from(file.content).toString('base64');
        
        try {
          await octokit.repos.createOrUpdateFileContents({
            owner: user.login,
            repo: repoName,
            path: file.path,
            message: commitMessage,
            content,
            branch,
          });
        } catch (error: any) {
          console.error(`Error pushing file ${file.path}:`, error.message);
        }
      }

      const repoUrl = `https://github.com/${user.login}/${repoName}`;
      res.json({ success: true, repoUrl });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // GitHub import route (fetch repo contents)
  app.post("/api/github/import", async (req, res) => {
    try {
      const { repoUrl, projectId } = req.body;
      
      // Parse GitHub URL
      const urlParts = repoUrl.replace("https://github.com/", "").split("/");
      const owner = urlParts[0];
      const repo = urlParts[1];

      const octokit = await getUncachableGitHubClient();
      
      // Get repository tree
      const { data: repoData } = await octokit.repos.get({ owner, repo });
      const { data: tree } = await octokit.git.getTree({
        owner,
        repo,
        tree_sha: repoData.default_branch,
        recursive: "1",
      });

      // Fetch file contents and create files
      const importedFiles = [];
      for (const item of tree.tree) {
        if (item.type === "blob" && item.path) {
          try {
            const { data: fileData } = await octokit.repos.getContent({
              owner,
              repo,
              path: item.path,
            });

            if ('content' in fileData) {
              const content = Buffer.from(fileData.content, 'base64').toString('utf-8');
              const fileName = item.path.split('/').pop() || item.path;
              
              const file = await storage.createFile({
                projectId,
                name: fileName,
                path: item.path,
                content,
                detectionConfidence: "auto",
                detectionReason: "Imported from GitHub repository",
              });
              
              importedFiles.push(file);
            }
          } catch (error) {
            console.error(`Error importing file ${item.path}:`, error);
          }
        }
      }

      res.json({ success: true, filesImported: importedFiles.length });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
