// Server-side file pattern detection
export interface FileDetectionResult {
  suggestedPath: string;
  confidence: "auto" | "suggested" | "manual";
  reason: string;
  language?: string;
}

export function detectFileLocation(fileName: string, content: string): FileDetectionResult {
  const lowerName = fileName.toLowerCase();
  const lowerContent = content.toLowerCase();
  
  // React component detection
  if ((lowerName.endsWith(".tsx") || lowerName.endsWith(".jsx")) && 
      (lowerContent.includes("export") || lowerContent.includes("function"))) {
    if (lowerContent.includes("return") && lowerContent.includes("<")) {
      return {
        suggestedPath: `src/components/${fileName}`,
        confidence: "auto",
        reason: "React component detected (JSX/TSX with export)",
        language: lowerName.endsWith(".tsx") ? "typescript" : "javascript",
      };
    }
  }

  // Page/Route detection
  if (lowerName.includes("page") || lowerName.includes("route")) {
    return {
      suggestedPath: `src/pages/${fileName}`,
      confidence: "auto",
      reason: "Page/Route component detected",
      language: lowerName.endsWith(".tsx") ? "typescript" : "javascript",
    };
  }

  // Style files
  if (lowerName.endsWith(".css") || lowerName.endsWith(".scss")) {
    if (lowerName.includes("global") || lowerName.includes("index")) {
      return {
        suggestedPath: `src/${fileName}`,
        confidence: "auto",
        reason: "Global stylesheet detected",
        language: "css",
      };
    }
    return {
      suggestedPath: `src/styles/${fileName}`,
      confidence: "auto",
      reason: "Stylesheet detected",
      language: "css",
    };
  }

  // Config files
  if (lowerName.includes("config") || lowerName === "package.json" || 
      lowerName === "tsconfig.json") {
    return {
      suggestedPath: fileName,
      confidence: "auto",
      reason: "Configuration file detected",
      language: "json",
    };
  }

  // Utility files
  if (lowerName.includes("util") || lowerName.includes("helper") || lowerName.includes("lib")) {
    return {
      suggestedPath: `src/lib/${fileName}`,
      confidence: "suggested",
      reason: "Utility/helper functions detected",
      language: lowerName.endsWith(".ts") ? "typescript" : "javascript",
    };
  }

  // Type definitions
  if (lowerName.endsWith(".d.ts") || lowerName.includes("types")) {
    return {
      suggestedPath: `src/types/${fileName}`,
      confidence: "auto",
      reason: "Type definitions detected",
      language: "typescript",
    };
  }

  // API/Server files
  if (lowerName.includes("api") || lowerName.includes("server") || 
      lowerContent.includes("express") || lowerContent.includes("app.get")) {
    return {
      suggestedPath: `server/${fileName}`,
      confidence: "auto",
      reason: "API/Server file detected",
      language: lowerName.endsWith(".ts") ? "typescript" : "javascript",
    };
  }

  // Assets
  if (lowerName.endsWith(".png") || lowerName.endsWith(".jpg") || 
      lowerName.endsWith(".svg") || lowerName.endsWith(".gif")) {
    return {
      suggestedPath: `public/assets/${fileName}`,
      confidence: "auto",
      reason: "Asset file detected",
    };
  }

  // HTML files
  if (lowerName.endsWith(".html")) {
    return {
      suggestedPath: lowerName.includes("index") ? fileName : `public/${fileName}`,
      confidence: "auto",
      reason: "HTML file detected",
      language: "html",
    };
  }

  // Markdown
  if (lowerName.endsWith(".md")) {
    return {
      suggestedPath: fileName,
      confidence: "auto",
      reason: "Documentation file detected",
      language: "markdown",
    };
  }

  // Default
  return {
    suggestedPath: `src/${fileName}`,
    confidence: "manual",
    reason: "Unable to detect file type - manual placement suggested",
  };
}
