import type { FileNode } from "@shared/schema";

export function buildFileTree(files: Array<{ id: string; name: string; path: string; content: string; language?: string; detectionConfidence?: string; detectionReason?: string }>): FileNode[] {
  const root: FileNode[] = [];
  const folderMap = new Map<string, FileNode>();

  files.forEach((file) => {
    const pathParts = file.path.split("/");
    let currentLevel = root;
    let currentPath = "";

    pathParts.forEach((part, index) => {
      const isFile = index === pathParts.length - 1;
      currentPath = currentPath ? `${currentPath}/${part}` : part;

      if (isFile) {
        currentLevel.push({
          id: file.id,
          name: part,
          path: file.path,
          type: "file",
          content: file.content,
          language: file.language,
          detectionConfidence: file.detectionConfidence as "auto" | "suggested" | "manual",
          detectionReason: file.detectionReason,
        });
      } else {
        let folder = folderMap.get(currentPath);
        if (!folder) {
          folder = {
            id: currentPath,
            name: part,
            path: currentPath,
            type: "folder",
            children: [],
            isExpanded: true,
          };
          folderMap.set(currentPath, folder);
          currentLevel.push(folder);
        }
        currentLevel = folder.children!;
      }
    });
  });

  return sortFileTree(root);
}

function sortFileTree(nodes: FileNode[]): FileNode[] {
  return nodes.sort((a, b) => {
    if (a.type === "folder" && b.type === "file") return -1;
    if (a.type === "file" && b.type === "folder") return 1;
    return a.name.localeCompare(b.name);
  }).map(node => {
    if (node.children) {
      return { ...node, children: sortFileTree(node.children) };
    }
    return node;
  });
}

export function flattenFileTree(nodes: FileNode[]): Array<{ id: string; path: string }> {
  const result: Array<{ id: string; path: string }> = [];
  
  function traverse(nodes: FileNode[]) {
    nodes.forEach(node => {
      if (node.type === "file") {
        result.push({ id: node.id, path: node.path });
      }
      if (node.children) {
        traverse(node.children);
      }
    });
  }
  
  traverse(nodes);
  return result;
}

export function updateFilePath(tree: FileNode[], fileId: string, newPath: string): FileNode[] {
  // This would handle drag-and-drop repositioning
  // For now, we'll rebuild the tree with updated paths
  return tree;
}
