// Pattern-based file detection without AI
export interface DetectionResult {
  suggestedPath: string;
  confidence: "auto" | "suggested" | "manual";
  reason: string;
  language?: string;
}

export function detectFileType(fileName: string, content: string): DetectionResult {
  const lowerName = fileName.toLowerCase();
  const lowerContent = content.toLowerCase();
  
  // React component detection
  if (
    (lowerName.endsWith(".tsx") || lowerName.endsWith(".jsx")) &&
    (lowerContent.includes("export") || lowerContent.includes("function") || lowerContent.includes("const"))
  ) {
    if (lowerContent.includes("return") && (lowerContent.includes("<") || lowerContent.includes("jsx"))) {
      return {
        suggestedPath: `src/components/${fileName}`,
        confidence: "auto",
        reason: "React component detected (JSX/TSX with export)",
        language: lowerName.endsWith(".tsx") ? "typescript" : "javascript",
      };
    }
  }

  // Page/Route detection
  if (
    lowerName.includes("page") ||
    lowerName.includes("route") ||
    lowerContent.includes("route") ||
    lowerContent.includes("router")
  ) {
    return {
      suggestedPath: `src/pages/${fileName}`,
      confidence: "auto",
      reason: "Page/Route component detected",
      language: lowerName.endsWith(".tsx") ? "typescript" : "javascript",
    };
  }

  // Style files
  if (lowerName.endsWith(".css") || lowerName.endsWith(".scss") || lowerName.endsWith(".less")) {
    if (lowerName.includes("global") || lowerName.includes("index")) {
      return {
        suggestedPath: `src/${fileName}`,
        confidence: "auto",
        reason: "Global stylesheet detected",
        language: "css",
      };
    }
    return {
      suggestedPath: `src/styles/${fileName}`,
      confidence: "auto",
      reason: "Stylesheet detected",
      language: "css",
    };
  }

  // Config files
  if (
    lowerName.includes("config") ||
    lowerName === "package.json" ||
    lowerName === "tsconfig.json" ||
    lowerName === "vite.config" ||
    lowerName === "tailwind.config"
  ) {
    return {
      suggestedPath: fileName,
      confidence: "auto",
      reason: "Configuration file detected",
      language: "json",
    };
  }

  // Utility/Helper files
  if (
    lowerName.includes("util") ||
    lowerName.includes("helper") ||
    lowerName.includes("lib") ||
    lowerContent.includes("export function") ||
    lowerContent.includes("export const")
  ) {
    return {
      suggestedPath: `src/lib/${fileName}`,
      confidence: "suggested",
      reason: "Utility/helper functions detected",
      language: lowerName.endsWith(".ts") ? "typescript" : "javascript",
    };
  }

  // Type definitions
  if (lowerName.endsWith(".d.ts") || lowerName.includes("types") || lowerContent.includes("interface") || lowerContent.includes("type ")) {
    return {
      suggestedPath: `src/types/${fileName}`,
      confidence: "auto",
      reason: "Type definitions detected",
      language: "typescript",
    };
  }

  // API/Server files
  if (
    lowerName.includes("api") ||
    lowerName.includes("server") ||
    lowerName.includes("route") ||
    lowerContent.includes("express") ||
    lowerContent.includes("app.get") ||
    lowerContent.includes("app.post")
  ) {
    return {
      suggestedPath: `server/${fileName}`,
      confidence: "auto",
      reason: "API/Server file detected",
      language: lowerName.endsWith(".ts") ? "typescript" : "javascript",
    };
  }

  // Assets (images, fonts, etc.)
  if (
    lowerName.endsWith(".png") ||
    lowerName.endsWith(".jpg") ||
    lowerName.endsWith(".svg") ||
    lowerName.endsWith(".gif") ||
    lowerName.endsWith(".woff") ||
    lowerName.endsWith(".ttf")
  ) {
    return {
      suggestedPath: `public/assets/${fileName}`,
      confidence: "auto",
      reason: "Asset file detected",
    };
  }

  // HTML files
  if (lowerName.endsWith(".html")) {
    return {
      suggestedPath: lowerName.includes("index") ? fileName : `public/${fileName}`,
      confidence: "auto",
      reason: "HTML file detected",
      language: "html",
    };
  }

  // Markdown files
  if (lowerName.endsWith(".md")) {
    return {
      suggestedPath: fileName,
      confidence: "auto",
      reason: "Documentation file detected",
      language: "markdown",
    };
  }

  // Default fallback
  return {
    suggestedPath: `src/${fileName}`,
    confidence: "manual",
    reason: "Unable to detect file type - manual placement suggested",
    language: detectLanguage(fileName),
  };
}

function detectLanguage(fileName: string): string {
  const ext = fileName.split(".").pop()?.toLowerCase();
  const languageMap: Record<string, string> = {
    ts: "typescript",
    tsx: "typescript",
    js: "javascript",
    jsx: "javascript",
    css: "css",
    scss: "scss",
    html: "html",
    json: "json",
    md: "markdown",
    py: "python",
    rb: "ruby",
    go: "go",
    rs: "rust",
  };
  return languageMap[ext || ""] || "plaintext";
}
