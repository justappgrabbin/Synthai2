import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { FileTreePanel } from "@/components/FileTreePanel";
import { CodeEditorPanel } from "@/components/CodeEditorPanel";
import { LivePreviewPanel } from "@/components/LivePreviewPanel";
import { GitHubExportDialog } from "@/components/GitHubExportDialog";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, Sparkles, Menu } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { buildFileTree } from "@/lib/fileTreeUtils";
import { detectFileType } from "@/lib/filePatterns";
import type { FileNode, Project, File } from "@shared/schema";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const [projectName, setProjectName] = useState("My Project");
  const [projectId, setProjectId] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [mobilePanel, setMobilePanel] = useState<"tree" | "editor" | "preview">("editor");
  const { toast } = useToast();

  const { data: currentProject } = useQuery<Project>({
    queryKey: ["/api/projects/current"],
  });

  const { data: files = [] } = useQuery<File[]>({
    queryKey: ["/api/files", projectId],
    enabled: !!projectId,
  });

  const createProjectMutation = useMutation({
    mutationFn: async (name: string) => {
      return apiRequest("POST", "/api/projects", { name, description: "" });
    },
    onSuccess: (data: any) => {
      setProjectId(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/projects/current"] });
    },
  });

  const addFileMutation = useMutation({
    mutationFn: async ({ fileName, content }: { fileName: string; content: string }) => {
      if (!projectId) {
        const project = await apiRequest("POST", "/api/projects", {
          name: projectName,
          description: "",
        });
        setProjectId(project.id);
        return apiRequest("POST", "/api/files", {
          projectId: project.id,
          name: fileName,
          path: "",
          content,
        });
      }
      return apiRequest("POST", "/api/files", {
        projectId,
        name: fileName,
        path: "",
        content,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files", projectId] });
      toast({
        title: "Module grafted successfully!",
        description: "Code has been added to your cosmic garden",
      });
    },
  });

  const handleAddCode = async (code: string, fileName: string) => {
    const detection = detectFileType(fileName, code);
    
    addFileMutation.mutate(
      { fileName, content: code },
      {
        onSuccess: () => {
          toast({
            title: "Auto-placed in tree",
            description: detection.reason,
          });
        },
      }
    );
  };

  const handleUploadFiles = async (fileList: FileList) => {
    Array.from(fileList).forEach(async (file) => {
      const content = await file.text();
      handleAddCode(content, file.name);
    });
  };

  const handleImportRepo = async (repoUrl: string) => {
    toast({
      title: "Importing repository...",
      description: "This may take a moment",
    });
    // This would call the backend to clone and import
    // For now, just show a toast
  };

  useEffect(() => {
    if (currentProject) {
      setProjectId(currentProject.id);
      setProjectName(currentProject.name);
    } else if (!projectId && !createProjectMutation.isPending) {
      createProjectMutation.mutate(projectName);
    }
  }, [currentProject]);

  const fileTree = buildFileTree(
    files.map((f) => ({
      id: f.id,
      name: f.name,
      path: f.path || f.name,
      content: f.content,
      language: f.language,
      detectionConfidence: f.detectionConfidence,
      detectionReason: f.detectionReason,
    }))
  );

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      {/* Header */}
      <header className="h-14 border-b bg-card px-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center animate-cosmic-pulse">
              <Sparkles className="h-3.5 w-3.5 text-primary" />
            </div>
            <div>
              <h1 className="text-base font-bold" style={{ fontFamily: "Space Grotesk, sans-serif" }}>
                YOUNIVERSE
              </h1>
              <p className="text-[10px] text-muted-foreground">Replant System</p>
            </div>
          </div>
          <Input
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            className="w-40 h-8 text-sm hidden md:block"
            data-testid="input-project-name"
          />
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={() => setExportDialogOpen(true)}
            disabled={files.length === 0}
            data-testid="button-export-github"
            className="hidden sm:flex h-8 text-sm"
            size="sm"
          >
            <Upload className="h-3.5 w-3.5 mr-1.5" />
            Export to GitHub
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setExportDialogOpen(true)}
            disabled={files.length === 0}
            data-testid="button-export-github-mobile"
            className="sm:hidden h-8 w-8"
          >
            <Upload className="h-3.5 w-3.5" />
          </Button>
          <ThemeToggle />
        </div>
      </header>

      {/* Desktop: Three-panel layout */}
      <div className="hidden lg:flex flex-1 overflow-hidden">
        <FileTreePanel
          files={fileTree}
          selectedFileId={selectedFile?.id || null}
          onFileSelect={setSelectedFile}
          className="w-64"
        />
        <CodeEditorPanel
          onAddCode={handleAddCode}
          onUploadFiles={handleUploadFiles}
          onImportRepo={handleImportRepo}
          className="flex-1"
        />
        <LivePreviewPanel
          projectId={projectId}
          buildStatus="idle"
          className="w-96"
        />
      </div>

      {/* Mobile/Tablet: Tabbed layout */}
      <div className="lg:hidden flex-1 overflow-hidden">
        <Tabs value={mobilePanel} onValueChange={(v) => setMobilePanel(v as any)} className="h-full flex flex-col">
          <div className="border-b">
            <TabsList className="w-full grid grid-cols-3 rounded-none h-12">
              <TabsTrigger value="tree" data-testid="mobile-tab-tree">
                <Menu className="h-4 w-4 mr-2" />
                Files
              </TabsTrigger>
              <TabsTrigger value="editor" data-testid="mobile-tab-editor">
                <Sparkles className="h-4 w-4 mr-2" />
                Code
              </TabsTrigger>
              <TabsTrigger value="preview" data-testid="mobile-tab-preview">
                <Upload className="h-4 w-4 mr-2" />
                Preview
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="tree" className="flex-1 m-0">
            <FileTreePanel
              files={fileTree}
              selectedFileId={selectedFile?.id || null}
              onFileSelect={setSelectedFile}
            />
          </TabsContent>

          <TabsContent value="editor" className="flex-1 m-0">
            <CodeEditorPanel
              onAddCode={handleAddCode}
              onUploadFiles={handleUploadFiles}
              onImportRepo={handleImportRepo}
            />
          </TabsContent>

          <TabsContent value="preview" className="flex-1 m-0">
            <LivePreviewPanel
              projectId={projectId}
              buildStatus="idle"
            />
          </TabsContent>
        </Tabs>
      </div>

      {projectId && (
        <GitHubExportDialog
          open={exportDialogOpen}
          onOpenChange={setExportDialogOpen}
          projectId={projectId}
          projectName={projectName}
          fileCount={files.length}
        />
      )}
    </div>
  );
}
