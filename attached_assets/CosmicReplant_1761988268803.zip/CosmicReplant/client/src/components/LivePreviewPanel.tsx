import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, ExternalLink, Monitor, Tablet, Smartphone, AlertCircle, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface LivePreviewPanelProps {
  projectId: string | null;
  buildStatus: "idle" | "building" | "success" | "error";
  errorMessage?: string;
  className?: string;
}

type DeviceSize = "desktop" | "tablet" | "mobile";

export function LivePreviewPanel({ projectId, buildStatus, errorMessage, className }: LivePreviewPanelProps) {
  const [deviceSize, setDeviceSize] = useState<DeviceSize>("desktop");
  const [key, setKey] = useState(0);

  const handleRefresh = () => {
    setKey(prev => prev + 1);
  };

  const deviceStyles = {
    desktop: "w-full h-full",
    tablet: "w-[768px] h-[1024px] mx-auto",
    mobile: "w-[375px] h-[667px] mx-auto",
  };

  return (
    <div className={cn("flex flex-col h-full border-l bg-card", className)}>
      <div className="p-3 border-b space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold">Live Preview</h2>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRefresh}
              data-testid="button-refresh-preview"
              className="h-8 w-8"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              data-testid="button-open-new-tab"
              className="h-8 w-8"
            >
              <ExternalLink className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant={deviceSize === "desktop" ? "secondary" : "ghost"}
            size="icon"
            onClick={() => setDeviceSize("desktop")}
            data-testid="button-device-desktop"
            className="h-8 w-8"
          >
            <Monitor className="h-4 w-4" />
          </Button>
          <Button
            variant={deviceSize === "tablet" ? "secondary" : "ghost"}
            size="icon"
            onClick={() => setDeviceSize("tablet")}
            data-testid="button-device-tablet"
            className="h-8 w-8"
          >
            <Tablet className="h-4 w-4" />
          </Button>
          <Button
            variant={deviceSize === "mobile" ? "secondary" : "ghost"}
            size="icon"
            onClick={() => setDeviceSize("mobile")}
            data-testid="button-device-mobile"
            className="h-8 w-8"
          >
            <Smartphone className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4 bg-muted/30">
        {!projectId ? (
          <div className="h-full flex items-center justify-center text-center">
            <div className="max-w-md space-y-3">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto animate-cosmic-pulse">
                <Monitor className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold">No Preview Available</h3>
              <p className="text-sm text-muted-foreground">
                Add code files to see a live preview of your assembled project
              </p>
            </div>
          </div>
        ) : (
          <div className={cn("transition-all duration-300", deviceStyles[deviceSize])}>
            <div className="w-full h-full bg-background rounded-md border shadow-lg overflow-hidden">
              {buildStatus === "error" ? (
                <div className="h-full flex items-center justify-center p-6">
                  <div className="text-center space-y-3 max-w-md">
                    <AlertCircle className="h-12 w-12 text-destructive mx-auto" />
                    <h3 className="font-semibold">Build Error</h3>
                    <p className="text-sm text-muted-foreground">{errorMessage || "Failed to build preview"}</p>
                    <Button onClick={handleRefresh} variant="outline" size="sm">
                      Try Again
                    </Button>
                  </div>
                </div>
              ) : (
                <iframe
                  key={key}
                  src="/preview"
                  className="w-full h-full border-0"
                  title="Live Preview"
                  sandbox="allow-scripts allow-same-origin"
                />
              )}
            </div>
          </div>
        )}
      </div>

      <div className="p-3 border-t bg-card">
        {buildStatus === "building" && (
          <Badge variant="outline" className="gap-2">
            <RefreshCw className="h-3 w-3 animate-spin" />
            Building...
          </Badge>
        )}
        {buildStatus === "success" && (
          <Badge variant="outline" className="gap-2 text-green-600 border-green-600">
            <CheckCircle2 className="h-3 w-3" />
            Build successful
          </Badge>
        )}
        {buildStatus === "error" && (
          <Badge variant="outline" className="gap-2 text-destructive border-destructive">
            <AlertCircle className="h-3 w-3" />
            Build failed
          </Badge>
        )}
      </div>
    </div>
  );
}
