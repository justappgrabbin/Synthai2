import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { GitBranch, Upload, CheckCircle2, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface GitHubExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  projectId: string;
  projectName: string;
  fileCount: number;
}

export function GitHubExportDialog({ open, onOpenChange, projectId, projectName, fileCount }: GitHubExportDialogProps) {
  const [repoName, setRepoName] = useState(projectName.toLowerCase().replace(/\s+/g, "-"));
  const [branch, setBranch] = useState("main");
  const [commitMessage, setCommitMessage] = useState(`Add ${projectName} project via YOUNIVERSE Replant`);
  const [createNewRepo, setCreateNewRepo] = useState(true);
  const { toast } = useToast();

  const exportMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/github/export", {
        projectId,
        repoName,
        branch,
        commitMessage,
        createNewRepo,
      });
    },
    onSuccess: (data: any) => {
      toast({
        title: "Export Successful!",
        description: `Project pushed to GitHub successfully. View at ${data.repoUrl}`,
      });
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Export Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleExport = () => {
    exportMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" data-testid="dialog-github-export">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitBranch className="h-5 w-5" />
            Export to GitHub
          </DialogTitle>
          <DialogDescription>
            Push your assembled project to GitHub
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="createNew">Create new repository</Label>
              <Switch
                id="createNew"
                checked={createNewRepo}
                onCheckedChange={setCreateNewRepo}
                data-testid="switch-create-new-repo"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="repoName">Repository Name</Label>
            <Input
              id="repoName"
              value={repoName}
              onChange={(e) => setRepoName(e.target.value)}
              placeholder="my-awesome-project"
              data-testid="input-repo-name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="branch">Branch</Label>
            <Input
              id="branch"
              value={branch}
              onChange={(e) => setBranch(e.target.value)}
              placeholder="main"
              data-testid="input-branch"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="commitMessage">Commit Message</Label>
            <Textarea
              id="commitMessage"
              value={commitMessage}
              onChange={(e) => setCommitMessage(e.target.value)}
              placeholder="Initial commit"
              rows={3}
              data-testid="textarea-commit-message"
            />
          </div>

          <div className="bg-muted rounded-md p-3">
            <p className="text-sm font-medium mb-2">Files to commit:</p>
            <Badge variant="outline">{fileCount} files</Badge>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            data-testid="button-cancel-export"
          >
            Cancel
          </Button>
          <Button
            onClick={handleExport}
            disabled={!repoName || !commitMessage || exportMutation.isPending}
            data-testid="button-confirm-export"
          >
            {exportMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Pushing...
              </>
            ) : (
              <>
                <Upload className="h-4 w-4 mr-2" />
                Commit & Push
              </>
            )}
          </Button>
        </DialogFooter>

        {exportMutation.isSuccess && (
          <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 dark:bg-green-950 p-3 rounded-md">
            <CheckCircle2 className="h-4 w-4" />
            Successfully exported to GitHub!
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
