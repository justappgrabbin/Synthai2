import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Upload, GitBranch, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface CodeEditorPanelProps {
  onAddCode: (code: string, fileName: string) => void;
  onUploadFiles: (files: FileList) => void;
  onImportRepo: (repoUrl: string) => void;
  className?: string;
}

export function CodeEditorPanel({ onAddCode, onUploadFiles, onImportRepo, className }: CodeEditorPanelProps) {
  const [activeTab, setActiveTab] = useState("paste");
  const [code, setCode] = useState("");
  const [fileName, setFileName] = useState("");
  const [repoUrl, setRepoUrl] = useState("");
  const [detectedLanguage, setDetectedLanguage] = useState<string | null>(null);

  const handleCodeChange = (value: string) => {
    setCode(value);
    // Simple language detection
    if (value.includes("import React") || value.includes("export default")) {
      setDetectedLanguage("React Component");
    } else if (value.includes("function") || value.includes("const")) {
      setDetectedLanguage("JavaScript");
    } else if (value.includes("{") && value.includes("}")) {
      setDetectedLanguage("JSON");
    } else {
      setDetectedLanguage(null);
    }
  };

  const handleAddCode = () => {
    if (code && fileName) {
      onAddCode(code, fileName);
      setCode("");
      setFileName("");
      setDetectedLanguage(null);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onUploadFiles(e.target.files);
      e.target.value = "";
    }
  };

  const handleImportRepo = () => {
    if (repoUrl) {
      onImportRepo(repoUrl);
      setRepoUrl("");
    }
  };

  return (
    <div className={cn("flex flex-col h-full bg-background", className)}>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <div className="p-3 border-b">
          <TabsList className="grid w-full grid-cols-3 mb-3 h-9">
            <TabsTrigger value="paste" data-testid="tab-paste-code" className="text-xs">
              <Plus className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Paste Code</span>
              <span className="sm:hidden">Paste</span>
            </TabsTrigger>
            <TabsTrigger value="upload" data-testid="tab-upload-files" className="text-xs">
              <Upload className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Upload Files</span>
              <span className="sm:hidden">Upload</span>
            </TabsTrigger>
            <TabsTrigger value="import" data-testid="tab-import-repo" className="text-xs">
              <GitBranch className="h-3.5 w-3.5 mr-1.5" />
              <span className="hidden sm:inline">Import Repo</span>
              <span className="sm:hidden">Import</span>
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="flex-1 overflow-y-auto">
          <TabsContent value="paste" className="p-3 space-y-3 m-0 h-full">
            <div className="space-y-1.5">
              <Label htmlFor="fileName" className="text-xs">File Name</Label>
              <Input
                id="fileName"
                placeholder="MyComponent.tsx"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                data-testid="input-file-name"
                className="font-mono text-sm"
              />
            </div>
            
            <div className="space-y-1.5 flex-1 flex flex-col">
              <div className="flex items-center justify-between">
                <Label htmlFor="code" className="text-xs">Code</Label>
                {detectedLanguage && (
                  <Badge variant="outline" className="gap-1">
                    <Sparkles className="h-3 w-3" />
                    {detectedLanguage}
                  </Badge>
                )}
              </div>
              <Textarea
                id="code"
                placeholder="Paste your code here..."
                value={code}
                onChange={(e) => handleCodeChange(e.target.value)}
                data-testid="textarea-code"
                className="font-mono text-sm flex-1 min-h-[300px] resize-none"
              />
            </div>

            <Button
              onClick={handleAddCode}
              disabled={!code || !fileName}
              className="w-full"
              data-testid="button-add-code"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Grow Module
            </Button>
          </TabsContent>

          <TabsContent value="upload" className="p-4 space-y-4 m-0">
            <div className="space-y-4">
              <div className="border-2 border-dashed rounded-md p-8 text-center hover-elevate transition-colors">
                <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-sm font-medium mb-2">Drop files here or click to browse</p>
                <p className="text-xs text-muted-foreground mb-4">Supports .js, .tsx, .css, .json, .zip and more</p>
                <Input
                  type="file"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                  data-testid="input-file-upload"
                />
                <Button asChild variant="outline">
                  <label htmlFor="file-upload" className="cursor-pointer">
                    Select Files
                  </label>
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="import" className="p-4 space-y-4 m-0">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="repoUrl">GitHub Repository URL</Label>
                <Input
                  id="repoUrl"
                  placeholder="https://github.com/username/repo"
                  value={repoUrl}
                  onChange={(e) => setRepoUrl(e.target.value)}
                  data-testid="input-repo-url"
                />
              </div>

              <Button
                onClick={handleImportRepo}
                disabled={!repoUrl}
                className="w-full"
                data-testid="button-import-repo"
              >
                <GitBranch className="h-4 w-4 mr-2" />
                Import Repository
              </Button>

              <div className="bg-muted rounded-md p-4 text-sm">
                <p className="font-medium mb-2">How it works:</p>
                <ul className="text-muted-foreground space-y-1 text-xs">
                  <li>• Paste any GitHub repository URL</li>
                  <li>• Files will be automatically organized</li>
                  <li>• Review and adjust placements as needed</li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
