import { useState } from "react";
import type { FileNode } from "@shared/schema";
import { ChevronRight, ChevronDown, FileCode, Folder, FolderOpen, CheckCircle2, AlertCircle, Circle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface FileTreePanelProps {
  files: FileNode[];
  selectedFileId: string | null;
  onFileSelect: (file: FileNode) => void;
  className?: string;
}

export function FileTreePanel({ files, selectedFileId, onFileSelect, className }: FileTreePanelProps) {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());

  const toggleFolder = (folderId: string) => {
    setExpandedFolders(prev => {
      const next = new Set(prev);
      if (next.has(folderId)) {
        next.delete(folderId);
      } else {
        next.add(folderId);
      }
      return next;
    });
  };

  const renderNode = (node: FileNode, depth = 0) => {
    const isExpanded = expandedFolders.has(node.id);
    const isSelected = selectedFileId === node.id;

    if (node.type === "folder") {
      return (
        <div key={node.id}>
          <button
            onClick={() => toggleFolder(node.id)}
            className={cn(
              "w-full flex items-center gap-1.5 px-1.5 py-1 text-xs hover-elevate rounded-md transition-colors",
              isExpanded && "bg-muted/50"
            )}
            style={{ paddingLeft: `${depth * 10 + 6}px` }}
            data-testid={`folder-${node.name}`}
          >
            {isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
            )}
            {isExpanded ? (
              <FolderOpen className="h-3.5 w-3.5 text-primary" />
            ) : (
              <Folder className="h-3.5 w-3.5 text-muted-foreground" />
            )}
            <span className="font-medium">{node.name}</span>
          </button>
          {isExpanded && node.children && (
            <div>
              {node.children.map(child => renderNode(child, depth + 1))}
            </div>
          )}
        </div>
      );
    }

    const confidenceIcon = {
      auto: <CheckCircle2 className="h-3 w-3 text-green-500" />,
      suggested: <AlertCircle className="h-3 w-3 text-yellow-500" />,
      manual: <Circle className="h-3 w-3 text-muted-foreground" />,
    }[node.detectionConfidence || "manual"];

    const confidenceBadge = {
      auto: "Auto",
      suggested: "Suggested",
      manual: "Manual",
    }[node.detectionConfidence || "manual"];

    return (
      <button
        key={node.id}
        onClick={() => onFileSelect(node)}
        className={cn(
          "w-full flex items-center gap-1.5 px-1.5 py-1 text-xs rounded-md transition-all group",
          isSelected ? "bg-primary/10 text-primary font-medium" : "hover-elevate",
          node.detectionConfidence === "auto" && !isSelected && "animate-slide-in"
        )}
        style={{ paddingLeft: `${depth * 10 + 26}px` }}
        data-testid={`file-${node.name}`}
        title={node.detectionReason}
      >
        <FileCode className="h-3.5 w-3.5 text-muted-foreground group-hover:text-foreground" />
        <span className="flex-1 text-left truncate">{node.name}</span>
        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
          {confidenceIcon}
          <Badge variant="outline" className="text-[10px] px-1 py-0">
            {confidenceBadge}
          </Badge>
        </div>
      </button>
    );
  };

  return (
    <div className={cn("flex flex-col h-full border-r bg-card", className)}>
      <div className="p-3 border-b">
        <h2 className="text-sm font-semibold">Project Files</h2>
        <p className="text-[11px] text-muted-foreground mt-0.5">
          {files.filter(f => f.type === "file" || (f.children && countFiles(f.children) > 0)).length} files
        </p>
      </div>
      <div className="flex-1 overflow-y-auto p-1.5">
        {files.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6">
            <Folder className="h-12 w-12 text-muted-foreground mb-3 opacity-50" />
            <p className="text-sm text-muted-foreground">Your cosmic code garden awaits</p>
            <p className="text-xs text-muted-foreground mt-1">Add code to see it organize automatically</p>
          </div>
        ) : (
          <div className="space-y-0.5">
            {files.map(node => renderNode(node))}
          </div>
        )}
      </div>
    </div>
  );
}

function countFiles(nodes: FileNode[]): number {
  let count = 0;
  nodes.forEach(node => {
    if (node.type === "file") count++;
    if (node.children) count += countFiles(node.children);
  });
  return count;
}
